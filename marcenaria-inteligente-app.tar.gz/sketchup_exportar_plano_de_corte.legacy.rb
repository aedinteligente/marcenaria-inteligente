require 'json'
require 'time'
require 'uri'
require 'net/http'
require 'fileutils'
require 'tmpdir'
require 'sketchup.rb'

module MarcenariaInteligente
  module CloudSync
    extend self

    PLUGIN_VERSION = '0.4.0'.freeze
    ROOT_MENU_NAME = 'Marcenaria Inteligente'.freeze
    CONNECT_MENU_NAME = 'Conectar Cloud Sync'.freeze
    SYNC_MENU_NAME = 'Sincronizar Projeto'.freeze
    CHECK_UPDATES_MENU_NAME = 'Verificar Atualizações do Plugin'.freeze
    CONFIG_MENU_NAME = 'Configurar URL da Nuvem'.freeze
    LOGOUT_MENU_NAME = 'Desconectar Plugin'.freeze
    DIALOG_KEY = 'marcenaria-inteligente-cloud-sync'.freeze

    PREF_NAMESPACE = 'MarcenariaInteligenteCloudSync'.freeze
    PREF_BASE_URL = 'cloud_base_url'.freeze
    PREF_PLUGIN_TOKEN = 'plugin_token'.freeze
    PREF_PLUGIN_TOKEN_EXPIRES_AT = 'plugin_token_expires_at'.freeze
    PREF_PLUGIN_USER_NAME = 'plugin_user_name'.freeze
    PREF_PLUGIN_USER_EMAIL = 'plugin_user_email'.freeze
    PREF_SYNC_URL = 'plugin_sync_url'.freeze
    PREF_DASHBOARD_URL = 'plugin_dashboard_url'.freeze
    PREF_VERSION_URL = 'plugin_version_url'.freeze
    PREF_DOWNLOAD_URL = 'plugin_download_url'.freeze
    PREF_LAST_VERSION_CHECK_AT = 'plugin_last_version_check_at'.freeze
    PREF_LAST_AVAILABLE_VERSION = 'plugin_last_available_version'.freeze

    DEFAULT_CLOUD_URL = 'https://marcenaria-6utpjcua.manus.space'.freeze
    UPDATE_CHECK_INTERVAL_SECONDS = 6 * 60 * 60
    LEGACY_LOCAL_HOST_PATTERNS = [
      'localhost',
      '127.0.0.1',
      '0.0.0.0'
    ].freeze
    LEGACY_PREVIEW_HOST_SUFFIX = '.manus.computer'.freeze

    def open_connect_dialog(auto: false)
      base_url = ensure_base_url
      return unless base_url

      check_for_updates(silent: true)
      url = build_connect_url(base_url, auto: auto)
      dialog = ensure_dialog
      dialog.set_url(url)
      dialog.show
    rescue => error
      UI.messagebox("Não foi possível abrir a janela de conexão:\n\n#{error.class}: #{error.message}")
    end

    def sync_selected_project
      check_for_updates(silent: true)

      unless plugin_token_valid?
        UI.messagebox('O plugin ainda não está conectado à nuvem. Faça login primeiro para sincronizar o projeto automaticamente.')
        open_connect_dialog(auto: true)
        return
      end

      model = Sketchup.active_model
      entities = selected_exportable_entities(model)

      if entities.empty?
        UI.messagebox('Selecione pelo menos um componente ou grupo antes de sincronizar o projeto.')
        return
      end

      payload = build_payload(model, entities)
      send_payload_to_cloud(payload)
    rescue => error
      UI.messagebox("Falha ao sincronizar o projeto:\n\n#{error.class}: #{error.message}")
      puts error.backtrace.join("\n") if error.backtrace
    end

    def check_for_updates(force: false, silent: false)
      return nil unless force || update_check_due?

      previous_available_version = read_pref(PREF_LAST_AVAILABLE_VERSION, '').to_s
      info = fetch_plugin_version_info
      remember_version_check(info)
      notify_about_update(info, silent: silent, previous_available_version: previous_available_version)
      info
    rescue => error
      puts "[MarcenariaInteligente] Falha ao verificar atualização do plugin: #{error.class}: #{error.message}" unless silent
      nil
    end

    def configure_cloud_url
      current_value = stored_base_url || DEFAULT_CLOUD_URL
      prompts = ['URL da Central CNC']
      defaults = [current_value]
      result = UI.inputbox(prompts, defaults, 'Configurar URL da Nuvem')
      return unless result

      base_url = normalize_base_url(result[0])
      if base_url.nil? || base_url.empty?
        UI.messagebox('Informe uma URL válida para a plataforma web.')
        return
      end

      write_pref(PREF_BASE_URL, base_url)
      write_pref(PREF_SYNC_URL, "#{base_url}/api/plugin/cloud-sync")
      write_pref(PREF_DASHBOARD_URL, "#{base_url}/projetos")
      write_pref(PREF_VERSION_URL, "#{base_url}/api/plugin/version")
      write_pref(PREF_DOWNLOAD_URL, "#{base_url}/api/plugin/download")
      UI.messagebox("URL da nuvem salva com sucesso:\n\n#{base_url}")
    end

    def logout_plugin
      clear_plugin_session
      UI.messagebox('Sessão local do plugin removida. Na próxima sincronização, será necessário autenticar novamente.')
    end

    def handle_plugin_session(raw_payload)
      payload = parse_json_payload(raw_payload)
      unless payload.is_a?(Hash) && payload['ok']
        UI.messagebox('Não foi possível concluir a conexão do plugin com a plataforma web.')
        return
      end

      token = payload['token'].to_s
      expires_in_ms = payload['expiresInMs'].to_i
      sync_url_value = payload.dig('syncUrl') || payload.dig('endpoints', 'sync')
      dashboard_url_value = payload['dashboardUrl']
      version_url_value = payload.dig('plugin', 'versionUrl') || payload.dig('endpoints', 'version')
      download_url_value = payload.dig('plugin', 'downloadUrl') || payload.dig('endpoints', 'download')
      user_name = payload.dig('user', 'name')
      user_email = payload.dig('user', 'email')

      if token.empty?
        UI.messagebox('A plataforma retornou uma conexão sem token. Tente novamente.')
        return
      end

      write_pref(PREF_PLUGIN_TOKEN, token)
      write_pref(PREF_PLUGIN_TOKEN_EXPIRES_AT, (Time.now + (expires_in_ms / 1000.0)).utc.iso8601)
      write_pref(PREF_SYNC_URL, sync_url_value.to_s)
      write_pref(PREF_DASHBOARD_URL, dashboard_url_value.to_s)
      write_pref(PREF_VERSION_URL, version_url_value.to_s)
      write_pref(PREF_DOWNLOAD_URL, download_url_value.to_s)
      write_pref(PREF_PLUGIN_USER_NAME, user_name.to_s)
      write_pref(PREF_PLUGIN_USER_EMAIL, user_email.to_s)

      user_label = [user_name, user_email].map(&:to_s).reject(&:empty?).join(' • ')
      user_label = 'usuário autenticado' if user_label.empty?

      UI.messagebox("Plugin conectado com sucesso à nuvem.\n\nSessão ativa para: #{user_label}")
      check_for_updates(force: true, silent: false)
    rescue => error
      UI.messagebox("Falha ao processar a resposta de autenticação:\n\n#{error.class}: #{error.message}")
    end

    def close_dialog
      @dialog.close if @dialog && @dialog.visible?
    rescue
      nil
    end

    def ensure_dialog
      if @dialog && @dialog.visible?
        return @dialog
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: 'Marcenaria Inteligente Cloud Sync',
        preferences_key: DIALOG_KEY,
        scrollable: true,
        resizable: true,
        width: 980,
        height: 760,
        style: UI::HtmlDialog::STYLE_DIALOG
      )

      @dialog.add_action_callback('onPluginSession') do |_context, raw_payload|
        handle_plugin_session(raw_payload)
      end

      @dialog.add_action_callback('closeDialog') do |_context, _payload|
        close_dialog
      end

      @dialog
    end

    def selected_exportable_entities(model)
      model.selection.to_a.select do |entity|
        entity.is_a?(Sketchup::ComponentInstance) || entity.is_a?(Sketchup::Group)
      end
    end

    def send_payload_to_cloud(payload)
      url = sync_url
      token = plugin_token

      if url.to_s.empty? || token.to_s.empty?
        UI.messagebox('O plugin ainda não possui uma sessão válida de Cloud Sync. Faça login novamente.')
        open_connect_dialog(auto: true)
        return
      end

      request = Sketchup::Http::Request.new(url, Sketchup::Http::POST)
      request.headers = {
        'Content-Type' => 'application/json; charset=utf-8',
        'Accept' => 'application/json',
        'Authorization' => "Bearer #{token}",
        'X-Plugin-Version' => PLUGIN_VERSION,
        'X-Plugin-Source' => 'SketchUp'
      }
      request.body = JSON.generate(payload)

      model_name = payload.dig(:project, :name) || 'Projeto SketchUp'
      UI.messagebox("Enviando '#{model_name}' para a nuvem. Aguarde a confirmação do processamento automático.")

      request.start do |_req, response|
        handle_sync_response(response)
      end
    rescue => error
      UI.messagebox("Falha ao enviar o projeto para a nuvem:\n\n#{error.class}: #{error.message}")
    end

    def handle_sync_response(response)
      status_code = response.status_code.to_i
      payload = parse_json_payload(response.body)

      case status_code
      when 200, 201
        project_url = payload['projectUrl'] || payload['dashboardUrl'] || dashboard_url
        summary = payload['summary'] || {}
        board_count = summary['boardCount'] || 0
        utilization = summary['utilizationPct'] || 0
        unplaced = summary['unplacedParts'] || 0
        direct_sync = perform_direct_sync_write(payload)

        message_lines = [
          'Projeto sincronizado com sucesso.',
          '',
          "Chapas utilizadas: #{board_count}",
          "Aproveitamento: #{utilization}%",
          "Peças não alocadas: #{unplaced}"
        ]

        if direct_sync[:configured]
          message_lines << ''
          message_lines << 'Saída direta:'
          message_lines << direct_sync[:message]
        end

        UI.messagebox(message_lines.join("\n"))
        UI.openURL(project_url) if project_url && !project_url.empty?
      when 401
        clear_plugin_session
        UI.messagebox('Sua sessão do plugin expirou. Faça login novamente para continuar a sincronização.')
        open_connect_dialog(auto: true)
      when 412
        project_url = payload['projectUrl'] || dashboard_url
        message = payload['message'] || 'O projeto foi recebido, mas não existe máquina ativa para processar automaticamente.'
        UI.messagebox(message)
        UI.openURL(project_url) if project_url && !project_url.empty?
      else
        message = payload['message'] || "O servidor respondeu com o código HTTP #{status_code}."
        UI.messagebox("Falha ao sincronizar o projeto:\n\n#{message}")
      end
    rescue => error
      UI.messagebox("Falha ao interpretar a resposta do servidor:\n\n#{error.class}: #{error.message}")
    end

    def perform_direct_sync_write(payload)
      info = extract_direct_sync_info(payload)
      return { configured: false, success: false, message: '' } unless info[:configured]

      unless info[:enabled]
        message = info[:message].to_s.strip
        message = 'A saída direta está desativada no perfil ativo. Os arquivos continuam disponíveis no painel da Central CNC.' if message.empty?
        return { configured: true, success: false, message: message }
      end

      if info[:destination_path].empty? || info[:files].empty?
        message = info[:message].to_s.strip
        message = 'A nuvem processou o projeto, mas não devolveu caminho ou arquivos suficientes para a gravação automática.' if message.empty?
        return { configured: true, success: false, message: message }
      end

      written_files = []

      info[:files].each do |artifact|
        next if artifact[:url].to_s.strip.empty?

        file_content = download_binary_file(artifact[:url], plugin_token)
        written_files << write_direct_output_file(info[:destination_path], artifact[:file_name], file_content)
      end

      if written_files.empty?
        raise 'Nenhum arquivo utilizável foi retornado pela nuvem para a saída direta.'
      end

      primary_file = written_files.first
      extra_files = written_files.drop(1)

      message_lines = [
        'Arquivos do projeto salvos automaticamente em:',
        info[:destination_path],
        '',
        "Principal: #{primary_file}"
      ]

      unless extra_files.empty?
        message_lines << 'Arquivos adicionais:'
        extra_files.each do |path|
          message_lines << path
        end
      end

      {
        configured: true,
        success: true,
        message: message_lines.join("\n")
      }
    rescue => error
      fallback = info && info[:message].to_s.strip
      message = "Não foi possível gravar os arquivos automaticamente na pasta configurada.\n#{error.class}: #{error.message}"
      message = "#{message}\n\nInstrução da nuvem: #{fallback}" unless fallback.to_s.empty?
      {
        configured: true,
        success: false,
        message: message
      }
    end

    def extract_direct_sync_info(payload)
      direct_sync = payload['directSync'].is_a?(Hash) ? payload['directSync'] : {}
      artifacts = payload['artifacts'].is_a?(Hash) ? payload['artifacts'] : {}
      direct_output = artifacts['directOutput'].is_a?(Hash) ? artifacts['directOutput'] : {}
      gcode = artifacts['gcode'].is_a?(Hash) ? artifacts['gcode'] : {}
      production_report = artifacts['productionReport'].is_a?(Hash) ? artifacts['productionReport'] : {}
      labels = artifacts['labels'].is_a?(Hash) ? artifacts['labels'] : {}

      configured = direct_sync.key?('enabled') || !direct_output.empty?
      enabled_value = direct_sync.key?('enabled') ? direct_sync['enabled'] : direct_output['enabled']

      files = []
      files << build_direct_output_asset(
        gcode['url'] || direct_sync['gcodeUrl'],
        direct_sync['fileName'] || direct_output['fileName'] || gcode['fileName'] || file_name_from_url(gcode['url'] || direct_sync['gcodeUrl']),
        'gcode'
      )
      files << build_direct_output_asset(
        production_report['url'],
        production_report['fileName'] || file_name_from_url(production_report['url']),
        'production_report'
      )
      files << build_direct_output_asset(
        labels['url'],
        labels['fileName'] || file_name_from_url(labels['url']),
        'labels'
      )
      files = files.compact

      {
        configured: configured,
        enabled: truthy_value?(enabled_value),
        transport: (direct_sync['transport'] || direct_output['transport']).to_s,
        destination_path: normalize_output_directory(direct_sync['destinationPath'] || direct_sync['path'] || direct_output['path']),
        file_name: sanitize_output_file_name(direct_sync['fileName'] || direct_output['fileName'] || gcode['fileName'] || file_name_from_url(direct_sync['gcodeUrl'] || gcode['url'])),
        gcode_url: (direct_sync['gcodeUrl'] || gcode['url']).to_s.strip,
        status: (direct_sync['status'] || direct_output['status']).to_s,
        message: (direct_sync['message'] || direct_output['message']).to_s,
        files: files
      }
    end

    def build_direct_output_asset(url, file_name, kind)
      normalized_url = url.to_s.strip
      return nil if normalized_url.empty?

      {
        url: normalized_url,
        file_name: sanitize_output_file_name(file_name),
        kind: kind.to_s
      }
    end

    def truthy_value?(value)
      return value if value == true || value == false

      %w[1 true yes on].include?(value.to_s.strip.downcase)
    end

    def normalize_output_directory(value)
      raw = value.to_s.strip
      return '' if raw.empty?

      raw.gsub('/', '\\').sub(/[\\\/]+$/, '')
    end

    def sanitize_output_file_name(value)
      file_name = value.to_s.strip
      file_name = 'programa.nc' if file_name.empty?
      file_name = file_name.gsub(/[<>:"\\\/|?*]+/, '-')
      file_name += '.nc' unless file_name =~ /\.[a-z0-9]{2,5}$/i
      file_name
    end

    def file_name_from_url(value)
      raw = value.to_s.strip
      return '' if raw.empty?

      uri = URI.parse(raw)
      File.basename(uri.path.to_s)
    rescue URI::InvalidURIError
      ''
    end

    def download_binary_file(url, bearer_token = nil, redirects_left = 4)
      raise 'A URL do arquivo retornada pela nuvem é inválida ou está vazia.' if url.to_s.strip.empty?

      uri = URI.parse(url)
      request = Net::HTTP::Get.new(uri.request_uri.empty? ? '/' : uri.request_uri)
      request['Accept'] = '*/*'
      request['Authorization'] = "Bearer #{bearer_token}" unless bearer_token.to_s.strip.empty?

      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = uri.scheme == 'https'
      http.open_timeout = 20
      http.read_timeout = 60

      response = http.start { |client| client.request(request) }

      case response
      when Net::HTTPSuccess
        response.body.to_s
      when Net::HTTPRedirection
        raise 'Muitas redireções ao baixar os arquivos hospedados.' if redirects_left <= 0

        next_url = URI.join(url, response['location'].to_s).to_s
        download_binary_file(next_url, bearer_token, redirects_left - 1)
      else
        raise "Download do arquivo falhou com HTTP #{response.code}."
      end
    rescue URI::InvalidURIError
      raise 'A URL do arquivo retornada pela nuvem é inválida.'
    end

    def fetch_plugin_version_info
      endpoint = version_url
      raise 'A URL de versão do plugin não está configurada.' if endpoint.to_s.strip.empty?

      uri = URI.parse(endpoint)
      uri.query = [uri.query, URI.encode_www_form(currentVersion: PLUGIN_VERSION)].compact.reject(&:empty?).join('&')
      request = Net::HTTP::Get.new(uri.request_uri.empty? ? '/' : uri.request_uri)
      request['Accept'] = 'application/json'
      request['X-Plugin-Version'] = PLUGIN_VERSION
      request['Authorization'] = "Bearer #{plugin_token}" if plugin_token_valid?

      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = uri.scheme == 'https'
      http.open_timeout = 15
      http.read_timeout = 30

      response = http.start { |client| client.request(request) }
      body = parse_json_payload(response.body)
      raise "Falha ao consultar a versão publicada do plugin (HTTP #{response.code})." unless response.is_a?(Net::HTTPSuccess)

      body
    rescue URI::InvalidURIError
      raise 'A URL de verificação de versão do plugin é inválida.'
    end

    def remember_version_check(info)
      write_pref(PREF_LAST_VERSION_CHECK_AT, Time.now.utc.iso8601)

      published_version = info.dig('plugin', 'version').to_s
      available = truthy_value?(info.dig('client', 'updateAvailable'))
      write_pref(PREF_LAST_AVAILABLE_VERSION, available ? published_version : '')
    end

    def notify_about_update(info, silent: false, previous_available_version: '')
      published_version = info.dig('plugin', 'version').to_s
      update_available = truthy_value?(info.dig('client', 'updateAvailable'))
      must_update = truthy_value?(info.dig('client', 'mustUpdate'))
      download = info.dig('plugin', 'downloadUrl').to_s
      notes = Array(info.dig('plugin', 'releaseNotes')).map(&:to_s).reject(&:empty?)

      if update_available
        return if silent && previous_available_version == published_version

        title = must_update ? 'Atualização obrigatória disponível' : 'Nova versão do plugin disponível'
        message_lines = [
          "#{title}: #{published_version}",
          "Versão instalada: #{PLUGIN_VERSION}",
          '',
          'O SketchUp pode continuar funcionando, mas recomendamos atualizar antes da próxima produção.'
        ]
        message_lines[3] = 'Esta versão do plugin ficou abaixo do mínimo suportado e precisa ser atualizada.' if must_update

        unless notes.empty?
          message_lines << ''
          message_lines << 'Novidades desta versão:'
          notes.each do |note|
            message_lines << "- #{note}"
          end
        end

        install_now = prompt_yes_no(message_lines.join("\n\n"))
        if install_now
          install_plugin_update(download, published_version)
        elsif !silent && !download.to_s.empty?
          UI.openURL(download)
        end
      elsif !silent
        UI.messagebox("O plugin já está atualizado na versão #{PLUGIN_VERSION}.")
      end
    end

    def prompt_yes_no(message)
      if defined?(MB_YESNO) && defined?(IDYES)
        UI.messagebox("#{message}\n\nDeseja atualizar agora?", MB_YESNO) == IDYES
      else
        UI.messagebox(message)
        false
      end
    end

    def install_plugin_update(download_url_value, published_version)
      if download_url_value.to_s.strip.empty?
        UI.messagebox('A plataforma informou uma nova versão, mas não retornou a URL de download do plugin.')
        return false
      end

      source = download_binary_file(download_url_value, plugin_token_valid? ? plugin_token : nil)
      backup_path = "#{__FILE__}.backup-#{Time.now.strftime('%Y%m%d%H%M%S')}"
      FileUtils.cp(__FILE__, backup_path)
      File.binwrite(__FILE__, source)
      write_pref(PREF_LAST_AVAILABLE_VERSION, '')

      UI.messagebox(
        "Plugin atualizado com sucesso para a versão #{published_version}.\n\n" \
        "Backup salvo em:\n#{backup_path}\n\n" \
        "Feche e abra o SketchUp novamente para carregar a nova versão."
      )
      true
    rescue => error
      manual_path = save_update_package_to_downloads(source, published_version)
      message_lines = [
        "Não foi possível substituir automaticamente o arquivo do plugin em:\n#{__FILE__}",
        '',
        "Motivo: #{error.class}: #{error.message}"
      ]

      if manual_path
        message_lines << ''
        message_lines << 'A nova versão foi baixada para:'
        message_lines << manual_path
        message_lines << ''
        message_lines << 'Feche o SketchUp e copie esse arquivo para a pasta Plugins para concluir a atualização.'
      else
        message_lines << ''
        message_lines << 'Abra o link de download informado pela plataforma e substitua manualmente o arquivo do plugin.'
        UI.openURL(download_url_value)
      end

      UI.messagebox(message_lines.join("\n"))
      false
    end

    def save_update_package_to_downloads(source, published_version)
      return nil if source.to_s.empty?

      target_directory = default_downloads_directory
      FileUtils.mkdir_p(target_directory) unless Dir.exist?(target_directory)
      target_path = File.join(target_directory, "sketchup_exportar_plano_de_corte-v#{published_version}.rb")
      File.binwrite(target_path, source)
      target_path
    rescue
      nil
    end

    def default_downloads_directory
      home = ENV['USERPROFILE'].to_s.strip
      home = ENV['HOME'].to_s.strip if home.empty?
      return File.join(home, 'Downloads') unless home.empty?

      Dir.tmpdir
    end

    def write_direct_output_file(directory, file_name, content)
      normalized_directory = normalize_output_directory(directory)
      raise 'O caminho da pasta de saída direta está vazio.' if normalized_directory.empty?

      FileUtils.mkdir_p(normalized_directory) unless Dir.exist?(normalized_directory)
      target_file = File.join(normalized_directory, sanitize_output_file_name(file_name))
      File.open(target_file, 'wb') { |file| file.write(content.to_s) }
      target_file
    end

    def build_payload(model, entities)
      parts = entities.each_with_index.map do |entity, index|
        build_part(entity, index + 1)
      end

      {
        tenantId: 'tenant-marcenaria-demo',
        source: 'sketchup',
        pluginVersion: PLUGIN_VERSION,
        sketchUpVersion: Sketchup.version.to_s,
        project: {
          externalProjectId: build_external_project_id(model),
          name: project_name(model),
          customerName: nil,
          designerName: nil,
          unit: 'mm',
          notes: 'Projeto sincronizado automaticamente pelo plugin SketchUp via Cloud Sync.'
        },
        parts: parts,
        materials: build_materials(parts),
        metadata: {
          exportedAt: Time.now.utc.iso8601,
          machinePostProcessor: nil,
          hash: nil,
          extra: {
            selectionMode: 'selected-components',
            originFile: origin_file_name(model),
            pluginAuthMode: 'bearer-token',
            syncMode: 'cloud-sync'
          }
        }
      }
    end

    def build_part(entity, sequence)
      dimensions = extract_dimensions_mm(entity)
      name = entity_name(entity, sequence)
      material_code = extract_material_code(entity)
      origin = entity.transformation.origin
      part_id = format('P-%03d', sequence)

      {
        partId: part_id,
        name: name,
        sku: nil,
        parentAssembly: nil,
        materialCode: material_code,
        lengthMm: dimensions[:length_mm],
        widthMm: dimensions[:width_mm],
        thicknessMm: dimensions[:thickness_mm],
        quantity: 1,
        canRotateInNesting: true,
        grainDirectionRequired: false,
        grainDirection: 'none',
        frontFace: 'top',
        partType: entity.is_a?(Sketchup::Group) ? 'group' : 'component',
        label: name,
        barcode: "#{part_id}-#{dimensions[:length_mm]}x#{dimensions[:width_mm]}x#{dimensions[:thickness_mm]}",
        position: {
          x: to_mm_value(origin.x),
          y: to_mm_value(origin.y),
          z: to_mm_value(origin.z),
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0
        },
        edgeBanding: empty_edge_banding,
        machining: [],
        attributes: {
          sketchupEntityType: entity.class.name,
          sketchupEntityId: entity.entityID.to_s,
          definitionName: definition_name(entity)
        }
      }
    end

    def build_materials(parts)
      parts
        .map { |part| [part[:materialCode], part[:thicknessMm]] }
        .uniq
        .map do |material_code, thickness_mm|
          {
            code: material_code,
            name: material_code,
            category: 'mdf',
            thicknessMm: thickness_mm,
            defaultBoardLengthMm: 2750,
            defaultBoardWidthMm: 1830,
            grainDirectionRequired: false,
            color: nil,
            supplier: nil
          }
        end
    end

    def extract_dimensions_mm(entity)
      local_bounds = local_bounds_for(entity)
      x_size = local_axis_size(local_bounds, :x) * axis_scale(entity.transformation.xaxis)
      y_size = local_axis_size(local_bounds, :y) * axis_scale(entity.transformation.yaxis)
      z_size = local_axis_size(local_bounds, :z) * axis_scale(entity.transformation.zaxis)

      {
        length_mm: round_mm(x_size),
        width_mm: round_mm(y_size),
        thickness_mm: round_mm(z_size)
      }
    end

    def local_bounds_for(entity)
      if entity.respond_to?(:definition) && entity.definition
        entity.definition.bounds
      else
        entity.bounds
      end
    end

    def local_axis_size(bounds, axis)
      case axis
      when :x
        bounds.max.x - bounds.min.x
      when :y
        bounds.max.y - bounds.min.y
      when :z
        bounds.max.z - bounds.min.z
      else
        0
      end
    end

    def axis_scale(vector)
      vector.length.to_f.abs
    end

    def to_mm_value(length_value)
      if length_value.respond_to?(:to_mm)
        length_value.to_mm.to_f
      else
        length_value.to_f
      end
    end

    def round_mm(length_value)
      to_mm_value(length_value).round(3)
    end

    def entity_name(entity, sequence)
      return entity.name unless entity.name.to_s.strip.empty?

      definition = definition_name(entity)
      return definition unless definition.to_s.strip.empty?

      format('Peca %03d', sequence)
    end

    def definition_name(entity)
      return '' unless entity.respond_to?(:definition) && entity.definition

      entity.definition.name.to_s
    end

    def extract_material_code(entity)
      material_name = nil

      if entity.respond_to?(:material) && entity.material
        material_name = entity.material.display_name
      elsif entity.respond_to?(:definition) && entity.definition.respond_to?(:material) && entity.definition.material
        material_name = entity.definition.material.display_name
      end

      material_name = material_name.to_s.strip
      material_name = 'SEM_MATERIAL' if material_name.empty?
      material_name.upcase.gsub(/[^A-Z0-9]+/, '-').gsub(/^-|-$/, '')
    end

    def empty_edge_banding
      {
        top: empty_edge_side,
        bottom: empty_edge_side,
        left: empty_edge_side,
        right: empty_edge_side
      }
    end

    def empty_edge_side
      {
        enabled: false,
        materialCode: nil,
        thicknessMm: 0,
        widthMm: 0,
        color: nil
      }
    end

    def project_name(model)
      title = model.title.to_s.strip
      return title unless title.empty?

      path = model.path.to_s.strip
      return File.basename(path, '.*') unless path.empty?

      'Projeto SketchUp'
    end

    def origin_file_name(model)
      path = model.path.to_s.strip
      return File.basename(path) unless path.empty?

      'modelo_sem_nome.skp'
    end

    def build_external_project_id(model)
      base_name = project_name(model)
      slug = base_name.downcase.gsub(/[^a-z0-9]+/, '-').gsub(/^-|-$/, '')
      slug = 'projeto-sketchup' if slug.empty?
      "skp-#{slug}"
    end

    def build_connect_url(base_url, auto: false)
      suffix = auto ? '?auto=1' : ''
      "#{base_url}/plugin/connect#{suffix}"
    end

    def ensure_base_url
      base_url = stored_base_url
      return base_url unless base_url.to_s.empty?

      current_value = DEFAULT_CLOUD_URL
      prompts = ['URL da Central CNC']
      defaults = [current_value]
      result = UI.inputbox(prompts, defaults, 'Conectar Cloud Sync')
      return nil unless result

      base_url = normalize_base_url(result[0])
      write_pref(PREF_BASE_URL, base_url)
      write_pref(PREF_VERSION_URL, "#{base_url}/api/plugin/version")
      write_pref(PREF_DOWNLOAD_URL, "#{base_url}/api/plugin/download")
      base_url
    end

    def normalize_base_url(value)
      raw = value.to_s.strip
      return nil if raw.empty?

      raw = "https://#{raw}" unless raw =~ %r{^https?://}i
      raw.gsub(%r{/+$}, '')
    end

    def uses_legacy_local_host?(value)
      normalized = normalize_base_url(value)
      return false if normalized.nil? || normalized.empty?

      uri = URI.parse(normalized)
      host = uri.host.to_s.downcase
      LEGACY_LOCAL_HOST_PATTERNS.include?(host)
    rescue URI::InvalidURIError
      false
    end

    def uses_legacy_preview_host?(value)
      normalized = normalize_base_url(value)
      return false if normalized.nil? || normalized.empty?

      uri = URI.parse(normalized)
      host = uri.host.to_s.downcase
      host.end_with?(LEGACY_PREVIEW_HOST_SUFFIX)
    rescue URI::InvalidURIError
      false
    end

    def current_public_base_url
      stored_value = normalize_base_url(read_pref(PREF_BASE_URL, DEFAULT_CLOUD_URL))
      return DEFAULT_CLOUD_URL if uses_legacy_local_host?(stored_value) || uses_legacy_preview_host?(stored_value)

      stored_value || DEFAULT_CLOUD_URL
    end

    def migrate_legacy_cloud_preferences
      base_url = normalize_base_url(read_pref(PREF_BASE_URL, DEFAULT_CLOUD_URL))
      sync = read_pref(PREF_SYNC_URL, '').to_s.strip
      dashboard = read_pref(PREF_DASHBOARD_URL, '').to_s.strip
      version = read_pref(PREF_VERSION_URL, '').to_s.strip
      download = read_pref(PREF_DOWNLOAD_URL, '').to_s.strip
      changed = false

      if uses_legacy_local_host?(base_url) || uses_legacy_preview_host?(base_url)
        write_pref(PREF_BASE_URL, DEFAULT_CLOUD_URL)
        changed = true
      end

      if uses_legacy_local_host?(sync) || uses_legacy_preview_host?(sync)
        write_pref(PREF_SYNC_URL, "#{DEFAULT_CLOUD_URL}/api/plugin/cloud-sync")
        changed = true
      end

      if uses_legacy_local_host?(dashboard) || uses_legacy_preview_host?(dashboard)
        write_pref(PREF_DASHBOARD_URL, "#{DEFAULT_CLOUD_URL}/projetos")
        changed = true
      end

      if version.empty? || uses_legacy_local_host?(version) || uses_legacy_preview_host?(version)
        write_pref(PREF_VERSION_URL, "#{DEFAULT_CLOUD_URL}/api/plugin/version")
        changed = true
      end

      if download.empty? || uses_legacy_local_host?(download) || uses_legacy_preview_host?(download)
        write_pref(PREF_DOWNLOAD_URL, "#{DEFAULT_CLOUD_URL}/api/plugin/download")
        changed = true
      end

      changed
    end

    def stored_base_url
      migrate_legacy_cloud_preferences
      current_public_base_url
    end

    def plugin_token
      read_pref(PREF_PLUGIN_TOKEN, '')
    end

    def plugin_token_valid?
      token = plugin_token.to_s
      expires_at = read_pref(PREF_PLUGIN_TOKEN_EXPIRES_AT, '').to_s
      return false if token.empty? || expires_at.empty?

      Time.iso8601(expires_at) > Time.now
    rescue
      false
    end

    def sync_url
      migrate_legacy_cloud_preferences
      stored = read_pref(PREF_SYNC_URL, '').to_s.strip
      return stored unless stored.empty? || uses_legacy_local_host?(stored) || uses_legacy_preview_host?(stored)

      base_url = stored_base_url
      return '' if base_url.to_s.empty?

      "#{base_url}/api/plugin/cloud-sync"
    end

    def dashboard_url
      migrate_legacy_cloud_preferences
      stored = read_pref(PREF_DASHBOARD_URL, '').to_s.strip
      return stored unless stored.empty? || uses_legacy_local_host?(stored) || uses_legacy_preview_host?(stored)

      base_url = stored_base_url
      return '' if base_url.to_s.empty?

      "#{base_url}/projetos"
    end

    def version_url
      migrate_legacy_cloud_preferences
      stored = read_pref(PREF_VERSION_URL, '').to_s.strip
      return stored unless stored.empty? || uses_legacy_local_host?(stored) || uses_legacy_preview_host?(stored)

      base_url = stored_base_url
      return '' if base_url.to_s.empty?

      "#{base_url}/api/plugin/version"
    end

    def download_url
      migrate_legacy_cloud_preferences
      stored = read_pref(PREF_DOWNLOAD_URL, '').to_s.strip
      return stored unless stored.empty? || uses_legacy_local_host?(stored) || uses_legacy_preview_host?(stored)

      base_url = stored_base_url
      return '' if base_url.to_s.empty?

      "#{base_url}/api/plugin/download"
    end

    def update_check_due?
      last_check = read_pref(PREF_LAST_VERSION_CHECK_AT, '').to_s.strip
      return true if last_check.empty?

      (Time.now - Time.iso8601(last_check)) >= UPDATE_CHECK_INTERVAL_SECONDS
    rescue
      true
    end

    def clear_plugin_session
      write_pref(PREF_PLUGIN_TOKEN, '')
      write_pref(PREF_PLUGIN_TOKEN_EXPIRES_AT, '')
      write_pref(PREF_PLUGIN_USER_NAME, '')
      write_pref(PREF_PLUGIN_USER_EMAIL, '')
      write_pref(PREF_SYNC_URL, '')
      write_pref(PREF_DASHBOARD_URL, '')
      write_pref(PREF_VERSION_URL, '')
      write_pref(PREF_DOWNLOAD_URL, '')
    end

    def parse_json_payload(raw_payload)
      return raw_payload if raw_payload.is_a?(Hash)
      return {} if raw_payload.nil? || raw_payload.to_s.strip.empty?

      JSON.parse(raw_payload.to_s)
    rescue JSON::ParserError
      {}
    end

    def compare_versions(left, right)
      left_parts = left.to_s.scan(/\d+/).map(&:to_i)
      right_parts = right.to_s.scan(/\d+/).map(&:to_i)
      max_length = [left_parts.length, right_parts.length].max

      (0...max_length).each do |index|
        left_value = left_parts[index] || 0
        right_value = right_parts[index] || 0
        return 1 if left_value > right_value
        return -1 if left_value < right_value
      end

      0
    end

    def read_pref(key, default_value = nil)
      Sketchup.read_default(PREF_NAMESPACE, key, default_value)
    end

    def write_pref(key, value)
      Sketchup.write_default(PREF_NAMESPACE, key, value)
    end

    def queue_startup_update_check
      return if @startup_update_check_scheduled

      @startup_update_check_scheduled = true
      UI.start_timer(2.0, false) do
        @startup_update_check_scheduled = false
        check_for_updates(silent: true)
      end
    rescue => error
      @startup_update_check_scheduled = false
      puts "[MarcenariaInteligente] Falha ao agendar verificação automática de atualização: #{error.class}: #{error.message}"
    end

    unless file_loaded?(__FILE__)
      root_menu = UI.menu('Extensions').add_submenu(ROOT_MENU_NAME)
      root_menu.add_item(CONNECT_MENU_NAME) { open_connect_dialog(auto: false) }
      root_menu.add_item(SYNC_MENU_NAME) { sync_selected_project }
      root_menu.add_item(CHECK_UPDATES_MENU_NAME) { check_for_updates(force: true, silent: false) }
      root_menu.add_separator
      root_menu.add_item(CONFIG_MENU_NAME) { configure_cloud_url }
      root_menu.add_item(LOGOUT_MENU_NAME) { logout_plugin }

      queue_startup_update_check
      file_loaded(__FILE__)
    end
  end
end
