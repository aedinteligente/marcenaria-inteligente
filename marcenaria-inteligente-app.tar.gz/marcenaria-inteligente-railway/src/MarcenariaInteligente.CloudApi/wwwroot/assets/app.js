const STORAGE_KEY = 'marcenaria-inteligente-enterprise-session';
const DEFAULT_LOGIN = {
  email: '',
  password: ''
};

const state = {
  route: normalizeRoute(window.location.pathname || '/'),
  dashboardToken: '',
  user: null,
  pluginSession: null,
  pluginEvents: [],
  lastSyncResult: null,
  projects: [],
  projectDetails: {},
  users: [],
  machine: null,
  tools: [],
  loading: false,
  menuProjectId: null,
  pendingProjectName: '',
  pendingCustomerName: '',
  chartMode: 'clientes',
  nestingMaterialFilter: 'all',
  nestingBoardIndex: 0
};

const app = document.getElementById('app');

function normalizeRoute(path) {
  if (!path || path === '/') return '/';
  const cleaned = String(path).replace(/\/+$/, '');
  return cleaned || '/';
}

function parseJsonSafe(value, fallback = null) {
  if (value == null) return fallback;
  if (typeof value === 'object') return value;
  try {
    return JSON.parse(String(value));
  } catch {
    return fallback;
  }
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function toHtml(value) {
  return escapeHtml(value).replace(/\n/g, '<br />');
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short'
  }).format(date);
}

function formatNumber(value) {
  return new Intl.NumberFormat('pt-BR').format(Number(value || 0));
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(1).replace('.', ',')}%`;
}

function slugCode(value) {
  const raw = String(value || '').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toUpperCase();
  return raw || 'PROJETO';
}

function statusLabel(status) {
  return status === 'em_producao' ? 'Em Produção' : 'Rascunho';
}

function statusBadge(status) {
  return status === 'em_producao'
    ? 'bg-red-50 text-red-700 ring-1 ring-inset ring-red-200'
    : 'bg-slate-100 text-slate-700 ring-1 ring-inset ring-slate-200';
}

function roleLabel(role) {
  if (role === 'admin') return 'Administrador';
  if (role === 'programador_cnc') return 'Programador CNC';
  if (role === 'operador_cnc') return 'Operador CNC';
  return role || 'Usuário';
}

function routeTitle(route) {
  if (route === '/') return 'Acesso à Plataforma';
  if (route === '/home') return 'Visão Geral';
  if (route === '/projetos') return 'Projetos';
  if (route.startsWith('/projetos/')) return 'Engenharia do Projeto';
  if (route === '/equipe') return 'Gestão de Equipe';
  if (route === '/maquina') return 'Máquina CNC';
  if (route === '/ferramentas') return 'Ferramentas e ATC';
  return 'Dashboard';
}

function isSketchUpHost() {
  return typeof window.sketchup === 'object' && window.sketchup !== null;
}

function callSketchUpBridge(names, payload) {
  if (!isSketchUpHost()) return false;
  const serialized = typeof payload === 'string' ? payload : JSON.stringify(payload || {});
  const candidates = Array.isArray(names) ? names : [names];

  for (const name of candidates) {
    const callback = window.sketchup?.[name];
    if (typeof callback === 'function') {
      callback(serialized);
      return true;
    }
  }

  return false;
}

function pushNotification(type, title, message) {
  const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  state.pluginEvents = state.pluginEvents.slice(0, 10);
  state.notifications = [
    {
      id,
      type,
      title,
      message,
      createdAt: new Date().toISOString()
    },
    ...(state.notifications || [])
  ].slice(0, 4);
  render();
}

function clearNotifications() {
  state.notifications = [];
  render();
}

function saveSession(response) {
  state.dashboardToken = response.dashboardToken;
  state.user = response.user;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
      dashboardToken: state.dashboardToken,
      user: state.user
    }));
  } catch {
    // storage indisponível
  }
}

function clearSession() {
  state.dashboardToken = '';
  state.user = null;
  state.pluginSession = null;
  state.lastSyncResult = null;
  state.projects = [];
  state.projectDetails = {};
  state.users = [];
  state.machine = null;
  state.tools = [];
  state.menuProjectId = null;
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // storage indisponível
  }
}

function restoreSession() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    state.dashboardToken = parsed.dashboardToken || '';
    state.user = parsed.user || null;
  } catch {
    clearSession();
  }
}

async function apiFetch(url, options = {}) {
  const headers = new Headers(options.headers || {});

  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }

  if (!headers.has('Authorization') && state.dashboardToken) {
    headers.set('Authorization', `Bearer ${state.dashboardToken}`);
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  const raw = await response.text();
  const payload = raw ? parseJsonSafe(raw, { message: raw }) : null;

  if (!response.ok) {
    throw new Error(payload?.message || payload?.title || `Falha na requisição (${response.status}).`);
  }

  return payload;
}

function navigate(path, options = {}) {
  const normalized = normalizeRoute(path);
  state.route = normalized;
  state.menuProjectId = null;

  if (options.replace) {
    window.history.replaceState({}, '', normalized);
  } else if (window.location.pathname !== normalized) {
    window.history.pushState({}, '', normalized);
  }

  render();
  hydrateRoute().catch(error => {
    pushNotification('error', 'Falha ao carregar a tela', error.message || 'Erro inesperado.');
  });
}

function ensureAuthenticatedRoute() {
  if (!state.dashboardToken && state.route !== '/') {
    navigate('/', { replace: true });
    return false;
  }

  if (state.dashboardToken && state.route === '/') {
    navigate('/home', { replace: true });
    return false;
  }

  return true;
}

function deriveMetrics() {
  const totalProjects = state.projects.length;
  const clients = new Set(state.projects.map(project => project.customerName || 'Sem cliente')).size;
  const inProduction = state.projects.filter(project => project.status === 'em_producao').length;
  const licenses = Math.max(1, (state.users || []).filter(user => user.isActive !== false).length || 3);
  const totalPieces = state.projects.reduce((sum, project) => sum + Number(project.summary?.partCount || 0), 0);
  const boards = state.projects.reduce((sum, project) => sum + Number(project.summary?.boardCount || 0), 0);

  return {
    totalProjects,
    clients,
    inProduction,
    licenses,
    totalPieces,
    boards
  };
}

function groupProjectsByCustomer() {
  const map = new Map();
  for (const project of state.projects) {
    const name = project.customerName || 'Sem cliente';
    map.set(name, (map.get(name) || 0) + 1);
  }
  return Array.from(map.entries())
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);
}

function customerColor(index) {
  const colors = ['#dc2626', '#ef4444', '#f87171', '#fb7185', '#fecaca', '#991b1b', '#be123c', '#e11d48'];
  return colors[index % colors.length];
}

function formatNestingMm(value) {
  return Number(value || 0).toFixed(1);
}

function normalizeMaterialName(value) {
  const raw = String(value ?? '').trim();
  return raw || 'Material não informado';
}

function buildSheetCaption(materials) {
  const unique = Array.from(new Set((materials || []).map(normalizeMaterialName)));
  if (!unique.length) return 'Material não informado';
  return unique.length === 1 ? unique[0] : `${unique[0]} + ${unique.length - 1} material(is)`;
}

function projectFromRoute() {
  if (!state.route.startsWith('/projetos/')) return null;
  const slug = state.route.replace('/projetos/', '').trim();
  return state.projects.find(project => project.slug === slug) || state.projectDetails[slug]?.project || null;
}

function normalizeProjectPart(part, index = 0) {
  const edgeBanding = part?.edgeBanding || {};
  const machining = part?.machining || {};
  return {
    item: Number(part?.item || index + 1),
    reference: part?.reference || part?.partId || `REF-${String(index + 1).padStart(3, '0')}`,
    code: part?.code || part?.sku || part?.partId || `${slugCode(part?.name || 'PECA').slice(0, 6)}-${String(index + 1).padStart(3, '0')}`,
    quantity: Number(part?.quantity || 1),
    description: part?.description || part?.name || `Peça ${index + 1}`,
    material: part?.materialName || part?.material || part?.materialCode || 'Material não informado',
    lengthMm: Number(part?.lengthMm || part?.length || 0),
    widthMm: Number(part?.widthMm || part?.width || 0),
    thicknessMm: Number(part?.thicknessMm || part?.thickness || 0),
    cnc: !!machining?.hasCnc || Number(machining?.totalOperations || 0) > 0,
    holes: Number(machining?.drillOperationCount || part?.holes || 0),
    edgeBanding: {
      top: !!edgeBanding?.top,
      right: !!edgeBanding?.right,
      bottom: !!edgeBanding?.bottom,
      left: !!edgeBanding?.left,
      visualCode: edgeBanding?.visualCode || '----'
    },
    raw: part
  };
}

function createSyntheticParts(project) {
  const cacheKey = project.slug || project.projectId;
  if (state.projectDetails[cacheKey]?.parts?.length) {
    return state.projectDetails[cacheKey].parts;
  }

  if (Array.isArray(project?.parts) && project.parts.length) {
    const normalized = project.parts.map((part, index) => normalizeProjectPart(part, index));
    state.projectDetails[cacheKey] = {
      ...(state.projectDetails[cacheKey] || {}),
      project,
      parts: normalized
    };
    return normalized;
  }

  const materials = ['Branco TX 15', 'Carvalho Hanover 18', 'Cinza Cristal 15', 'MDF Cru 18'];
  const partCount = Math.max(4, Math.min(Number(project.summary?.partCount || 8), 18));
  const machiningCount = Number(project.summary?.machiningOperationCount || 0);
  const parts = [];

  for (let index = 0; index < partCount; index += 1) {
    const length = 300 + ((index * 97) % 900);
    const width = 120 + ((index * 53) % 480);
    const thickness = [15, 18, 25][index % 3];
    const hasCnc = index < machiningCount || index % 3 === 0;
    const edgePattern = index % 4;
    parts.push({
      item: index + 1,
      reference: `REF-${String(index + 1).padStart(3, '0')}`,
      code: `${slugCode(project.name).slice(0, 6)}-${String(index + 1).padStart(3, '0')}`,
      quantity: index % 5 === 0 ? 2 : 1,
      description: ['Lateral', 'Base', 'Travessa', 'Prateleira', 'Porta'][index % 5] + ` ${index + 1}`,
      material: materials[index % materials.length],
      lengthMm: length,
      widthMm: width,
      thicknessMm: thickness,
      cnc: hasCnc,
      holes: hasCnc ? ((index % 4) + 1) : 0,
      edgeBanding: {
        top: edgePattern === 0 || edgePattern === 2,
        right: edgePattern === 1 || edgePattern === 2,
        bottom: edgePattern === 0 || edgePattern === 3,
        left: edgePattern === 1 || edgePattern === 3
      }
    });
  }

  if (!state.projectDetails[cacheKey]) {
    state.projectDetails[cacheKey] = { project, parts };
  } else {
    state.projectDetails[cacheKey].parts = parts;
  }

  return parts;
}

function computeNesting(parts, project = null) {
  const sourceNesting = project?.nesting;
  const palette = ['#d8ecc0', '#e3f4cf', '#d1e7b8', '#e8f1cf', '#dcefc7', '#edf6dc'];
  const boardWidth = Number(sourceNesting?.boardWidthMm || 2750);
  const boardHeight = Number(sourceNesting?.boardHeightMm || 1830);

  if (sourceNesting?.sheets?.length) {
    const partLookup = new Map();
    parts.forEach((part, index) => {
      [part?.reference, part?.code, part?.raw?.partId, part?.raw?.reference, part?.raw?.code, `IDX-${index}`]
        .filter(Boolean)
        .forEach(key => partLookup.set(String(key), part));
    });

    const sheets = sourceNesting.sheets.map((sheet, sheetIndex) => {
      const widthMm = Number(sheet.widthMm || boardWidth || 2750);
      const heightMm = Number(sheet.heightMm || boardHeight || 1830);
      const items = (sheet.items || []).map((item, itemIndex) => {
        const relatedPart = partLookup.get(String(item.partId || ''))
          || partLookup.get(String(item.reference || ''))
          || partLookup.get(String(item.code || ''))
          || partLookup.get(`IDX-${itemIndex}`)
          || parts[itemIndex]
          || {};
        const drawWidth = Number(item.widthMm || item.width || relatedPart.widthMm || relatedPart.lengthMm || 0);
        const drawHeight = Number(item.heightMm || item.height || relatedPart.lengthMm || relatedPart.widthMm || 0);
        const material = normalizeMaterialName(item.materialName || item.materialCode || relatedPart.material || relatedPart.raw?.materialCode);
        return {
          reference: item.reference || item.code || item.partId || `PECA-${itemIndex + 1}`,
          code: item.code || relatedPart.code || '',
          label: item.label || relatedPart.description || relatedPart.raw?.label || item.reference || item.code || `Peça ${itemIndex + 1}`,
          description: relatedPart.description || item.label || '',
          material,
          boardIndex: Math.max(0, Number(sheet.sheetNumber || sheetIndex + 1) - 1),
          x: Number(item.xmm || item.x || 0),
          y: Number(item.ymm || item.y || 0),
          drawWidth,
          drawHeight,
          fill: palette[(itemIndex + sheetIndex) % palette.length],
          dimensionLabel: `${formatNestingMm(drawWidth)} x ${formatNestingMm(drawHeight)}`
        };
      });
      const materials = Array.from(new Set(items.map(item => item.material)));
      const usedArea = items.reduce((sum, item) => sum + (item.drawWidth * item.drawHeight), 0);
      return {
        sheetNumber: Number(sheet.sheetNumber || sheetIndex + 1),
        widthMm,
        heightMm,
        usedAreaPct: Number(sheet.usedAreaPct || (widthMm * heightMm > 0 ? (usedArea / (widthMm * heightMm)) * 100 : 0)),
        materials,
        primaryMaterial: materials[0] || 'Material não informado',
        items
      };
    });

    return {
      boardWidth,
      boardHeight,
      boardCount: Number(sourceNesting.boardCount || sheets.length || 1),
      utilization: Number(sourceNesting.utilizationPct || 0),
      estimatedMinutes: Number(sourceNesting.estimatedMinutes || 0),
      travelMeters: Number(sourceNesting.travelMeters || 0),
      passes: Number(sourceNesting.passCount || 0),
      averageSpeed: Number(sourceNesting.averageSpeedMetersPerMinute || 16.8),
      sheets,
      materials: Array.from(new Set(sheets.flatMap(sheet => sheet.materials || []))),
      placed: sheets.flatMap(sheet => sheet.items)
    };
  }

  const placed = [];
  let currentX = 24;
  let currentY = 24;
  let rowHeight = 0;
  let boardIndex = 0;

  parts.forEach((part, index) => {
    const width = Math.min(part.lengthMm, 900);
    const height = Math.min(part.widthMm, 500);

    if (currentX + width + 24 > boardWidth) {
      currentX = 24;
      currentY += rowHeight + 24;
      rowHeight = 0;
    }

    if (currentY + height + 24 > boardHeight) {
      boardIndex += 1;
      currentX = 24;
      currentY = 24;
      rowHeight = 0;
    }

    placed.push({
      ...part,
      material: normalizeMaterialName(part.material),
      boardIndex,
      x: currentX,
      y: currentY,
      drawWidth: width,
      drawHeight: height,
      fill: palette[index % palette.length],
      dimensionLabel: `${formatNestingMm(width)} x ${formatNestingMm(height)}`
    });

    currentX += width + 24;
    rowHeight = Math.max(rowHeight, height);
  });

  const boardCount = Math.max(1, boardIndex + 1);
  const usedArea = placed.reduce((sum, item) => sum + (item.drawWidth * item.drawHeight), 0);
  const totalArea = boardCount * boardWidth * boardHeight;
  const utilization = totalArea > 0 ? (usedArea / totalArea) * 100 : 0;
  const estimatedMinutes = Math.max(12, Math.round(parts.length * 2.6));
  const travelMeters = Number((parts.length * 1.42).toFixed(1));
  const passes = parts.reduce((sum, item) => sum + (item.cnc ? 3 : 2), 0);
  const averageSpeed = 16.8;

  const sheets = Array.from({ length: boardCount }, (_, index) => {
    const items = placed.filter(item => item.boardIndex === index);
    const materials = Array.from(new Set(items.map(item => item.material)));
    const usedAreaPct = boardWidth * boardHeight > 0
      ? (items.reduce((sum, item) => sum + (item.drawWidth * item.drawHeight), 0) / (boardWidth * boardHeight)) * 100
      : 0;
    return {
      sheetNumber: index + 1,
      widthMm: boardWidth,
      heightMm: boardHeight,
      usedAreaPct,
      materials,
      primaryMaterial: materials[0] || 'Material não informado',
      items
    };
  });

  return {
    boardWidth,
    boardHeight,
    boardCount,
    utilization,
    estimatedMinutes,
    travelMeters,
    passes,
    averageSpeed,
    sheets,
    materials: Array.from(new Set(placed.map(item => item.material))),
    placed
  };
}

function edgeBandingIcon(edgeBanding) {
  const top = edgeBanding?.top;
  const right = edgeBanding?.right;
  const bottom = edgeBanding?.bottom;
  const left = edgeBanding?.left;

  return `
    <svg viewBox="0 0 92 64" class="h-10 w-16" aria-hidden="true">
      <rect x="16" y="12" width="60" height="40" rx="10" fill="#fff" stroke="#cbd5e1" stroke-width="2"></rect>
      <line x1="22" y1="12" x2="70" y2="12" stroke="${top ? '#dc2626' : '#94a3b8'}" stroke-width="${top ? 6 : 3}" stroke-dasharray="${top ? '0' : '6 4'}"></line>
      <line x1="76" y1="18" x2="76" y2="46" stroke="${right ? '#dc2626' : '#94a3b8'}" stroke-width="${right ? 6 : 3}" stroke-dasharray="${right ? '0' : '6 4'}"></line>
      <line x1="22" y1="52" x2="70" y2="52" stroke="${bottom ? '#dc2626' : '#94a3b8'}" stroke-width="${bottom ? 6 : 3}" stroke-dasharray="${bottom ? '0' : '6 4'}"></line>
      <line x1="16" y1="18" x2="16" y2="46" stroke="${left ? '#dc2626' : '#94a3b8'}" stroke-width="${left ? 6 : 3}" stroke-dasharray="${left ? '0' : '6 4'}"></line>
    </svg>
  `;
}

function smallMetricCard(title, value, subtitle, accent = 'red') {
  const theme = accent === 'slate'
    ? 'from-slate-50 to-white ring-slate-200 text-slate-900'
    : 'from-red-50 to-white ring-red-100 text-slate-900';
  return `
    <article class="rounded-3xl bg-gradient-to-br ${theme} p-5 shadow-soft ring-1">
      <p class="text-sm font-medium text-slate-500">${escapeHtml(title)}</p>
      <strong class="mt-3 block text-3xl font-extrabold tracking-tight text-slate-900">${escapeHtml(value)}</strong>
      <p class="mt-2 text-sm text-slate-500">${escapeHtml(subtitle)}</p>
    </article>
  `;
}

function renderNotifications() {
  const items = state.notifications || [];
  if (!items.length) return '';

  return `
    <div class="space-y-3">
      ${items.map(item => {
        const palette = item.type === 'error'
          ? 'border-red-200 bg-red-50 text-red-800'
          : item.type === 'success'
            ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
            : 'border-slate-200 bg-white text-slate-700';
        return `
          <article class="rounded-2xl border ${palette} px-4 py-3 shadow-sm">
            <div class="flex items-start justify-between gap-3">
              <div>
                <p class="text-sm font-semibold">${escapeHtml(item.title)}</p>
                <p class="mt-1 text-sm leading-6">${toHtml(item.message)}</p>
              </div>
              <button class="rounded-full p-2 text-slate-400 transition hover:bg-white/80 hover:text-slate-700" data-action="dismiss-notification" data-id="${item.id}" type="button">×</button>
            </div>
          </article>
        `;
      }).join('')}
    </div>
  `;
}

function renderSidebar() {
  const links = [
    { href: '/home', label: 'Home', icon: '⌂' },
    { href: '/projetos', label: 'Projetos', icon: '▣' },
    { href: '/equipe', label: 'Equipe', icon: '◎' },
    { href: '/maquina', label: 'Máquina CNC', icon: '◫' },
    { href: '/ferramentas', label: 'Ferramentas', icon: '✦' }
  ];

  return `
    <aside class="hidden xl:flex xl:w-[320px] xl:flex-col xl:gap-6 xl:border-r xl:border-slate-200 xl:bg-white/90 xl:px-6 xl:py-8 xl:backdrop-blur">
      <div class="rounded-3xl bg-gradient-to-br from-red-600 via-red-600 to-red-700 p-6 text-white shadow-panel">
        <p class="text-xs font-semibold uppercase tracking-[0.35em] text-red-100">Enterprise SaaS</p>
        <h1 class="mt-4 text-3xl font-extrabold tracking-tight">Marcenaria Inteligente</h1>
        <p class="mt-3 text-sm leading-6 text-red-50/90">Fluxo comercial profissional inspirado em operações de alto nível: SketchUp, engenharia, produção, CAM e chão de fábrica.</p>
      </div>

      <nav class="space-y-2">
        ${links.map(link => {
          const active = state.route === link.href || (link.href === '/projetos' && state.route.startsWith('/projetos/'));
          return `
            <button type="button" data-action="navigate" data-path="${link.href}" class="flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-semibold transition ${active ? 'bg-red-50 text-red-700 ring-1 ring-red-100 shadow-sm' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}">
              <span class="grid h-10 w-10 place-items-center rounded-2xl ${active ? 'bg-white text-red-600 shadow-sm' : 'bg-slate-100 text-slate-500'}">${link.icon}</span>
              <span>${escapeHtml(link.label)}</span>
            </button>
          `;
        }).join('')}
      </nav>

      <section class="rounded-3xl border border-slate-200 bg-slate-50 p-5 shadow-sm">
        <p class="text-xs font-semibold uppercase tracking-[0.3em] text-slate-400">Conexão SketchUp</p>
        <div class="mt-4 space-y-3 text-sm text-slate-600">
          <div class="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <p class="font-semibold text-slate-900">HtmlDialog ativo</p>
            <p class="mt-1 leading-6">${isSketchUpHost() ? 'A extensão está aberta dentro do SketchUp.' : 'Modo navegador externo para validação.'}</p>
          </div>
          <div class="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <p class="font-semibold text-slate-900">URL pública</p>
            <p class="mt-1 break-all leading-6 text-red-700">${escapeHtml(state.pluginSession?.dashboardUrl || window.location.origin)}</p>
          </div>
          <div class="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <p class="font-semibold text-slate-900">Último evento</p>
            <p class="mt-1 leading-6">${escapeHtml(state.pluginEvents[0]?.message || 'Aguardando interação com o plugin.')}</p>
          </div>
        </div>
      </section>
    </aside>
  `;
}

function renderTopBar() {
  return `
    <header class="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div class="mx-auto flex max-w-[1800px] flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <p class="text-xs font-semibold uppercase tracking-[0.35em] text-red-600">${escapeHtml(routeTitle(state.route))}</p>
          <h2 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Operação comercial branca e vermelha</h2>
          <p class="mt-1 text-sm text-slate-500">Dashboard responsivo, ponte SketchUp ↔ nuvem, produção com travas e saída CNC profissional.</p>
        </div>

        <div class="flex flex-wrap items-center gap-3">
          <button type="button" data-action="generate-plugin-session" class="inline-flex items-center justify-center rounded-2xl border border-red-200 bg-white px-4 py-3 text-sm font-semibold text-red-700 shadow-sm transition hover:bg-red-50">Conectar SketchUp</button>
          <button type="button" data-action="send-project" class="inline-flex items-center justify-center rounded-2xl bg-red-600 px-5 py-3 text-sm font-semibold text-white shadow-panel transition hover:bg-red-700">ENVIAR PROJETO</button>
          <div class="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
            <p class="text-xs uppercase tracking-[0.24em] text-slate-400">Sessão</p>
            <p class="mt-1 text-sm font-semibold text-slate-900">${escapeHtml(state.user ? `${state.user.name} · ${roleLabel(state.user.role)}` : 'Sem autenticação')}</p>
          </div>
          ${state.user ? '<button type="button" data-action="logout" class="inline-flex items-center justify-center rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">Sair</button>' : ''}
        </div>
      </div>
    </header>
  `;
}

function renderLogin() {
  return `
    <main class="grid min-h-screen place-items-center px-4 py-10 sm:px-6 lg:px-8">
      <section class="grid w-full max-w-6xl gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <div class="rounded-[2rem] bg-gradient-to-br from-red-600 via-red-600 to-rose-700 p-8 text-white shadow-panel sm:p-10">
          <p class="text-xs font-semibold uppercase tracking-[0.4em] text-red-100">Padrão Comercial</p>
          <h1 class="mt-6 text-4xl font-black tracking-tight sm:text-5xl">Marcenaria SaaS Enterprise</h1>
          <p class="mt-6 max-w-2xl text-base leading-8 text-red-50/95">Conecte o SketchUp, sincronize projetos com um clique, acompanhe produção, equipe, máquina CNC, ferramentas ATC e G-Code com trava de segurança por status.</p>
          <div class="mt-10 grid gap-4 sm:grid-cols-3">
            ${smallMetricCard('Projetos', '128', 'Base comercial do dashboard', 'red')}
            ${smallMetricCard('Clientes', '34', 'Carteira sincronizada', 'red')}
            ${smallMetricCard('Produção', '19', 'Projetos em andamento', 'red')}
          </div>
        </div>

        <div class="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-soft sm:p-10">
          <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Acesso seguro</p>
          <h2 class="mt-4 text-3xl font-bold tracking-tight text-slate-900">Entrar no Dashboard</h2>
          <p class="mt-3 text-sm leading-7 text-slate-500">Digite suas credenciais corporativas para acessar o dashboard. As credenciais de demonstração não são mais exibidas na interface pública.</p>

          <form id="login-form" class="mt-8 space-y-5">
            <div>
              <label class="mb-2 block text-sm font-semibold text-slate-700" for="email">E-mail corporativo</label>
              <input id="email" name="email" type="email" value="" placeholder="voce@empresa.com" autocomplete="username" class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-red-400 focus:bg-white focus:ring-4 focus:ring-red-100" required />
            </div>
            <div>
              <label class="mb-2 block text-sm font-semibold text-slate-700" for="password">Senha</label>
              <input id="password" name="password" type="password" value="" placeholder="Digite sua senha" autocomplete="current-password" class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-red-400 focus:bg-white focus:ring-4 focus:ring-red-100" required />
            </div>
            <button type="submit" class="inline-flex w-full items-center justify-center rounded-2xl bg-red-600 px-5 py-3.5 text-sm font-semibold text-white shadow-panel transition hover:bg-red-700">Acessar plataforma</button>
          </form>

          <div class="mt-8 rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p class="font-semibold text-slate-900">Segurança de acesso</p>
            <p class="mt-1 text-sm leading-6 text-slate-500">As credenciais operacionais foram removidas desta tela. Caso precise de acesso de suporte, utilize o fluxo interno da equipe responsável.</p>
          </div>
        </div>
      </section>
    </main>
  `;
}

function renderHome() {
  const metrics = deriveMetrics();
  const byCustomer = groupProjectsByCustomer();
  const barMax = Math.max(1, ...byCustomer.map(item => item.total));

  return `
    <section class="space-y-8">
      <div class="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        ${smallMetricCard('Total de Projetos', formatNumber(metrics.totalProjects), 'Projetos sincronizados com a nuvem')}
        ${smallMetricCard('Clientes Ativos', formatNumber(metrics.clients), 'Clientes distintos na carteira')}
        ${smallMetricCard('Em Produção', formatNumber(metrics.inProduction), 'Projetos liberados para G-Code')}
        ${smallMetricCard('Licenças Ativas', formatNumber(metrics.licenses), 'Usuários com acesso liberado', 'slate')}
      </div>

      <div class="grid gap-6 xl:grid-cols-[1.3fr_0.7fr]">
        <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
          <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Inteligência Comercial</p>
              <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Volume de projetos por cliente</h3>
            </div>
            <p class="text-sm text-slate-500">Visão executiva inspirada em plataformas enterprise.</p>
          </div>

          <div class="mt-8 space-y-4">
            ${byCustomer.length ? byCustomer.map((item, index) => `
              <div>
                <div class="mb-2 flex items-center justify-between text-sm font-medium text-slate-600">
                  <span>${escapeHtml(item.name)}</span>
                  <span>${formatNumber(item.total)} projeto(s)</span>
                </div>
                <div class="h-4 rounded-full bg-slate-100">
                  <div class="h-4 rounded-full" style="width:${Math.max(12, (item.total / barMax) * 100)}%; background:${customerColor(index)}"></div>
                </div>
              </div>
            `).join('') : '<p class="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">Ainda não há projetos sincronizados para compor o gráfico.</p>'}
          </div>
        </section>

        <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
          <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Operação</p>
          <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Painel de produção</h3>
          <div class="mt-6 space-y-4">
            <article class="rounded-2xl border border-red-100 bg-red-50 p-5">
              <p class="text-sm font-semibold text-red-700">Integração SketchUp ↔ Dashboard</p>
              <p class="mt-2 text-sm leading-6 text-red-800">O plugin abre esta URL dentro do HtmlDialog e usa a ponte <code class="rounded bg-white px-1.5 py-0.5 text-xs">window.sketchup.sincronizar()</code> para disparar a extração e o POST em Ruby.</p>
            </article>
            <article class="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p class="text-sm font-semibold text-slate-900">Peças detalhadas</p>
              <p class="mt-2 text-sm leading-6 text-slate-600">Tabela com material, medidas, fita de borda visual e indicação de furação/usinagem.</p>
            </article>
            <article class="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p class="text-sm font-semibold text-slate-900">Nesting e CAM</p>
              <p class="mt-2 text-sm leading-6 text-slate-600">Visualização das chapas, estatísticas de corte e G-Code com ATC T1/T2.</p>
            </article>
          </div>
        </section>
      </div>
    </section>
  `;
}

function renderProjectsList() {
  const projects = state.projects || [];
  return `
    <section class="space-y-8">
      <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
        <div class="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Conexão SketchUp</p>
            <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Sincronização profissional com 1 clique</h3>
            <p class="mt-3 max-w-3xl text-sm leading-7 text-slate-500">Preencha o cliente e o projeto, gere a sessão do plugin e depois use o botão <strong>ENVIAR PROJETO</strong>. O site chama o Ruby, o Ruby extrai medidas, materiais, bordas e usinagens, e faz o POST direto para a nuvem.</p>
          </div>
          <div class="grid gap-3 sm:grid-cols-2">
            <button type="button" data-action="generate-plugin-session" class="rounded-2xl border border-red-200 bg-white px-4 py-3 text-sm font-semibold text-red-700 shadow-sm transition hover:bg-red-50">Gerar sessão do plugin</button>
            <button type="button" data-action="send-project" class="rounded-2xl bg-red-600 px-4 py-3 text-sm font-semibold text-white shadow-panel transition hover:bg-red-700">ENVIAR PROJETO</button>
          </div>
        </div>

        <div class="mt-6 grid gap-4 md:grid-cols-2">
          <label class="block">
            <span class="mb-2 block text-sm font-semibold text-slate-700">Cliente</span>
            <input id="pending-customer-name" value="${escapeHtml(state.pendingCustomerName)}" placeholder="Ex.: Além do Aroma" class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-red-400 focus:bg-white focus:ring-4 focus:ring-red-100" />
          </label>
          <label class="block">
            <span class="mb-2 block text-sm font-semibold text-slate-700">Projeto</span>
            <input id="pending-project-name" value="${escapeHtml(state.pendingProjectName)}" placeholder="Ex.: Cozinha Gourmet" class="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-red-400 focus:bg-white focus:ring-4 focus:ring-red-100" />
          </label>
        </div>
      </section>

      <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
        <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Projetos</p>
            <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Lista de Projetos</h3>
            <p class="mt-2 text-sm leading-7 text-slate-500">Cada projeto começa em <strong>Rascunho</strong>. Só projetos em <strong>Em Produção</strong> liberam a geração de G-Code.</p>
          </div>
          <button type="button" data-action="refresh-projects" class="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">Atualizar lista</button>
        </div>

        <div class="mt-6 overflow-hidden rounded-3xl border border-slate-200">
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-left text-sm">
              <thead class="bg-slate-50 text-slate-500">
                <tr>
                  <th class="px-5 py-4 font-semibold">Código</th>
                  <th class="px-5 py-4 font-semibold">Nome</th>
                  <th class="px-5 py-4 font-semibold">Cliente</th>
                  <th class="px-5 py-4 font-semibold">Status</th>
                  <th class="px-5 py-4 font-semibold">Autor</th>
                  <th class="px-5 py-4 font-semibold">Produção</th>
                  <th class="px-5 py-4 font-semibold text-right">Ações</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 bg-white">
                ${projects.length ? projects.map(project => `
                  <tr class="align-top transition hover:bg-red-50/40">
                    <td class="px-5 py-4 font-semibold text-slate-700">${escapeHtml(slugCode(project.slug).slice(0, 10))}</td>
                    <td class="px-5 py-4">
                      <button class="text-left font-semibold text-slate-900 transition hover:text-red-700" data-action="open-project" data-slug="${project.slug}" type="button">${escapeHtml(project.name)}</button>
                      <p class="mt-1 text-xs text-slate-500">${escapeHtml(project.route || `/projetos/${project.slug}`)}</p>
                    </td>
                    <td class="px-5 py-4 text-slate-600">${escapeHtml(project.customerName || 'Sem cliente')}</td>
                    <td class="px-5 py-4"><span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold ${statusBadge(project.status)}">${statusLabel(project.status)}</span></td>
                    <td class="px-5 py-4 text-slate-600">${escapeHtml(project.syncedBy || '—')}</td>
                    <td class="px-5 py-4 text-slate-600">
                      <p>${escapeHtml(project.localProductionFolder || 'Aguardando geração')}</p>
                      <p class="mt-1 text-xs text-slate-400">${project.canGenerateGCode ? 'G-Code liberado' : 'Aguardando aprovação de produção'}</p>
                    </td>
                    <td class="relative px-5 py-4 text-right">
                      <button type="button" data-action="toggle-menu" data-project-id="${project.projectId}" class="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-lg font-semibold text-slate-600 shadow-sm transition hover:bg-slate-50">⋯</button>
                      ${state.menuProjectId === project.projectId ? `
                        <div class="absolute right-5 top-16 z-10 w-52 rounded-2xl border border-slate-200 bg-white p-2 text-left shadow-soft">
                          <button type="button" data-action="open-project" data-slug="${project.slug}" class="flex w-full rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Orçamentos</button>
                          <button type="button" data-action="open-project" data-slug="${project.slug}" class="flex w-full rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Custos</button>
                          <button type="button" data-action="open-project" data-slug="${project.slug}" class="flex w-full rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Lista de Cortes</button>
                          <button type="button" data-action="open-project" data-slug="${project.slug}" class="flex w-full rounded-xl px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Plano de Corte</button>
                        </div>
                      ` : ''}
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="7" class="px-6 py-12 text-center text-sm text-slate-500">Nenhum projeto sincronizado ainda. Use o botão <strong>ENVIAR PROJETO</strong> para trazer o modelo do SketchUp.</td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </section>
  `;
}

function renderNestingPiece(piece, boardScale) {
  const x = 26 + (piece.x * boardScale);
  const y = 26 + (piece.y * boardScale);
  const width = Math.max(24, piece.drawWidth * boardScale);
  const height = Math.max(24, piece.drawHeight * boardScale);
  const centerX = x + (width / 2);
  const centerY = y + (height / 2);
  const titleSize = Math.max(10, Math.min(22, Math.min(width, height) * 0.2));
  const detailSize = Math.max(9, Math.min(15, titleSize * 0.82));
  const showDimensions = width >= 84 && height >= 40;
  const showDescription = width >= 128 && height >= 78;

  return `
    <g>
      <rect x="${x}" y="${y}" width="${width}" height="${height}" rx="4" fill="${piece.fill || '#d8ecc0'}" stroke="#657558" stroke-width="1.4"></rect>
      <text x="${centerX}" y="${centerY - (showDimensions ? titleSize * 0.35 : 0)}" text-anchor="middle" font-size="${titleSize}" font-weight="700" fill="#18230f">${escapeHtml(piece.reference || piece.code || 'P')}</text>
      ${showDimensions ? `<text x="${centerX}" y="${centerY + titleSize * 0.9}" text-anchor="middle" font-size="${detailSize}" font-weight="600" fill="#314126">${escapeHtml(piece.dimensionLabel || '')}</text>` : ''}
      ${showDescription ? `<text x="${centerX}" y="${y + height - 8}" text-anchor="middle" font-size="${Math.max(8, detailSize - 1)}" fill="#55664b">${escapeHtml((piece.label || '').slice(0, 26))}</text>` : ''}
    </g>
  `;
}

function renderNestingThumbnail(sheet, boardIndex, active = false) {
  const thumbScale = Math.min(160 / Math.max(sheet.widthMm || 1, 1), 108 / Math.max(sheet.heightMm || 1, 1));
  const frameWidth = Math.max(150, (sheet.widthMm || 0) * thumbScale + 18);
  const frameHeight = Math.max(92, (sheet.heightMm || 0) * thumbScale + 18);

  return `
    <button type="button" data-action="select-nesting-board" data-board-index="${boardIndex}" class="w-full rounded-[1.4rem] border bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${active ? 'border-red-300 ring-2 ring-red-100' : 'border-slate-200'}">
      <div class="flex items-start justify-between gap-3">
        <div>
          <p class="text-sm font-bold text-slate-900">${escapeHtml(buildSheetCaption(sheet.materials || [sheet.primaryMaterial]))}</p>
          <p class="mt-1 text-xs text-slate-500">Dimensões: ${formatNestingMm(sheet.widthMm)} × ${formatNestingMm(sheet.heightMm)} mm</p>
        </div>
        <span class="inline-flex rounded-full bg-slate-700 px-2.5 py-1 text-xs font-semibold text-white">Nº ${sheet.sheetNumber}</span>
      </div>
      <div class="mt-4 grid place-items-center rounded-2xl border border-slate-200 bg-slate-50 p-3">
        <svg viewBox="0 0 ${frameWidth} ${frameHeight}" class="w-full max-w-[210px]">
          <rect x="9" y="9" width="${Math.max(24, (sheet.widthMm || 0) * thumbScale)}" height="${Math.max(24, (sheet.heightMm || 0) * thumbScale)}" rx="4" fill="#fff" stroke="#2f2f2f" stroke-dasharray="3 3"></rect>
          ${(sheet.items || []).map(item => `<rect x="${9 + (item.x * thumbScale)}" y="${9 + (item.y * thumbScale)}" width="${Math.max(3, item.drawWidth * thumbScale)}" height="${Math.max(3, item.drawHeight * thumbScale)}" fill="none" stroke="#ef4444" stroke-width="1"></rect>`).join('')}
        </svg>
      </div>
      <div class="mt-3 flex items-center justify-between text-xs text-slate-500">
        <span>Peças: ${formatNumber((sheet.items || []).length)}</span>
        <span>Aproveitamento: ${formatPercent(sheet.usedAreaPct || 0)}</span>
      </div>
    </button>
  `;
}

function renderProjectDetail() {
  const project = projectFromRoute();
  if (!project) {
    return `
      <section class="rounded-[2rem] border border-dashed border-slate-300 bg-white p-10 text-center shadow-soft">
        <h3 class="text-xl font-bold text-slate-900">Projeto não encontrado</h3>
        <p class="mt-3 text-sm text-slate-500">Atualize a lista ou volte para a tela de projetos.</p>
        <button type="button" data-action="navigate" data-path="/projetos" class="mt-6 rounded-2xl bg-red-600 px-5 py-3 text-sm font-semibold text-white shadow-panel">Voltar para Projetos</button>
      </section>
    `;
  }

  const detail = state.projectDetails[project.slug] || { project, parts: createSyntheticParts(project) };
  const projectData = detail.project || project;
  const parts = detail.parts || createSyntheticParts(projectData);
  const nesting = computeNesting(parts, projectData);
  const productionOrder = projectData.productionOrder || {};
  const stats = [
    ['Peças', formatNumber(projectData.summary?.partCount || parts.reduce((sum, part) => sum + Number(part.quantity || 1), 0))],
    ['Chapas usadas', formatNumber(projectData.summary?.boardCount || nesting.boardCount)],
    ['Tempo estimado', `${productionOrder.estimatedMinutes || nesting.estimatedMinutes || 0} min`],
    ['Deslocamento total', `${nesting.travelMeters || 0} m`],
    ['Passadas', formatNumber(nesting.passes || 0)],
    ['Velocidade média', `${Number(nesting.averageSpeed || 0).toFixed(1).replace('.', ',')} m/min`],
    ['Yield', formatPercent(projectData.summary?.utilizationPct || nesting.utilization)],
    ['Ferramentas', productionOrder.toolSequence || 'T1 → T2'],
    ['Furação', formatNumber(productionOrder.drillOperationCount || parts.reduce((sum, part) => sum + Number(part.holes || 0), 0))],
    ['Pasta da máquina', projectData.localProductionFolder || productionOrder.projectFolderPath || 'Aguardando geração']
  ];

  const requestedMaterial = state.nestingMaterialFilter || 'all';
  const materialOptions = ['all', ...(nesting.materials || [])];
  const materialFilteredSheets = requestedMaterial === 'all'
    ? (nesting.sheets || [])
    : (nesting.sheets || []).filter(sheet => (sheet.materials || []).includes(requestedMaterial) || sheet.primaryMaterial === requestedMaterial);
  const visibleSheets = materialFilteredSheets.length ? materialFilteredSheets : (nesting.sheets || []);
  const selectedMaterial = materialFilteredSheets.length ? requestedMaterial : 'all';
  const safeBoardIndex = Math.min(Math.max(Number(state.nestingBoardIndex || 0), 0), Math.max(visibleSheets.length - 1, 0));
  const currentBoard = visibleSheets[safeBoardIndex] || visibleSheets[0] || {
    sheetNumber: 1,
    widthMm: nesting.boardWidth,
    heightMm: nesting.boardHeight,
    usedAreaPct: 0,
    primaryMaterial: 'Material não informado',
    materials: ['Material não informado'],
    items: []
  };
  const boardScale = Math.min(
    840 / Math.max(currentBoard.widthMm || nesting.boardWidth || 1, 1),
    620 / Math.max(currentBoard.heightMm || nesting.boardHeight || 1, 1)
  );
  const boardWidthPx = Math.max(320, (currentBoard.widthMm || nesting.boardWidth || 2750) * boardScale);
  const boardHeightPx = Math.max(220, (currentBoard.heightMm || nesting.boardHeight || 1830) * boardScale);
  const boardPieces = currentBoard.items || [];
  const currentBoardCaption = buildSheetCaption(currentBoard.materials || [currentBoard.primaryMaterial]);

  return `
    <section class="space-y-8">
      <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
        <div class="flex flex-col gap-6 xl:flex-row xl:items-start xl:justify-between">
          <div>
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Engenharia do Projeto</p>
            <h3 class="mt-2 text-3xl font-black tracking-tight text-slate-900">${escapeHtml(project.name)}</h3>
            <p class="mt-3 max-w-3xl text-sm leading-7 text-slate-500">Cliente: <strong>${escapeHtml(projectData.customerName || 'Sem cliente')}</strong> · Autor: <strong>${escapeHtml(projectData.syncedBy || '—')}</strong> · Última atualização: <strong>${escapeHtml(formatDate(projectData.updatedAtUtc))}</strong></p>
          </div>
          <div class="grid gap-3 sm:grid-cols-2 xl:min-w-[420px]">
            <label class="block rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <span class="text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">Status de Produção</span>
              <select data-action="project-status" data-project-id="${projectData.projectId}" class="mt-3 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-red-400 focus:ring-4 focus:ring-red-100">
                <option value="rascunho" ${projectData.status !== 'em_producao' ? 'selected' : ''}>Rascunho</option>
                <option value="em_producao" ${projectData.status === 'em_producao' ? 'selected' : ''}>Em Produção</option>
              </select>
            </label>
            <div class="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <span class="text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">G-Code</span>
              <button type="button" data-action="generate-gcode" data-project-id="${projectData.projectId}" class="mt-3 inline-flex w-full items-center justify-center rounded-2xl px-4 py-3 text-sm font-semibold ${projectData.canGenerateGCode && state.user?.permissions?.canAccessTools ? 'bg-red-600 text-white shadow-panel hover:bg-red-700' : 'cursor-not-allowed border border-slate-200 bg-white text-slate-400'}" ${projectData.canGenerateGCode && state.user?.permissions?.canAccessTools ? '' : 'disabled'}>
                ${projectData.canGenerateGCode ? 'Gerar G-Code (T1/T2)' : 'Bloqueado até Em Produção'}
              </button>
            </div>
          </div>
        </div>
      </section>

      <section class="space-y-6">
        <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
          <div class="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Plano de Corte</p>
              <h4 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Nesting operacional</h4>
              <p class="mt-2 text-sm leading-7 text-slate-500">Visualização central da chapa com medidas e etiquetas, filtro por material no topo e miniaturas laterais para navegar rapidamente entre as chapas do projeto.</p>
            </div>
            <div class="grid gap-3 sm:grid-cols-[220px_auto_auto] sm:items-center">
              <label class="block">
                <span class="mb-2 block text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">Material</span>
                <select id="nesting-material-filter" class="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-red-400 focus:ring-4 focus:ring-red-100">
                  ${materialOptions.map(option => `<option value="${escapeHtml(option)}" ${selectedMaterial === option ? 'selected' : ''}>${escapeHtml(option === 'all' ? 'Todos os materiais' : option)}</option>`).join('')}
                </select>
              </label>
              <div class="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                <p class="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">Chapa ativa</p>
                <p class="mt-1 font-bold text-slate-900">Nº ${currentBoard.sheetNumber}</p>
              </div>
              <div class="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                <p class="text-xs font-semibold uppercase tracking-[0.22em] text-slate-400">Exibição</p>
                <p class="mt-1 font-bold text-slate-900">${safeBoardIndex + 1} / ${Math.max(visibleSheets.length, 1)}</p>
              </div>
            </div>
          </div>

          <div class="mt-6 grid gap-6 xl:grid-cols-[minmax(0,1fr)_290px]">
            <div class="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-4 sm:p-6">
              <div class="rounded-[1.6rem] border border-slate-200 bg-white px-4 py-3 shadow-sm sm:px-6">
                <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p class="text-lg font-bold text-slate-900">${escapeHtml(currentBoardCaption)}</p>
                    <p class="text-sm text-slate-500">Chapa Nº ${currentBoard.sheetNumber} · ${formatNestingMm(currentBoard.widthMm)} × ${formatNestingMm(currentBoard.heightMm)} mm</p>
                  </div>
                  <div class="rounded-full bg-red-50 px-4 py-2 text-sm font-semibold text-red-700 ring-1 ring-inset ring-red-200">
                    Aproveitamento ${formatPercent(currentBoard.usedAreaPct || 0)}
                  </div>
                </div>
              </div>

              <div class="mt-4 overflow-auto rounded-[1.6rem] border border-slate-200 p-4" style="background-color:#f7f7f5;background-image:linear-gradient(to right, rgba(148,163,184,0.22) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.22) 1px, transparent 1px);background-size:24px 24px;">
                <div class="mx-auto" style="width:${boardWidthPx + 84}px;min-width:${Math.min(boardWidthPx + 84, 420)}px;">
                  <svg viewBox="0 0 ${boardWidthPx + 84} ${boardHeightPx + 84}" class="w-full">
                    <text x="${42 + (boardWidthPx / 2)}" y="20" text-anchor="middle" font-size="15" font-weight="700" fill="#334155">${formatNestingMm(currentBoard.widthMm)}mm</text>
                    <text x="${boardWidthPx + 64}" y="${42 + (boardHeightPx / 2)}" text-anchor="middle" font-size="15" font-weight="700" fill="#334155" transform="rotate(90 ${boardWidthPx + 64} ${42 + (boardHeightPx / 2)})">${formatNestingMm(currentBoard.heightMm)}mm</text>
                    <rect x="26" y="26" width="${boardWidthPx}" height="${boardHeightPx}" rx="4" fill="#ece8b3" stroke="#2e2e2e" stroke-width="2"></rect>
                    ${boardPieces.map(piece => renderNestingPiece(piece, boardScale)).join('')}
                  </svg>
                </div>
              </div>
            </div>

            <aside class="rounded-[1.8rem] border border-slate-200 bg-slate-50 p-4 sm:p-5">
              <div class="flex items-center justify-between gap-3">
                <div>
                  <p class="text-xs font-semibold uppercase tracking-[0.28em] text-slate-400">Miniaturas</p>
                  <h5 class="mt-1 text-lg font-bold text-slate-900">Chapas do projeto</h5>
                </div>
                <span class="rounded-full bg-white px-3 py-1 text-xs font-semibold text-slate-600 ring-1 ring-inset ring-slate-200">${formatNumber(visibleSheets.length)} chapa(s)</span>
              </div>
              <div class="mt-4 space-y-4 max-h-[860px] overflow-auto pr-1">
                ${visibleSheets.map((sheet, index) => renderNestingThumbnail(sheet, index, index === safeBoardIndex)).join('')}
              </div>
            </aside>
          </div>
        </section>

        <section class="grid gap-6 2xl:grid-cols-[1.18fr_0.82fr]">
          <div class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
            <div class="flex items-center justify-between gap-4">
              <div>
                <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Lista de Cortes</p>
                <h4 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">BOM detalhada</h4>
              </div>
              <span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold ${statusBadge(projectData.status)}">${statusLabel(projectData.status)}</span>
            </div>

            <div class="mt-6 overflow-hidden rounded-3xl border border-slate-200">
              <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 text-left text-sm">
                  <thead class="bg-slate-50 text-slate-500">
                    <tr>
                      <th class="px-4 py-4 font-semibold">Item</th>
                      <th class="px-4 py-4 font-semibold">Referência</th>
                      <th class="px-4 py-4 font-semibold">Código</th>
                      <th class="px-4 py-4 font-semibold">Qtde</th>
                      <th class="px-4 py-4 font-semibold">Descrição da Peça</th>
                      <th class="px-4 py-4 font-semibold">Material</th>
                      <th class="px-4 py-4 font-semibold">Medidas (C × L × E)</th>
                      <th class="px-4 py-4 font-semibold">Fita de Borda</th>
                      <th class="px-4 py-4 font-semibold">Furos</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100 bg-white">
                    ${parts.map(part => `
                      <tr class="align-middle hover:bg-red-50/40">
                        <td class="px-4 py-4 font-semibold text-slate-700">${part.item}</td>
                        <td class="px-4 py-4 text-slate-600">${escapeHtml(part.reference)}</td>
                        <td class="px-4 py-4 text-slate-600">${escapeHtml(part.code)}</td>
                        <td class="px-4 py-4 text-slate-600">${part.quantity}</td>
                        <td class="px-4 py-4 text-slate-900">${escapeHtml(part.description)}</td>
                        <td class="px-4 py-4 text-slate-600">${escapeHtml(part.material)}</td>
                        <td class="px-4 py-4 text-slate-600">${formatNumber(part.lengthMm)} × ${formatNumber(part.widthMm)} × ${formatNumber(part.thicknessMm)} mm</td>
                        <td class="px-4 py-4">${edgeBandingIcon(part.edgeBanding)}</td>
                        <td class="px-4 py-4">
                          ${part.cnc ? `<span class="inline-flex rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-700 ring-1 ring-inset ring-red-200">${part.holes} furo(s)</span>` : '<span class="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 ring-1 ring-inset ring-slate-200">Sem CNC</span>'}
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Estatísticas</p>
            <h4 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">CAM e Produção</h4>
            <div class="mt-6 grid gap-3">
              ${stats.map(([label, value]) => `
                <div class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                  <span class="font-medium text-slate-500">${escapeHtml(label)}</span>
                  <span class="font-semibold text-slate-900">${escapeHtml(value)}</span>
                </div>
              `).join('')}
            </div>
          </section>
        </section>
      </section>
    </section>
  `;
}

function renderTeam() {
  if (state.user?.role !== 'admin') {
    return `
      <section class="rounded-[2rem] border border-slate-200 bg-white p-10 text-center shadow-soft">
        <h3 class="text-2xl font-bold text-slate-900">Acesso restrito</h3>
        <p class="mt-3 text-sm text-slate-500">Somente administradores podem gerenciar equipe e permissões.</p>
      </section>
    `;
  }

  return `
    <section class="space-y-8">
      <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
        <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Gestão de Equipe</p>
            <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Usuários e permissões</h3>
            <p class="mt-2 text-sm leading-7 text-slate-500">Controle de acesso com toggles para Configuração de Máquina e Ferramentas, no padrão operacional comercial.</p>
          </div>
          <button type="button" data-action="refresh-users" class="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">Atualizar equipe</button>
        </div>
      </section>

      <div class="grid gap-5 xl:grid-cols-2">
        ${(state.users || []).map(user => `
          <article class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft">
            <div class="flex items-start justify-between gap-4">
              <div>
                <p class="text-lg font-bold text-slate-900">${escapeHtml(user.name)}</p>
                <p class="mt-1 text-sm text-slate-500">${escapeHtml(user.email)}</p>
                <p class="mt-3 inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">${escapeHtml(roleLabel(user.role))}</p>
              </div>
              <span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold ${user.isActive !== false ? 'bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-200' : 'bg-slate-100 text-slate-600 ring-1 ring-inset ring-slate-200'}">${user.isActive !== false ? 'Ativo' : 'Inativo'}</span>
            </div>
            <div class="mt-6 grid gap-3">
              <label class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <div>
                  <p class="text-sm font-semibold text-slate-900">Configuração de Máquina</p>
                  <p class="text-xs text-slate-500">Permite acesso à aba de parâmetros da CNC.</p>
                </div>
                <input ${user.permissions?.canAccessMachineSettings ? 'checked' : ''} data-action="toggle-machine-permission" data-user-id="${user.userId}" type="checkbox" class="h-5 w-5 rounded border-slate-300 text-red-600 focus:ring-red-500" ${user.isAdmin ? 'disabled' : ''} />
              </label>
              <label class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <div>
                  <p class="text-sm font-semibold text-slate-900">Ferramentas / ATC</p>
                  <p class="text-xs text-slate-500">Libera acesso à aba de ferramentas e à geração de G-Code.</p>
                </div>
                <input ${user.permissions?.canAccessTools ? 'checked' : ''} data-action="toggle-tools-permission" data-user-id="${user.userId}" type="checkbox" class="h-5 w-5 rounded border-slate-300 text-red-600 focus:ring-red-500" ${user.isAdmin ? 'disabled' : ''} />
              </label>
            </div>
          </article>
        `).join('') || '<p class="text-sm text-slate-500">Nenhum usuário disponível.</p>'}
      </div>
    </section>
  `;
}

function renderMachine() {
  const canAccess = state.user?.permissions?.canAccessMachineSettings;
  if (!canAccess) {
    return `
      <section class="rounded-[2rem] border border-slate-200 bg-white p-10 text-center shadow-soft">
        <h3 class="text-2xl font-bold text-slate-900">Acesso restrito</h3>
        <p class="mt-3 text-sm text-slate-500">Seu usuário não possui acesso à Configuração de Máquina.</p>
      </section>
    `;
  }

  const machine = state.machine || {};
  const rows = [
    ['Código da máquina', machine.code || 'router-cnc-01'],
    ['Mesa útil', '2750 × 1830 mm'],
    ['Kerf / Fresa', '6 mm'],
    ['Margem operacional', '12 mm'],
    ['Spindle', `${machine.spindleRpm || 18000} rpm`],
    ['Avanço', `${machine.feedRateMmMin || 4200} mm/min`],
    ['Plunge', `${machine.plungeRateMmMin || 1800} mm/min`],
    ['Safe Z', `${machine.safeZMm || 12} mm`]
  ];

  return `
    <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
      <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">Máquina CNC</p>
          <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Configuração da mesa e parâmetros de corte</h3>
        </div>
        <button type="button" data-action="refresh-machine" class="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">Atualizar máquina</button>
      </div>
      <div class="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        ${rows.map(([label, value]) => `
          <article class="rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <p class="text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">${escapeHtml(label)}</p>
            <p class="mt-3 text-lg font-bold text-slate-900">${escapeHtml(value)}</p>
          </article>
        `).join('')}
      </div>
    </section>
  `;
}

function renderTools() {
  const canAccess = state.user?.permissions?.canAccessTools;
  if (!canAccess) {
    return `
      <section class="rounded-[2rem] border border-slate-200 bg-white p-10 text-center shadow-soft">
        <h3 class="text-2xl font-bold text-slate-900">Acesso restrito</h3>
        <p class="mt-3 text-sm text-slate-500">Seu usuário não possui acesso à biblioteca de ferramentas e ao ATC.</p>
      </section>
    `;
  }

  const tools = state.tools || [];
  const mergedTools = tools.map(tool => ({
    ...tool,
    type: tool.code === 'T2' ? 'Furação' : 'Corte'
  }));

  return `
    <section class="space-y-8">
      <section class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
        <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p class="text-xs font-semibold uppercase tracking-[0.35em] text-slate-400">ATC / Ferramentas</p>
            <h3 class="mt-2 text-2xl font-bold tracking-tight text-slate-900">Troca automática de ferramenta</h3>
            <p class="mt-2 text-sm leading-7 text-slate-500">O G-Code separa operações de <strong>T1 (Corte)</strong> e <strong>T2 (Furação)</strong> para um fluxo compatível com ATC.</p>
          </div>
          <button type="button" data-action="refresh-tools" class="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">Atualizar ferramentas</button>
        </div>
      </section>

      <div class="grid gap-5 xl:grid-cols-3">
        ${mergedTools.map(tool => `
          <article class="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-soft">
            <div class="flex items-start justify-between gap-3">
              <div>
                <p class="text-xs font-semibold uppercase tracking-[0.25em] text-slate-400">${escapeHtml(tool.code)}</p>
                <h4 class="mt-2 text-xl font-bold text-slate-900">${escapeHtml(tool.name)}</h4>
              </div>
              <span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold ${tool.type === 'Furação' ? 'bg-red-50 text-red-700 ring-1 ring-inset ring-red-200' : 'bg-slate-100 text-slate-700 ring-1 ring-inset ring-slate-200'}">${escapeHtml(tool.type)}</span>
            </div>
            <div class="mt-6 space-y-3 text-sm text-slate-600">
              <div class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3"><span>Diâmetro</span><strong class="text-slate-900">${escapeHtml(String(tool.diameterMm))} mm</strong></div>
              <div class="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3"><span>Uso no G-Code</span><strong class="text-slate-900">${tool.code === 'T2' ? 'Ciclos de furação' : 'Cortes internos/externos'}</strong></div>
            </div>
          </article>
        `).join('')}
      </div>
    </section>
  `;
}

function renderAuthenticatedShell(content) {
  return `
    <div class="min-h-screen xl:grid xl:grid-cols-[320px_1fr]">
      ${renderSidebar()}
      <div class="min-w-0">
        ${renderTopBar()}
        <main class="mx-auto max-w-[1800px] space-y-8 px-4 py-6 sm:px-6 lg:px-8">
          ${renderNotifications()}
          ${content}
        </main>
      </div>
    </div>
  `;
}

function render() {
  if (!ensureAuthenticatedRoute()) return;

  if (!state.dashboardToken) {
    app.innerHTML = renderLogin();
    return;
  }

  let content = '';
  if (state.route === '/home') {
    content = renderHome();
  } else if (state.route === '/projetos') {
    content = renderProjectsList();
  } else if (state.route.startsWith('/projetos/')) {
    content = renderProjectDetail();
  } else if (state.route === '/equipe') {
    content = renderTeam();
  } else if (state.route === '/maquina') {
    content = renderMachine();
  } else if (state.route === '/ferramentas') {
    content = renderTools();
  } else {
    content = renderHome();
  }

  app.innerHTML = renderAuthenticatedShell(content);
}

async function login(email, password) {
  const response = await apiFetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
  saveSession(response);
  pushNotification('success', 'Autenticação concluída', 'Sessão iniciada com sucesso.');
  await hydrateCoreData();
  try {
    await ensurePluginSession(true);
  } catch {
    // sessão do plugin será gerada manualmente se necessário
  }
  navigate('/home', { replace: true });
}

async function ensurePluginSession(silent = false) {
  if (!state.dashboardToken) {
    throw new Error('Faça login antes de gerar a sessão do plugin.');
  }

  const response = await apiFetch('/api/auth/plugin-session', {
    method: 'POST',
    body: JSON.stringify({ dashboardToken: state.dashboardToken })
  });

  state.pluginSession = response;

  const delivered = callSketchUpBridge(['onPluginSession'], response);
  if (!silent) {
    pushNotification('success', 'Sessão do plugin gerada', delivered
      ? 'O HtmlDialog recebeu a sessão e já pode enviar o projeto atual.'
      : 'Sessão criada com sucesso. Se você abrir no SketchUp, o plugin poderá recebê-la.');
  }

  render();
  return response;
}

async function hydrateCoreData() {
  await fetchProjects(true);
  if (state.user?.role === 'admin') {
    await fetchUsers(true);
  }
}

async function hydrateRoute() {
  if (!state.dashboardToken) return;

  if (state.route === '/home' || state.route === '/projetos' || state.route.startsWith('/projetos/')) {
    await fetchProjects(true);
  }

  if (state.route.startsWith('/projetos/')) {
    const slug = state.route.replace('/projetos/', '');
    await fetchProjectDetail(slug, true);
  }

  if (state.route === '/equipe' && state.user?.role === 'admin') {
    await fetchUsers(true);
  }

  if (state.route === '/maquina' && state.user?.permissions?.canAccessMachineSettings) {
    await fetchMachine(true);
  }

  if (state.route === '/ferramentas' && state.user?.permissions?.canAccessTools) {
    await fetchTools(true);
  }

  render();
}

async function fetchProjects(silent = false) {
  try {
    const payload = await apiFetch('/api/projects');
    state.projects = payload?.projects || payload || [];
    render();
  } catch (error) {
    if (!silent) pushNotification('error', 'Falha ao carregar projetos', error.message);
  }
}

async function fetchProjectDetail(slug, silent = false) {
  try {
    const payload = await apiFetch(`/api/projects/by-slug/${encodeURIComponent(slug)}`);
    const project = payload?.project || payload;
    if (project) {
      const parts = createSyntheticParts(project);
      state.projectDetails[slug] = {
        ...(state.projectDetails[slug] || {}),
        project,
        parts
      };
      const index = state.projects.findIndex(item => item.slug === slug);
      if (index >= 0) state.projects[index] = project;
    }
    render();
  } catch (error) {
    if (!silent) pushNotification('error', 'Falha ao carregar o projeto', error.message);
  }
}

async function fetchUsers(silent = false) {
  try {
    const payload = await apiFetch('/api/admin/users');
    state.users = payload?.users || [];
    render();
  } catch (error) {
    if (!silent) pushNotification('error', 'Falha ao carregar equipe', error.message);
  }
}

async function fetchMachine(silent = false) {
  try {
    const payload = await apiFetch('/api/machine-settings');
    state.machine = payload?.machine || null;
    render();
  } catch (error) {
    if (!silent) pushNotification('error', 'Falha ao carregar máquina', error.message);
  }
}

async function fetchTools(silent = false) {
  try {
    const payload = await apiFetch('/api/tools');
    state.tools = payload?.tools || [];
    render();
  } catch (error) {
    if (!silent) pushNotification('error', 'Falha ao carregar ferramentas', error.message);
  }
}

async function updateUserPermission(userId, permissionKey, value) {
  const current = state.users.find(item => item.userId === userId);
  if (!current) return;

  const payload = {
    canAccessMachineSettings: permissionKey === 'machine' ? value : !!current.permissions?.canAccessMachineSettings,
    canAccessTools: permissionKey === 'tools' ? value : !!current.permissions?.canAccessTools
  };

  try {
    await apiFetch(`/api/admin/users/${encodeURIComponent(userId)}/permissions`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
    pushNotification('success', 'Permissões atualizadas', `As permissões de ${current.name} foram atualizadas.`);
    await fetchUsers(true);
  } catch (error) {
    pushNotification('error', 'Falha ao atualizar permissões', error.message);
    render();
  }
}

async function updateProjectStatus(projectId, status) {
  try {
    const payload = await apiFetch(`/api/projects/${encodeURIComponent(projectId)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
    const project = payload?.project || payload;
    if (project) {
      const index = state.projects.findIndex(item => item.projectId === project.projectId);
      if (index >= 0) state.projects[index] = project;
      state.projectDetails[project.slug] = {
        ...(state.projectDetails[project.slug] || {}),
        project,
        parts: Array.isArray(project.parts) && project.parts.length
          ? project.parts.map((part, index) => normalizeProjectPart(part, index))
          : (state.projectDetails[project.slug]?.parts || createSyntheticParts(project))
      };
    }
    pushNotification('success', 'Status atualizado', `Projeto movido para ${statusLabel(status)}.`);
    render();
  } catch (error) {
    pushNotification('error', 'Falha ao atualizar o status', error.message);
  }
}

async function generateGCode(projectId) {
  try {
    const payload = await apiFetch(`/api/projects/${encodeURIComponent(projectId)}/generate-gcode`, {
      method: 'POST'
    });
    const currentProject = state.projects.find(item => item.projectId === projectId) || projectFromRoute();
    if (currentProject?.slug) {
      await fetchProjectDetail(currentProject.slug, true);
    }
    await fetchProjects(true);
    state.lastSyncResult = payload;
    pushNotification('success', 'G-Code gerado', payload?.message || 'Arquivo gerado com sucesso na pasta da máquina.');
    render();
  } catch (error) {
    pushNotification('error', 'Falha ao gerar G-Code', error.message);
  }
}

function registerPluginEvent(type, message, data) {
  state.pluginEvents.unshift({
    type,
    message,
    data,
    createdAt: formatDate(new Date().toISOString())
  });
  state.pluginEvents = state.pluginEvents.slice(0, 12);
}

async function requestSketchUpSync() {
  if (!state.pluginSession) {
    await ensurePluginSession(true);
  }

  const payload = {
    customerName: state.pendingCustomerName || 'Cliente SketchUp',
    projectName: state.pendingProjectName || 'Projeto SketchUp'
  };

  const delivered = callSketchUpBridge(['sincronizar', 'synchronizeCurrentProject', 'sendCurrentProject'], payload);
  if (delivered) {
    registerPluginEvent('info', 'Comando ENVIAR PROJETO disparado para o Ruby.', payload);
    pushNotification('info', 'Integração acionada', 'O HtmlDialog enviou o comando para o plugin SketchUp.');
    render();
    return;
  }

  pushNotification('info', 'Modo navegador externo', 'A interface está pronta, mas o callback do SketchUp só será executado dentro do HtmlDialog.');
}

function handlePluginEvent(payload) {
  const eventPayload = parseJsonSafe(payload, payload) || {};
  const type = eventPayload.type || 'info';
  const message = eventPayload.message || eventPayload.title || 'Evento recebido do plugin.';
  registerPluginEvent(type, message, eventPayload.data || eventPayload.payload || null);

  if (type === 'success') {
    pushNotification('success', 'SketchUp → Dashboard', message);
    const syncData = eventPayload.data || eventPayload.payload || null;
    if (syncData && (syncData.projectUrl || syncData.route || syncData.projectId)) {
      handlePluginSyncResult(syncData).catch(() => {
        // atualização complementar do dashboard
      });
    }
  } else if (type === 'error') {
    pushNotification('error', 'SketchUp → Dashboard', message);
  } else {
    pushNotification('info', 'SketchUp → Dashboard', message);
  }
}

async function handlePluginSyncResult(payload) {
  const data = parseJsonSafe(payload, payload) || {};
  state.lastSyncResult = data;
  registerPluginEvent('success', data.message || 'Projeto sincronizado com sucesso.', data);
  pushNotification('success', 'Projeto sincronizado', data.message || 'O projeto atual foi enviado para a nuvem.');
  await fetchProjects(true);

  const targetRoute = data.projectUrl || data.route;
  if (targetRoute) {
    navigate(targetRoute);
  } else {
    navigate('/projetos');
  }
}

window.handlePluginEvent = handlePluginEvent;
window.handlePluginSyncResult = handlePluginSyncResult;
window.handlePluginSessionAck = function handlePluginSessionAck(payload) {
  const data = parseJsonSafe(payload, payload) || {};
  if (data?.token) {
    state.pluginSession = data;
  }
  registerPluginEvent('success', 'Sessão do plugin confirmada pelo Ruby.', data);
  render();
};

window.addEventListener('popstate', () => {
  state.route = normalizeRoute(window.location.pathname || '/');
  render();
  hydrateRoute().catch(error => pushNotification('error', 'Falha ao navegar', error.message));
});

document.addEventListener('click', async event => {
  const actionElement = event.target.closest('[data-action]');
  if (!actionElement) return;

  const { action } = actionElement.dataset;

  if (action === 'navigate') {
    navigate(actionElement.dataset.path || '/');
    return;
  }

  if (action === 'dismiss-notification') {
    state.notifications = (state.notifications || []).filter(item => item.id !== actionElement.dataset.id);
    render();
    return;
  }

  if (action === 'logout') {
    clearSession();
    pushNotification('info', 'Sessão encerrada', 'Você saiu da plataforma.');
    navigate('/', { replace: true });
    return;
  }

  if (action === 'generate-plugin-session') {
    try {
      await ensurePluginSession(false);
    } catch (error) {
      pushNotification('error', 'Falha ao gerar sessão do plugin', error.message);
    }
    return;
  }

  if (action === 'send-project') {
    try {
      await requestSketchUpSync();
    } catch (error) {
      pushNotification('error', 'Falha ao enviar projeto', error.message);
    }
    return;
  }

  if (action === 'refresh-projects') {
    await fetchProjects();
    pushNotification('success', 'Projetos atualizados', 'A lista de projetos foi sincronizada novamente.');
    return;
  }

  if (action === 'refresh-users') {
    await fetchUsers();
    pushNotification('success', 'Equipe atualizada', 'A lista de usuários foi atualizada.');
    return;
  }

  if (action === 'refresh-machine') {
    await fetchMachine();
    pushNotification('success', 'Máquina atualizada', 'Os parâmetros da CNC foram recarregados.');
    return;
  }

  if (action === 'refresh-tools') {
    await fetchTools();
    pushNotification('success', 'Ferramentas atualizadas', 'A biblioteca de ferramentas foi recarregada.');
    return;
  }

  if (action === 'open-project') {
    navigate(`/projetos/${actionElement.dataset.slug}`);
    return;
  }

  if (action === 'toggle-menu') {
    const projectId = actionElement.dataset.projectId;
    state.menuProjectId = state.menuProjectId === projectId ? null : projectId;
    render();
    return;
  }

  if (action === 'select-nesting-board') {
    state.nestingBoardIndex = Number(actionElement.dataset.boardIndex || 0);
    render();
    return;
  }

  if (action === 'generate-gcode') {
    await generateGCode(actionElement.dataset.projectId);
    return;
  }
});

document.addEventListener('change', async event => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;

  if (target.id === 'pending-project-name') {
    state.pendingProjectName = target.value;
    return;
  }

  if (target.id === 'pending-customer-name') {
    state.pendingCustomerName = target.value;
    return;
  }

  if (target.id === 'nesting-material-filter') {
    state.nestingMaterialFilter = target.value || 'all';
    state.nestingBoardIndex = 0;
    render();
    return;
  }

  if (target.dataset.action === 'project-status') {
    await updateProjectStatus(target.dataset.projectId, target.value);
    return;
  }

  if (target.dataset.action === 'toggle-machine-permission') {
    await updateUserPermission(target.dataset.userId, 'machine', !!target.checked);
    return;
  }

  if (target.dataset.action === 'toggle-tools-permission') {
    await updateUserPermission(target.dataset.userId, 'tools', !!target.checked);
  }
});

document.addEventListener('input', event => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;

  if (target.id === 'pending-project-name') {
    state.pendingProjectName = target.value;
  }

  if (target.id === 'pending-customer-name') {
    state.pendingCustomerName = target.value;
  }
});

document.addEventListener('submit', async event => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  if (form.id !== 'login-form') return;

  event.preventDefault();
  const submitButton = form.querySelector('button[type="submit"]');
  if (submitButton) submitButton.setAttribute('disabled', 'disabled');

  try {
    const email = form.querySelector('#email')?.value?.trim() || '';
    const password = form.querySelector('#password')?.value || '';
    if (!email || !password) {
      throw new Error('Informe seu e-mail e sua senha para entrar.');
    }
    await login(email, password);
  } catch (error) {
    pushNotification('error', 'Falha na autenticação', error.message || 'Não foi possível entrar.');
    render();
  } finally {
    if (submitButton) submitButton.removeAttribute('disabled');
  }
});

restoreSession();
state.notifications = [];
render();
hydrateRoute().catch(error => {
  pushNotification('error', 'Falha ao iniciar a plataforma', error.message || 'Erro inesperado.');
});
