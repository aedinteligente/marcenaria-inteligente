# Notas internas de acesso

As credenciais de demonstração e validação do ambiente local foram removidas da interface pública de login do dashboard por exigência de segurança e usabilidade.

## Diretriz aplicada

Nenhuma senha ou combinação de usuário de teste deve aparecer na tela pública de entrada. O formulário de login deve permanecer vazio, exigindo digitação manual das credenciais.

## Uso interno

As contas internas de validação, quando necessárias para homologação local, devem ser consultadas apenas por mantenedores autorizados do projeto e nunca exibidas no frontend público.

## Observação operacional

Se houver necessidade futura de suporte guiado, criar um fluxo autenticado ou uma página de ajuda restrita, sem expor senhas diretamente no dashboard inicial.
