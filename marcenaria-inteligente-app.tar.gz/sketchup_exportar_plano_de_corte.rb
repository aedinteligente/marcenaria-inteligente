require 'json'
require 'time'
require 'uri'
require 'fileutils'
require 'sketchup.rb'

module MarcenariaInteligente
  module CloudSync
    extend self

    PLUGIN_VERSION = '0.4.0'.freeze
    DIALOG_KEY = 'marcenaria-inteligente-dashboard'.freeze
    PREF_NAMESPACE = 'MarcenariaInteligenteCloudSync'.freeze
    PREF_BASE_URL = 'base_url'.freeze
    PREF_PLUGIN_TOKEN = 'plugin_token'.freeze
    PREF_PLUGIN_TOKEN_EXPIRES_AT = 'plugin_token_expires_at'.freeze
    PREF_SYNC_URL = 'sync_url'.freeze
    PREF_DASHBOARD_URL = 'dashboard_url'.freeze
    PREF_MACHINE_ROOT = 'machine_root'.freeze
    PREF_LAST_PROJECT_FOLDER = 'last_project_folder'.freeze
    DEFAULT_BASE_URL = 'https://charged-dealing-assets-radius.trycloudflare.com'.freeze
    DEFAULT_MACHINE_ROOT = 'C:/CNC'.freeze

    EDGE_BOOLEAN_CANDIDATES = {
      top: %w[edge_top top_edge fita_topo fita_superior borda_topo borda_superior],
      bottom: %w[edge_bottom bottom_edge fita_base fita_inferior borda_base borda_inferior],
      left: %w[edge_left left_edge fita_esquerda borda_esquerda],
      right: %w[edge_right right_edge fita_direita borda_direita]
    }.freeze

    EDGE_MATERIAL_CANDIDATES = {
      top: %w[edge_top_material top_edge_material fita_topo_material fita_superior_material borda_topo_material],
      bottom: %w[edge_bottom_material bottom_edge_material fita_base_material fita_inferior_material borda_base_material],
      left: %w[edge_left_material left_edge_material fita_esquerda_material borda_esquerda_material],
      right: %w[edge_right_material right_edge_material fita_direita_material borda_direita_material]
    }.freeze

    MATERIAL_CANDIDATES = %w[
      material
      material_code
      material_name
      material_exacto
      material_exato
      materia_prima
      materia_prima_codigo
      chapa_material
      board_material
    ].freeze

    def open_dashboard
      dialog = ensure_dialog
      dialog.set_url(dashboard_url)
      dialog.show
      dialog.bring_to_front if dialog.respond_to?(:bring_to_front)
      notify_dialog('info', 'Dashboard profissional carregado no HtmlDialog do SketchUp.', {
        dashboardUrl: dashboard_url,
        pluginVersion: PLUGIN_VERSION,
        machineRoot: machine_root_path
      })
    rescue => error
      log("Falha ao abrir HtmlDialog: #{error.class}: #{error.message}")
    end

    def ensure_dialog
      return @dialog if @dialog

      @dialog = UI::HtmlDialog.new(
        dialog_title: 'Marcenaria Inteligente',
        preferences_key: DIALOG_KEY,
        scrollable: true,
        resizable: true,
        width: 1280,
        height: 840,
        style: UI::HtmlDialog::STYLE_DIALOG
      )

      @dialog.add_action_callback('onPluginSession') do |_context, raw_payload|
        handle_plugin_session(raw_payload)
      end

      @dialog.add_action_callback('sendCurrentProject') do |_context, raw_payload|
        handle_send_request(raw_payload)
      end

      @dialog.add_action_callback('synchronizeCurrentProject') do |_context, raw_payload|
        handle_send_request(raw_payload)
      end

      @dialog.add_action_callback('sincronizar') do |_context, raw_payload|
        handle_send_request(raw_payload)
      end

      @dialog.add_action_callback('closeDialog') do |_context, _payload|
        @dialog&.close
      end

      @dialog.add_action_callback('refreshDashboard') do |_context, _payload|
        @dialog.set_url(dashboard_url)
      end

      @dialog
    end

    def handle_plugin_session(raw_payload)
      payload = parse_json(raw_payload)
      unless payload.is_a?(Hash) && payload['ok']
        notify_dialog('error', 'O dashboard não retornou uma sessão válida para o plugin.')
        return
      end

      token = payload['token'].to_s
      expires_in_ms = payload['expiresInMs'].to_i
      sync_url_value = payload['syncUrl'].to_s
      dashboard_url_value = payload['dashboardUrl'].to_s

      if token.empty?
        notify_dialog('error', 'O dashboard não retornou um token de autenticação para o plugin.')
        return
      end

      write_pref(PREF_PLUGIN_TOKEN, token)
      write_pref(PREF_PLUGIN_TOKEN_EXPIRES_AT, (Time.now + (expires_in_ms / 1000.0)).utc.iso8601)
      write_pref(PREF_SYNC_URL, sync_url_value)
      write_pref(PREF_DASHBOARD_URL, dashboard_url_value)

      notify_dialog('success', 'Sessão do plugin recebida com sucesso. O botão ENVIAR PROJETO já pode ser utilizado.', {
        tokenPreview: token[0, 12],
        syncUrl: sync_url_value,
        dashboardUrl: dashboard_url_value
      })
    rescue => error
      log("Falha ao processar sessão do plugin: #{error.class}: #{error.message}")
      notify_dialog('error', 'Falha ao processar a sessão recebida do dashboard.')
    end

    def handle_send_request(raw_payload)
      request_payload = parse_json(raw_payload)

      unless plugin_token_valid?
        notify_dialog('error', 'O envio do projeto foi bloqueado porque o token do plugin está ausente ou expirado.')
        return
      end

      model = Sketchup.active_model
      entities = selected_exportable_entities(model)
      if entities.empty?
        entities = model.entities.grep(Sketchup::ComponentInstance) + model.entities.grep(Sketchup::Group)
      end

      if entities.empty?
        notify_dialog('error', 'Nenhum componente ou grupo exportável foi encontrado no projeto atual.')
        return
      end

      payload = build_payload(model, entities, request_payload)
      local_project_folder = ensure_local_project_folder(payload[:project][:name])
      payload[:metadata] ||= {}
      payload[:metadata][:extra] ||= {}
      payload[:metadata][:extra][:localProjectFolder] = local_project_folder unless blank?(local_project_folder)

      @pending_project_context = {
        projectName: payload[:project][:name],
        customerName: payload[:project][:customerName],
        localProjectFolder: local_project_folder
      }

      notify_dialog('info', 'Projeto extraído do SketchUp. Executando POST direto para a nuvem.', {
        projectName: payload[:project][:name],
        partCount: payload[:parts].length,
        materialCount: payload[:materials].length,
        localProjectFolder: local_project_folder
      })

      send_payload_to_cloud(payload)
    rescue => error
      log("Falha ao enviar o projeto atual: #{error.class}: #{error.message}")
      log(error.backtrace.join("\n")) if error.backtrace
      notify_dialog('error', 'Ocorreu uma falha durante o envio do projeto atual.')
    end

    def selected_exportable_entities(model)
      model.selection.to_a.select do |entity|
        entity.is_a?(Sketchup::ComponentInstance) || entity.is_a?(Sketchup::Group)
      end
    end

    def build_payload(model, entities, request_payload = {})
      materials_index = {}
      parts = entities.each_with_index.map do |entity, index|
        part = extract_part(entity, index + 1)
        materials_index[part[:material][:code]] ||= part.delete(:material)
        part
      end

      project_name = request_payload['projectName'].to_s.strip
      customer_name = request_payload['customerName'].to_s.strip
      project_name = model.title.to_s.strip if project_name.empty?
      project_name = File.basename(model.path.to_s, '.*') if project_name.empty? && !model.path.to_s.empty?
      project_name = 'Projeto SketchUp' if project_name.empty?

      {
        tenantId: 'tenant-local',
        source: 'sketchup',
        pluginVersion: PLUGIN_VERSION,
        sketchUpVersion: sketchup_version,
        project: {
          externalProjectId: safe_model_guid(model),
          name: project_name,
          customerName: customer_name,
          designerName: model.get_attribute('dynamic_attributes', 'designer_name'),
          unit: 'mm',
          notes: 'Fluxo profissional via HtmlDialog, callback Ruby e POST HTTP direto para a nuvem.'
        },
        parts: parts,
        materials: materials_index.values,
        metadata: {
          exportedAt: Time.now.utc.iso8601,
          hash: nil,
          extra: {
            selectionCount: entities.length.to_s,
            modelName: model.title.to_s,
            modelPath: model.path.to_s,
            machineRoot: machine_root_path
          }
        }
      }
    end

    def extract_part(entity, ordinal)
      all_attributes = extract_attributes(entity)
      dimensions = component_dimensions_mm(entity)
      world_origin = entity.transformation.origin rescue Geom::Point3d.new(0, 0, 0)
      material_name = exact_material_name(entity, all_attributes)
      part_name = part_display_name(entity, ordinal)

      {
        partId: persistent_id_for(entity, ordinal),
        name: part_name,
        sku: find_attribute_value(all_attributes, %w[sku codigo codigo_peca part_code]),
        parentAssembly: entity.respond_to?(:definition) ? entity.definition&.name : nil,
        materialCode: slug(material_name),
        lengthMm: dimensions[:x],
        widthMm: dimensions[:y],
        thicknessMm: dimensions[:z],
        quantity: 1,
        canRotateInNesting: true,
        grainDirectionRequired: truthy_attribute?(all_attributes, %w[grain_direction_required veio_obrigatorio sentido_veio]),
        grainDirection: find_attribute_value(all_attributes, %w[grain_direction sentido_veio]),
        frontFace: find_attribute_value(all_attributes, %w[front_face face_frontal]),
        partType: entity.is_a?(Sketchup::Group) ? 'group' : 'component',
        label: part_name,
        barcode: persistent_id_for(entity, ordinal),
        position: {
          x: to_mm(world_origin.x),
          y: to_mm(world_origin.y),
          z: to_mm(world_origin.z),
          rotationX: 0,
          rotationY: 0,
          rotationZ: rotation_z(entity)
        },
        edgeBanding: extract_edge_banding(all_attributes),
        machining: extract_machining(entity),
        attributes: all_attributes,
        material: {
          code: slug(material_name),
          name: material_name,
          category: 'sheet',
          thicknessMm: dimensions[:z],
          defaultBoardLengthMm: 2750,
          defaultBoardWidthMm: 1830,
          grainDirectionRequired: truthy_attribute?(all_attributes, %w[grain_direction_required veio_obrigatorio sentido_veio]),
          color: find_attribute_value(all_attributes, %w[color cor]),
          supplier: find_attribute_value(all_attributes, %w[supplier fornecedor])
        }
      }
    end

    def component_dimensions_mm(entity)
      definition = entity.respond_to?(:definition) ? entity.definition : nil
      local_bounds = definition ? definition.bounds : entity.bounds
      transformation = entity.transformation

      {
        x: to_mm(local_bounds.width * axis_scale(transformation.xaxis)),
        y: to_mm(local_bounds.depth * axis_scale(transformation.yaxis)),
        z: to_mm(local_bounds.height * axis_scale(transformation.zaxis))
      }
    rescue => error
      log("Falha ao calcular dimensões locais da peça: #{error.class}: #{error.message}")
      bounds = entity.bounds
      {
        x: to_mm(bounds.width),
        y: to_mm(bounds.depth),
        z: to_mm(bounds.height)
      }
    end

    def axis_scale(vector)
      vector.length.to_f
    rescue
      1.0
    end

    def exact_material_name(entity, all_attributes)
      from_attributes = find_attribute_value(all_attributes, MATERIAL_CANDIDATES)
      return from_attributes unless blank?(from_attributes)

      material = entity.material&.display_name
      return material unless blank?(material)

      definition_material = entity.respond_to?(:definition) ? entity.definition&.material&.display_name : nil
      return definition_material unless blank?(definition_material)

      'MATERIAL-NAO-INFORMADO'
    end

    def part_display_name(entity, ordinal)
      raw = entity.name.to_s.strip
      raw = entity.definition&.name.to_s.strip if raw.empty? && entity.respond_to?(:definition)
      raw = "Peça #{ordinal}" if raw.empty?
      raw
    end

    def extract_edge_banding(all_attributes)
      {
        top: build_edge_band_side(:top, all_attributes),
        bottom: build_edge_band_side(:bottom, all_attributes),
        left: build_edge_band_side(:left, all_attributes),
        right: build_edge_band_side(:right, all_attributes)
      }
    end

    def build_edge_band_side(side, all_attributes)
      material_code = find_attribute_value(all_attributes, EDGE_MATERIAL_CANDIDATES.fetch(side))
      enabled = truthy_attribute?(all_attributes, EDGE_BOOLEAN_CANDIDATES.fetch(side)) || !blank?(material_code)

      {
        enabled: enabled,
        materialCode: blank?(material_code) ? nil : material_code,
        thicknessMm: enabled ? numeric_attribute_value(all_attributes, ["#{side}_edge_thickness", "fita_#{side}_espessura"], 1.0) : 0.0,
        widthMm: enabled ? numeric_attribute_value(all_attributes, ["#{side}_edge_width", "fita_#{side}_largura"], 22.0) : 0.0,
        color: find_attribute_value(all_attributes, ["#{side}_edge_color", "fita_#{side}_cor"])
      }
    end

    def extract_machining(entity)
      entities = geometry_entities(entity)
      return [] unless entities

      panel_face = primary_panel_face(entities)
      return fallback_machining(entity, entities) unless panel_face

      operations = []
      face_label = panel_face.normal.z >= 0 ? 'top' : 'bottom'
      thickness = component_dimensions_mm(entity)[:z]

      panel_face.loops.each_with_index do |loop, loop_index|
        if loop.outer?
          loop.edges.each_with_index do |edge, edge_index|
            start_point = world_point(edge.start.position, entity.transformation)
            end_point = world_point(edge.end.position, entity.transformation)
            operations << {
              operationId: "#{persistent_id_for(entity, 0)}-outer-#{loop_index + 1}-#{edge_index + 1}",
              type: 'external_cut',
              face: face_label,
              startXmm: to_mm(start_point.x),
              startYmm: to_mm(start_point.y),
              endXmm: to_mm(end_point.x),
              endYmm: to_mm(end_point.y),
              lengthMm: to_mm(edge.length),
              depthMm: thickness,
              toolCode: 'T1'
            }
          end
        elsif circular_loop?(loop)
          center = loop_center(loop, entity.transformation)
          diameter = circular_loop_diameter(loop, entity.transformation)
          operations << {
            operationId: "#{persistent_id_for(entity, 0)}-drill-#{loop_index + 1}",
            type: 'drilling',
            face: face_label,
            centerXmm: to_mm(center.x),
            centerYmm: to_mm(center.y),
            diameterMm: diameter,
            depthMm: thickness,
            toolCode: 'T2'
          }
        else
          loop.edges.each_with_index do |edge, edge_index|
            start_point = world_point(edge.start.position, entity.transformation)
            end_point = world_point(edge.end.position, entity.transformation)
            operations << {
              operationId: "#{persistent_id_for(entity, 0)}-inner-#{loop_index + 1}-#{edge_index + 1}",
              type: 'internal_cut',
              face: face_label,
              startXmm: to_mm(start_point.x),
              startYmm: to_mm(start_point.y),
              endXmm: to_mm(end_point.x),
              endYmm: to_mm(end_point.y),
              lengthMm: to_mm(edge.length),
              depthMm: thickness,
              toolCode: 'T1'
            }
          end
        end
      end

      operations
    rescue => error
      log("Falha ao extrair usinagem da peça #{persistent_id_for(entity, 0)}: #{error.class}: #{error.message}")
      []
    end

    def fallback_machining(entity, entities)
      operations = []
      thickness = component_dimensions_mm(entity)[:z]

      entities.grep(Sketchup::Edge).uniq.each_with_index do |edge, index|
        start_point = world_point(edge.start.position, entity.transformation)
        end_point = world_point(edge.end.position, entity.transformation)
        curve = edge.curve

        if curve.is_a?(Sketchup::ArcCurve)
          center = world_point(curve.center, entity.transformation)
          operations << {
            operationId: "#{persistent_id_for(entity, 0)}-fallback-drill-#{index + 1}",
            type: 'drilling',
            face: 'top',
            centerXmm: to_mm(center.x),
            centerYmm: to_mm(center.y),
            diameterMm: to_mm(curve.radius * 2),
            depthMm: thickness,
            toolCode: 'T2'
          }
        else
          operations << {
            operationId: "#{persistent_id_for(entity, 0)}-fallback-cut-#{index + 1}",
            type: 'external_cut',
            face: 'top',
            startXmm: to_mm(start_point.x),
            startYmm: to_mm(start_point.y),
            endXmm: to_mm(end_point.x),
            endYmm: to_mm(end_point.y),
            lengthMm: to_mm(edge.length),
            depthMm: thickness,
            toolCode: 'T1'
          }
        end
      end

      operations
    end

    def geometry_entities(entity)
      return entity.entities if entity.is_a?(Sketchup::Group)
      return entity.definition.entities if entity.respond_to?(:definition) && entity.definition

      nil
    end

    def primary_panel_face(entities)
      entities.grep(Sketchup::Face).max_by(&:area)
    end

    def circular_loop?(loop)
      curves = loop.edges.map(&:curve).compact.uniq
      return false if curves.empty?

      curves.all? { |curve| curve.is_a?(Sketchup::ArcCurve) }
    end

    def loop_center(loop, transformation)
      points = loop.vertices.map { |vertex| world_point(vertex.position, transformation) }
      average_x = points.sum(&:x) / points.length.to_f
      average_y = points.sum(&:y) / points.length.to_f
      average_z = points.sum(&:z) / points.length.to_f
      Geom::Point3d.new(average_x, average_y, average_z)
    end

    def circular_loop_diameter(loop, transformation)
      center = loop_center(loop, transformation)
      distances = loop.vertices.map do |vertex|
        point = world_point(vertex.position, transformation)
        point.distance(center)
      end
      radius = distances.sum / distances.length.to_f
      to_mm(radius * 2)
    rescue
      0.0
    end

    def extract_attributes(entity)
      attributes = {}
      sources = [entity]
      sources << entity.definition if entity.respond_to?(:definition) && entity.definition

      sources.compact.each do |source|
        dictionaries = source.attribute_dictionaries
        next unless dictionaries

        dictionaries.each do |dictionary|
          dictionary.each_pair do |key, value|
            full_key = "#{dictionary.name}.#{key}"
            attributes[full_key] = value.to_s
            short_key = normalize_key(key)
            attributes[short_key] = value.to_s if blank?(attributes[short_key])
          end
        end
      end

      attributes
    end

    def find_attribute_value(attributes, candidates)
      candidates.each do |candidate|
        exact = attributes[candidate]
        return exact.to_s unless blank?(exact)

        normalized_candidate = normalize_key(candidate)
        normalized = attributes[normalized_candidate]
        return normalized.to_s unless blank?(normalized)

        fuzzy_match = attributes.find do |key, value|
          normalize_key(key).include?(normalized_candidate) && !blank?(value)
        end
        return fuzzy_match[1].to_s if fuzzy_match
      end

      nil
    end

    def truthy_attribute?(attributes, candidates)
      value = find_attribute_value(attributes, candidates)
      %w[1 true yes sim y].include?(value.to_s.strip.downcase)
    end

    def numeric_attribute_value(attributes, candidates, fallback)
      value = find_attribute_value(attributes, candidates)
      return fallback if blank?(value)

      value.to_s.tr(',', '.').to_f.round(3)
    rescue
      fallback
    end

    def send_payload_to_cloud(payload)
      request = Sketchup::Http::Request.new(sync_url, Sketchup::Http::POST)
      request.headers = {
        'Content-Type' => 'application/json; charset=utf-8',
        'Accept' => 'application/json',
        'Authorization' => "Bearer #{plugin_token}",
        'X-Plugin-Version' => PLUGIN_VERSION,
        'X-Plugin-Source' => 'SketchUp'
      }
      request.body = JSON.generate(payload)

      request.start do |_request, response|
        handle_sync_response(response)
      end
    rescue => error
      log("Falha no POST HTTP direto para a API: #{error.class}: #{error.message}")
      notify_dialog('error', 'Falha ao enviar o projeto diretamente para a nuvem.')
    end

    def handle_sync_response(response)
      status_code = response.status_code.to_i
      body = parse_json(response.body)

      if status_code >= 200 && status_code < 300
        payload = body.merge(@pending_project_context || {})
        notify_dialog('success', body['message'].to_s.empty? ? 'Projeto enviado com sucesso.' : body['message'].to_s, payload)
      else
        message = body['message'].to_s
        message = "A API respondeu com HTTP #{status_code}." if message.empty?
        notify_dialog('error', message, body)
      end
    rescue => error
      log("Falha ao interpretar resposta da API: #{error.class}: #{error.message}")
      notify_dialog('error', 'Falha ao interpretar a resposta da API de sincronização.')
    ensure
      @pending_project_context = nil
    end

    def ensure_local_project_folder(project_name)
      folder_name = safe_folder_name(project_name)
      folder_path = File.join(machine_root_path, folder_name)
      FileUtils.mkdir_p(folder_path)
      write_pref(PREF_LAST_PROJECT_FOLDER, folder_path)
      folder_path
    rescue => error
      log("Falha ao criar a pasta local do projeto: #{error.class}: #{error.message}")
      nil
    end

    def machine_root_path
      value = read_pref(PREF_MACHINE_ROOT, DEFAULT_MACHINE_ROOT).to_s.strip
      blank?(value) ? DEFAULT_MACHINE_ROOT : value
    end

    def safe_folder_name(value)
      cleaned = value.to_s.strip
      cleaned = 'Projeto SketchUp' if cleaned.empty?
      cleaned = cleaned.gsub(/[\\\/:*?"<>|]/, ' ')
      cleaned = cleaned.gsub(/\s+/, ' ').strip
      cleaned.empty? ? 'Projeto SketchUp' : cleaned
    end

    def notify_dialog(type, message, payload = {})
      return unless @dialog

      event_payload = JSON.generate({ type: type, message: message, payload: payload })
      script = "window.handlePluginEvent && window.handlePluginEvent(#{event_payload});"
      @dialog.execute_script(script)
    rescue => error
      log("Falha ao notificar HtmlDialog: #{error.class}: #{error.message}")
    end

    def plugin_token_valid?
      token = plugin_token
      expires_at = read_pref(PREF_PLUGIN_TOKEN_EXPIRES_AT, '').to_s
      return false if blank?(token) || blank?(expires_at)

      Time.parse(expires_at) > Time.now
    rescue
      false
    end

    def plugin_token
      read_pref(PREF_PLUGIN_TOKEN, '').to_s
    end

    def sync_url
      value = read_pref(PREF_SYNC_URL, '').to_s
      blank?(value) ? "#{base_url}/api/plugin/cloud-sync" : value
    end

    def dashboard_url
      value = read_pref(PREF_DASHBOARD_URL, '').to_s
      blank?(value) ? "#{base_url}/" : value
    end

    def base_url
      normalize_base_url(read_pref(PREF_BASE_URL, DEFAULT_BASE_URL))
    end

    def normalize_base_url(value)
      value.to_s.strip.sub(%r{/+$}, '')
    end

    def safe_model_guid(model)
      return model.guid.to_s unless blank?(model.guid)

      "model-#{Time.now.to_i}"
    rescue
      "model-#{Time.now.to_i}"
    end

    def world_point(point, transformation)
      point.transform(transformation)
    rescue
      point
    end

    def normalize_key(key)
      key.to_s.downcase.gsub(/[^a-z0-9]+/, '_').gsub(/^_+|_+$/, '')
    end

    def blank?(value)
      value.nil? || value.to_s.strip.empty?
    end

    def persistent_id_for(entity, fallback)
      return entity.persistent_id.to_s if entity.respond_to?(:persistent_id)

      "part-#{fallback}"
    end

    def rotation_z(entity)
      transformation = entity.transformation
      x_axis = transformation.xaxis
      radians = Math.atan2(x_axis.y, x_axis.x)
      (radians * 180.0 / Math::PI).round(3)
    rescue
      0.0
    end

    def to_mm(length)
      return 0.0 if length.nil?
      return length.to_mm.to_f.round(3) if length.respond_to?(:to_mm)

      length.to_f.round(3)
    rescue
      length.to_f.round(3)
    end

    def sketchup_version
      Sketchup.version.to_s
    rescue
      'unknown'
    end

    def slug(value)
      text = value.to_s.strip.downcase
      text = text.gsub(/[^a-z0-9]+/, '-')
      text = text.gsub(/^-+|-+$/, '')
      text.empty? ? 'material-nao-informado' : text
    end

    def parse_json(raw_payload)
      return {} if raw_payload.nil? || raw_payload.to_s.strip.empty?

      JSON.parse(raw_payload)
    rescue JSON::ParserError
      {}
    end

    def write_pref(key, value)
      Sketchup.write_default(PREF_NAMESPACE, key, value)
    end

    def read_pref(key, default_value = nil)
      Sketchup.read_default(PREF_NAMESPACE, key, default_value)
    end

    def log(message)
      puts("[MarcenariaInteligente] #{message}")
    end

    unless file_loaded?(__FILE__)
      submenu = UI.menu('Plugins').add_submenu('Marcenaria Inteligente')
      submenu.add_item('Abrir Dashboard Web') { open_dashboard }
      file_loaded(__FILE__)
    end
  end
end
