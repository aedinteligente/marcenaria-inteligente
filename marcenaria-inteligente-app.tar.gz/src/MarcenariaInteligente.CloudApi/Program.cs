using System.Text.Json.Serialization;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.Extensions.FileProviders;

var webRootPath = ResolveWebRootPath();
var builderOptions = new WebApplicationOptions
{
    Args = args,
    WebRootPath = webRootPath
};

var builder = WebApplication.CreateBuilder(builderOptions);
builder.WebHost.UseUrls($"http://0.0.0.0:{Environment.GetEnvironmentVariable("PORT") ?? "8080"}");

builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        options.JsonSerializerOptions.WriteIndented = true;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHealthChecks();
builder.Services.AddCors(options =>
{
    options.AddPolicy("SpaAndPlugin", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.Configure<DashboardOptions>(builder.Configuration.GetSection(DashboardOptions.SectionName));
builder.Services.AddSingleton<IAuthSessionService, InMemoryAuthSessionService>();
builder.Services.AddSingleton<IProjectCatalogService, InMemoryProjectCatalogService>();

var app = builder.Build();
var staticFileProvider = new PhysicalFileProvider(webRootPath);

app.UseDefaultFiles(new DefaultFilesOptions
{
    FileProvider = staticFileProvider
});

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = staticFileProvider
});

app.UseRouting();
app.UseCors("SpaAndPlugin");

app.MapHealthChecks("/health");
app.MapControllers();

app.MapFallback(async context =>
{
    if (context.Request.Path.StartsWithSegments("/api") ||
        context.Request.Path.StartsWithSegments("/health"))
    {
        context.Response.StatusCode = StatusCodes.Status404NotFound;
        await context.Response.WriteAsJsonAsync(new
        {
            ok = false,
            message = "Endpoint nao encontrado."
        });
        return;
    }

    var indexFile = Path.Combine(webRootPath, "index.html");
    if (!File.Exists(indexFile))
    {
        context.Response.StatusCode = StatusCodes.Status404NotFound;
        await context.Response.WriteAsync("Arquivo index.html nao encontrado.");
        return;
    }

    context.Response.ContentType = "text/html; charset=utf-8";
    await context.Response.SendFileAsync(indexFile);
});

app.Run();

static string ResolveWebRootPath()
{
    var candidates = new[]
    {
        Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"),
        Path.Combine(AppContext.BaseDirectory, "wwwroot"),
        Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "wwwroot"),
        Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "..", "..", "src", "MarcenariaInteligente.CloudApi", "wwwroot")
    };

    foreach (var candidate in candidates)
    {
        var fullPath = Path.GetFullPath(candidate);
        if (Directory.Exists(fullPath) && File.Exists(Path.Combine(fullPath, "index.html")))
        {
            return fullPath;
        }
    }

    throw new DirectoryNotFoundException("Nao foi possivel localizar o diretório wwwroot da aplicação.");
}
