namespace MarcenariaInteligente.CloudApi.Contracts;

public static class ProjectStatusValues
{
    public const string Draft = "rascunho";
    public const string InProduction = "em_producao";

    public static string Normalize(string? value)
    {
        var raw = (value ?? string.Empty).Trim().ToLowerInvariant();
        return raw switch
        {
            "" => Draft,
            "rascunho" => Draft,
            "draft" => Draft,
            "em_producao" => InProduction,
            "em-producao" => InProduction,
            "em produção" => InProduction,
            "producao" => InProduction,
            "produção" => InProduction,
            "production" => InProduction,
            _ => raw
        };
    }

    public static bool IsValid(string? value)
    {
        var normalized = Normalize(value);
        return normalized is Draft or InProduction;
    }
}

public sealed class ProjectSummaryDto
{
    public int PartCount { get; set; }
    public int MaterialCount { get; set; }
    public int MachiningOperationCount { get; set; }
    public int DrillingOperationCount { get; set; }
    public int ExternalCutOperationCount { get; set; }
    public int InternalCutOperationCount { get; set; }
    public int BoardCount { get; set; }
    public decimal UtilizationPct { get; set; }
    public int UnplacedParts { get; set; }
    public decimal EstimatedMachineTimeMinutes { get; set; }
    public decimal TotalDisplacementMeters { get; set; }
    public int PassCount { get; set; }
    public decimal AverageSpeedMetersPerMinute { get; set; }
}

public class ProjectListItemDto
{
    public Guid ProjectId { get; set; }
    public string Slug { get; set; } = string.Empty;
    public string Route { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Status { get; set; } = ProjectStatusValues.Draft;
    public bool CanGenerateGCode { get; set; }
    public string Source { get; set; } = string.Empty;
    public string SyncedBy { get; set; } = string.Empty;
    public string? LocalProductionFolder { get; set; }
    public string? LastGeneratedGCodeFileName { get; set; }
    public string? LastGeneratedGCodePath { get; set; }
    public DateTimeOffset? LastGeneratedAtUtc { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset UpdatedAtUtc { get; set; }
    public ProjectSummaryDto Summary { get; set; } = new();
}

public sealed class ProjectDetailDto : ProjectListItemDto
{
    public string ExternalProjectId { get; set; } = string.Empty;
    public string? DesignerName { get; set; }
    public string? Unit { get; set; } = "mm";
    public string? Notes { get; set; }
    public string? MachinePostProcessor { get; set; }
    public string? ImportHash { get; set; }
    public DateTimeOffset? ImportedAtUtc { get; set; }
    public IReadOnlyList<ProjectPartDto> Parts { get; set; } = Array.Empty<ProjectPartDto>();
    public IReadOnlyList<MaterialDto> Materials { get; set; } = Array.Empty<MaterialDto>();
    public ProjectNestingDto Nesting { get; set; } = new();
    public ProjectProductionOrderDto ProductionOrder { get; set; } = new();
}

public sealed class ProjectPartDto
{
    public int Item { get; set; }
    public string PartId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Reference { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? Sku { get; set; }
    public string? ParentAssembly { get; set; }
    public string MaterialCode { get; set; } = string.Empty;
    public string MaterialName { get; set; } = string.Empty;
    public decimal LengthMm { get; set; }
    public decimal WidthMm { get; set; }
    public decimal ThicknessMm { get; set; }
    public int Quantity { get; set; }
    public bool CanRotateInNesting { get; set; }
    public bool GrainDirectionRequired { get; set; }
    public string? GrainDirection { get; set; }
    public string? FrontFace { get; set; }
    public string? PartType { get; set; }
    public string? Label { get; set; }
    public string? Barcode { get; set; }
    public ProjectPartPositionDto Position { get; set; } = new();
    public ProjectEdgeBandingSummaryDto EdgeBanding { get; set; } = new();
    public ProjectMachiningSummaryDto Machining { get; set; } = new();
    public Dictionary<string, string> Attributes { get; set; } = new();
}

public sealed class ProjectPartPositionDto
{
    public decimal X { get; set; }
    public decimal Y { get; set; }
    public decimal Z { get; set; }
    public decimal RotationX { get; set; }
    public decimal RotationY { get; set; }
    public decimal RotationZ { get; set; }
}

public sealed class ProjectEdgeBandingSummaryDto
{
    public bool Top { get; set; }
    public bool Bottom { get; set; }
    public bool Left { get; set; }
    public bool Right { get; set; }
    public string VisualCode { get; set; } = "----";
}

public sealed class ProjectMachiningSummaryDto
{
    public bool HasCnc { get; set; }
    public int TotalOperations { get; set; }
    public int DrillOperationCount { get; set; }
    public int InternalCutCount { get; set; }
    public int ExternalCutCount { get; set; }
    public IReadOnlyList<string> ToolCodes { get; set; } = Array.Empty<string>();
}

public sealed class ProjectNestingDto
{
    public decimal BoardWidthMm { get; set; }
    public decimal BoardHeightMm { get; set; }
    public int BoardCount { get; set; }
    public decimal UtilizationPct { get; set; }
    public int EstimatedMinutes { get; set; }
    public decimal TravelMeters { get; set; }
    public int PassCount { get; set; }
    public decimal AverageSpeedMetersPerMinute { get; set; }
    public IReadOnlyList<ProjectNestingSheetDto> Sheets { get; set; } = Array.Empty<ProjectNestingSheetDto>();
}

public sealed class ProjectNestingSheetDto
{
    public int SheetNumber { get; set; }
    public decimal WidthMm { get; set; }
    public decimal HeightMm { get; set; }
    public decimal UsedAreaPct { get; set; }
    public IReadOnlyList<ProjectNestingItemDto> Items { get; set; } = Array.Empty<ProjectNestingItemDto>();
}

public sealed class ProjectNestingItemDto
{
    public string PartId { get; set; } = string.Empty;
    public string Reference { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string MaterialCode { get; set; } = string.Empty;
    public string MaterialName { get; set; } = string.Empty;
    public decimal Xmm { get; set; }
    public decimal Ymm { get; set; }
    public decimal WidthMm { get; set; }
    public decimal HeightMm { get; set; }
    public bool Rotated { get; set; }
    public string FillColor { get; set; } = string.Empty;
}

public sealed class ProjectProductionOrderDto
{
    public string ProjectFolderPath { get; set; } = string.Empty;
    public string ToolSequence { get; set; } = string.Empty;
    public int LabelCount { get; set; }
    public int EstimatedMinutes { get; set; }
    public int CutOperationCount { get; set; }
    public int DrillOperationCount { get; set; }
    public string CuttingMapLabel { get; set; } = string.Empty;
    public string LabelExportLabel { get; set; } = string.Empty;
}

public sealed class ProjectStatusUpdateRequest
{
    public string Status { get; set; } = ProjectStatusValues.Draft;
}

public sealed class GenerateGCodeResponse
{
    public bool Ok { get; set; }
    public string Message { get; set; } = string.Empty;
    public Guid ProjectId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public bool CanGenerateGCode { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public string ProjectFolderPath { get; set; } = string.Empty;
    public DateTimeOffset GeneratedAtUtc { get; set; }
    public int ToolChangeCount { get; set; }
    public int CutOperationCount { get; set; }
    public int DrillOperationCount { get; set; }
    public string ToolSequence { get; set; } = string.Empty;
}
