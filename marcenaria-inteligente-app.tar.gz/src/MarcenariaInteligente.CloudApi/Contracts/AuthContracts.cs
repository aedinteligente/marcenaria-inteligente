﻿namespace MarcenariaInteligente.CloudApi.Contracts;

public sealed class LoginRequest
{
    public string Email { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;
}

public sealed class PluginSessionRequest
{
    public string DashboardToken { get; set; } = string.Empty;
}

public sealed class UserPermissionsDto
{
    public bool CanAccessMachineSettings { get; set; }

    public bool CanAccessTools { get; set; }
}

public sealed class AuthUserDto
{
    public string UserId { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Role { get; set; } = string.Empty;

    public UserPermissionsDto Permissions { get; set; } = new();
}

public sealed class LoginResponse
{
    public bool Ok { get; set; }

    public string Message { get; set; } = string.Empty;

    public string DashboardToken { get; set; } = string.Empty;

    public DateTimeOffset DashboardTokenExpiresAtUtc { get; set; }

    public AuthUserDto User { get; set; } = new();
}

public sealed class PluginSessionResponse
{
    public bool Ok { get; set; }

    public string Token { get; set; } = string.Empty;

    public long ExpiresInMs { get; set; }

    public string SyncUrl { get; set; } = string.Empty;

    public string DashboardUrl { get; set; } = string.Empty;

    public PluginEndpointsDto Endpoints { get; set; } = new();

    public PluginVersionDto Plugin { get; set; } = new();

    public AuthUserDto User { get; set; } = new();
}

public sealed class PluginEndpointsDto
{
    public string Sync { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public string Download { get; set; } = string.Empty;
}

public sealed class PluginVersionDto
{
    public string Version { get; set; } = "0.3.0";

    public string VersionUrl { get; set; } = string.Empty;

    public string DownloadUrl { get; set; } = string.Empty;
}

public sealed class AdminUserDto
{
    public string UserId { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Role { get; set; } = string.Empty;

    public bool IsAdmin { get; set; }

    public bool IsActive { get; set; }

    public UserPermissionsDto Permissions { get; set; } = new();
}

public sealed class UpdateUserPermissionsRequest
{
    public bool CanAccessMachineSettings { get; set; }

    public bool CanAccessTools { get; set; }
}
