using System.ComponentModel.DataAnnotations;

namespace MarcenariaInteligente.CloudApi.Contracts;

public sealed class SketchUpProjectImportRequest
{
    [Required]
    public string TenantId { get; set; } = string.Empty;

    [Required]
    public string Source { get; set; } = "sketchup";

    [Required]
    public string PluginVersion { get; set; } = string.Empty;

    [Required]
    public string SketchUpVersion { get; set; } = string.Empty;

    [Required]
    public ProjectInfoDto Project { get; set; } = new();

    [Required]
    [MinLength(1)]
    public List<PartDto> Parts { get; set; } = new();

    public List<MaterialDto> Materials { get; set; } = new();

    public ImportMetadataDto Metadata { get; set; } = new();
}

public sealed class ProjectInfoDto
{
    [Required]
    public string ExternalProjectId { get; set; } = string.Empty;

    [Required]
    public string Name { get; set; } = string.Empty;

    public string? CustomerName { get; set; }

    public string? DesignerName { get; set; }

    public string? Unit { get; set; } = "mm";

    public string? Notes { get; set; }
}

public sealed class PartDto
{
    [Required]
    public string PartId { get; set; } = string.Empty;

    [Required]
    public string Name { get; set; } = string.Empty;

    public string? Sku { get; set; }

    public string? ParentAssembly { get; set; }

    [Required]
    public string MaterialCode { get; set; } = string.Empty;

    [Required]
    [Range(0.01, 10000)]
    public decimal LengthMm { get; set; }

    [Required]
    [Range(0.01, 10000)]
    public decimal WidthMm { get; set; }

    [Required]
    [Range(0.01, 200)]
    public decimal ThicknessMm { get; set; }

    [Range(1, 10000)]
    public int Quantity { get; set; } = 1;

    public bool CanRotateInNesting { get; set; } = true;

    public bool GrainDirectionRequired { get; set; }

    public string? GrainDirection { get; set; }

    public string? FrontFace { get; set; }

    public string? PartType { get; set; }

    public string? Label { get; set; }

    public string? Barcode { get; set; }

    public PartPositionDto Position { get; set; } = new();

    public EdgeBandingDto EdgeBanding { get; set; } = new();

    public List<MachiningOperationDto> Machining { get; set; } = new();

    public Dictionary<string, string> Attributes { get; set; } = new();
}

public sealed class PartPositionDto
{
    public decimal X { get; set; }

    public decimal Y { get; set; }

    public decimal Z { get; set; }

    public decimal RotationX { get; set; }

    public decimal RotationY { get; set; }

    public decimal RotationZ { get; set; }
}

public sealed class EdgeBandingDto
{
    public EdgeBandSideDto Top { get; set; } = new();

    public EdgeBandSideDto Bottom { get; set; } = new();

    public EdgeBandSideDto Left { get; set; } = new();

    public EdgeBandSideDto Right { get; set; } = new();
}

public sealed class EdgeBandSideDto
{
    public bool Enabled { get; set; }

    public string? MaterialCode { get; set; }

    public decimal ThicknessMm { get; set; }

    public decimal WidthMm { get; set; }

    public string? Color { get; set; }
}

public sealed class MaterialDto
{
    [Required]
    public string Code { get; set; } = string.Empty;

    [Required]
    public string Name { get; set; } = string.Empty;

    public string? Category { get; set; }

    public decimal ThicknessMm { get; set; }

    public decimal DefaultBoardLengthMm { get; set; }

    public decimal DefaultBoardWidthMm { get; set; }

    public bool GrainDirectionRequired { get; set; }

    public string? Color { get; set; }

    public string? Supplier { get; set; }
}

public sealed class MachiningOperationDto
{
    [Required]
    public string OperationId { get; set; } = string.Empty;

    [Required]
    public string Type { get; set; } = string.Empty;

    public string Face { get; set; } = "top";

    public decimal StartXmm { get; set; }

    public decimal StartYmm { get; set; }

    public decimal EndXmm { get; set; }

    public decimal EndYmm { get; set; }

    public decimal CenterXmm { get; set; }

    public decimal CenterYmm { get; set; }

    public decimal DiameterMm { get; set; }

    public decimal WidthMm { get; set; }

    public decimal LengthMm { get; set; }

    public decimal DepthMm { get; set; }

    public string? ToolCode { get; set; }

    public string? Notes { get; set; }
}

public sealed class ImportMetadataDto
{
    public DateTimeOffset ExportedAt { get; set; } = DateTimeOffset.UtcNow;

    public string? MachinePostProcessor { get; set; }

    public string? Hash { get; set; }

    public Dictionary<string, string> Extra { get; set; } = new();
}

public sealed class SketchUpProjectImportResponse
{
    public Guid ImportId { get; set; }

    public string Status { get; set; } = "accepted";

    public string Message { get; set; } = string.Empty;

    public string ProjectName { get; set; } = string.Empty;

    public int PartCount { get; set; }

    public int MaterialCount { get; set; }

    public int MachiningOperationCount { get; set; }

    public DateTimeOffset ReceivedAt { get; set; } = DateTimeOffset.UtcNow;
}
