﻿using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/tools")]
public sealed class ToolsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public ToolsController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet]
    public IActionResult Get([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessTools)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui acesso a Ferramentas."
            });
        }

        return Ok(new
        {
            ok = true,
            tools = new[]
            {
                new { code = "T1", name = "Fresa de topo 6mm", diameterMm = 6 },
                new { code = "T2", name = "Broca 5mm", diameterMm = 5 },
                new { code = "T3", name = "Fresa de acabamento 3mm", diameterMm = 3 }
            }
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
