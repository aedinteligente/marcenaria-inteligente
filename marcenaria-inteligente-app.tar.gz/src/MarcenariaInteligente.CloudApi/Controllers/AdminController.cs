﻿using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/admin")]
public sealed class AdminController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public AdminController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet("users")]
    public IActionResult ListUsers([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetAdminUser(authorization, out var errorResult);
        if (user is null)
        {
            return errorResult!;
        }

        var users = _authSessionService.GetUserDirectory().Select(MapUser);
        return Ok(new { ok = true, users });
    }

    [HttpPut("users/{userId}/permissions")]
    public IActionResult UpdatePermissions(
        string userId,
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] UpdateUserPermissionsRequest request)
    {
        var user = GetAdminUser(authorization, out var errorResult);
        if (user is null)
        {
            return errorResult!;
        }

        var updated = _authSessionService.UpdatePermissions(
            userId,
            request.CanAccessMachineSettings,
            request.CanAccessTools);

        if (updated is null)
        {
            return NotFound(new { ok = false, message = "Usuario nao encontrado." });
        }

        return Ok(new
        {
            ok = true,
            message = "Permissoes atualizadas com sucesso.",
            user = MapUser(updated)
        });
    }

    private AuthenticatedUser? GetAdminUser(string? authorization, out IActionResult? errorResult)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            errorResult = Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
            return null;
        }

        if (!string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase))
        {
            errorResult = StatusCode(StatusCodes.Status403Forbidden, new { ok = false, message = "Acesso restrito ao painel de administracao." });
            return null;
        }

        errorResult = null;
        return user;
    }

    private static AdminUserDto MapUser(UserAccountSnapshot user)
    {
        return new AdminUserDto
        {
            UserId = user.UserId,
            Name = user.Name,
            Email = user.Email,
            Role = user.Role,
            IsAdmin = string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase),
            IsActive = user.IsActive,
            Permissions = new UserPermissionsDto
            {
                CanAccessMachineSettings = user.CanAccessMachineSettings,
                CanAccessTools = user.CanAccessTools
            }
        };
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
