using MarcenariaInteligente.CloudApi.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/imports")]
public sealed class ImportsController : ControllerBase
{
    [HttpPost("sketchup")]
    [ProducesResponseType(typeof(SketchUpProjectImportResponse), StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ActionResult<SketchUpProjectImportResponse> ImportFromSketchUp(
        [FromBody] SketchUpProjectImportRequest request)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var machiningOperationCount = request.Parts.Sum(part => part.Machining.Count);

        var response = new SketchUpProjectImportResponse
        {
            ImportId = Guid.NewGuid(),
            Status = "accepted",
            Message = "Importação recebida com sucesso. O projeto foi enfileirado para processamento.",
            ProjectName = request.Project.Name,
            PartCount = request.Parts.Sum(part => part.Quantity),
            MaterialCount = request.Materials.Count,
            MachiningOperationCount = machiningOperationCount,
            ReceivedAt = DateTimeOffset.UtcNow
        };

        return Accepted(response);
    }

    [HttpGet("health")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Health()
    {
        return Ok(new
        {
            service = "MarcenariaInteligente.CloudApi",
            status = "ok",
            timestamp = DateTimeOffset.UtcNow
        });
    }
}
