﻿using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly DashboardOptions _options;

    public AuthController(IAuthSessionService authSessionService, IOptions<DashboardOptions> options)
    {
        _authSessionService = authSessionService;
        _options = options.Value;
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public ActionResult<LoginResponse> Login([FromBody] LoginRequest request)
    {
        try
        {
            var user = _authSessionService.SignIn(request.Email, request.Password);
            return Ok(new LoginResponse
            {
                Ok = true,
                Message = "Autenticacao concluida com sucesso.",
                DashboardToken = user.DashboardToken,
                DashboardTokenExpiresAtUtc = user.DashboardTokenExpiresAtUtc,
                User = ToUserDto(user)
            });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "E-mail ou senha invalidos."
            });
        }
    }

    [HttpPost("plugin-session")]
    [ProducesResponseType(typeof(PluginSessionResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public ActionResult<PluginSessionResponse> CreatePluginSession([FromBody] PluginSessionRequest request)
    {
        var user = _authSessionService.GetDashboardUser(request.DashboardToken);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Sessao do dashboard invalida ou expirada."
            });
        }

        var baseUrl = ResolvePublicBaseUrl();
        return Ok(new PluginSessionResponse
        {
            Ok = true,
            Token = user.PluginToken,
            ExpiresInMs = Math.Max(0, (long)(user.PluginTokenExpiresAtUtc - DateTimeOffset.UtcNow).TotalMilliseconds),
            SyncUrl = $"{baseUrl}/api/plugin/cloud-sync",
            DashboardUrl = $"{baseUrl}/projetos",
            Endpoints = new PluginEndpointsDto
            {
                Sync = $"{baseUrl}/api/plugin/cloud-sync",
                Version = $"{baseUrl}/api/plugin/version",
                Download = $"{baseUrl}/api/plugin/download"
            },
            Plugin = new PluginVersionDto
            {
                Version = "0.3.0",
                VersionUrl = $"{baseUrl}/api/plugin/version",
                DownloadUrl = $"{baseUrl}/api/plugin/download"
            },
            User = ToUserDto(user)
        });
    }

    [HttpGet("me")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult Me([FromHeader(Name = "Authorization")] string? authorization)
    {
        var token = ExtractBearerToken(authorization);
        var user = _authSessionService.GetDashboardUser(token);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Sessao invalida ou expirada."
            });
        }

        return Ok(new
        {
            ok = true,
            user = ToUserDto(user)
        });
    }

    private string ResolvePublicBaseUrl()
    {
        var forwardedProto = Request.Headers["X-Forwarded-Proto"].FirstOrDefault();
        var forwardedHost = Request.Headers["X-Forwarded-Host"].FirstOrDefault();

        if (!string.IsNullOrWhiteSpace(forwardedHost))
        {
            var scheme = string.IsNullOrWhiteSpace(forwardedProto) ? Request.Scheme : forwardedProto;
            return $"{scheme}://{forwardedHost}".TrimEnd('/');
        }

        if (Request.Host.HasValue)
        {
            var host = Request.Host.Value.Trim();
            var isLocalHost = host.StartsWith("localhost", StringComparison.OrdinalIgnoreCase)
                || host.StartsWith("127.0.0.1", StringComparison.OrdinalIgnoreCase)
                || host.StartsWith("[::1]", StringComparison.OrdinalIgnoreCase);

            if (!isLocalHost)
            {
                var scheme = host.Contains("trycloudflare.com", StringComparison.OrdinalIgnoreCase)
                    ? "https"
                    : Request.Scheme;
                return $"{scheme}://{host}".TrimEnd('/');
            }
        }

        return _options.DefaultBaseUrl.TrimEnd('/');
    }

    private static AuthUserDto ToUserDto(AuthenticatedUser user)
    {
        return new AuthUserDto
        {
            UserId = user.UserId,
            Name = user.Name,
            Email = user.Email,
            Role = user.Role,
            Permissions = new UserPermissionsDto
            {
                CanAccessMachineSettings = user.CanAccessMachineSettings,
                CanAccessTools = user.CanAccessTools
            }
        };
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
