﻿using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/machine-settings")]
public sealed class MachineSettingsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public MachineSettingsController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet]
    public IActionResult Get([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessMachineSettings)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui acesso a Configuracao de Maquina."
            });
        }

        return Ok(new
        {
            ok = true,
            machine = new
            {
                code = "router-cnc-01",
                spindleRpm = 18000,
                feedRateMmMin = 4200,
                plungeRateMmMin = 1800,
                safeZMm = 12
            }
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
