﻿using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/plugin")]
public sealed class PluginController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly IProjectCatalogService _projectCatalogService;

    public PluginController(IAuthSessionService authSessionService, IProjectCatalogService projectCatalogService)
    {
        _authSessionService = authSessionService;
        _projectCatalogService = projectCatalogService;
    }

    [HttpPost("cloud-sync")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult CloudSync(
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] SketchUpProjectImportRequest request)
    {
        var token = ExtractBearerToken(authorization);
        var user = _authSessionService.GetPluginUser(token);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Token do plugin invalido ou expirado."
            });
        }

        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var project = _projectCatalogService.UpsertFromImport(request, user);
        return Ok(new
        {
            ok = true,
            message = "Projeto sincronizado com sucesso.",
            projectId = project.ProjectId,
            projectName = project.Name,
            customerName = project.CustomerName,
            projectUrl = project.Route,
            status = project.Status,
            canGenerateGCode = project.CanGenerateGCode,
            syncedBy = user.Email,
            localProjectFolder = project.LocalProductionFolder,
            receivedAt = DateTimeOffset.UtcNow,
            summary = project.Summary
        });
    }

    [HttpGet("version")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Version()
    {
        return Ok(new
        {
            version = "0.4.0",
            minimumDashboardVersion = "0.4.0",
            releasedAt = DateTimeOffset.UtcNow,
            notes = "Plugin com HtmlDialog, URL publica, callback ENVIAR PROJETO, POST direto para a nuvem e pasta local automatica por nome do projeto."
        });
    }

    [HttpGet("download")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Download()
    {
        return Ok(new
        {
            ok = true,
            message = "Endpoint reservado para distribuicao futura do pacote RBZ do plugin."
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
