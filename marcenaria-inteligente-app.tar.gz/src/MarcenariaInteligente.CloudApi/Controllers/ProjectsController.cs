﻿using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/projects")]
public sealed class ProjectsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly IProjectCatalogService _projectCatalogService;

    public ProjectsController(IAuthSessionService authSessionService, IProjectCatalogService projectCatalogService)
    {
        _authSessionService = authSessionService;
        _projectCatalogService = projectCatalogService;
    }

    [HttpGet]
    public IActionResult List([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var projects = _projectCatalogService.List().Select(MapProject);
        return Ok(new { ok = true, projects });
    }

    [HttpGet("{projectId:guid}")]
    public IActionResult GetById(Guid projectId, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var project = _projectCatalogService.Get(projectId);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new { ok = true, project = MapProjectDetail(project) });
    }

    [HttpGet("by-slug/{slug}")]
    public IActionResult GetBySlug(string slug, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var project = _projectCatalogService.GetBySlug(slug);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new { ok = true, project = MapProjectDetail(project) });
    }

    [HttpPatch("{projectId:guid}/status")]
    public IActionResult UpdateStatus(
        Guid projectId,
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] ProjectStatusUpdateRequest request)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!ProjectStatusValues.IsValid(request.Status))
        {
            return BadRequest(new { ok = false, message = "Status de projeto invalido." });
        }

        var project = _projectCatalogService.UpdateStatus(projectId, request.Status, user);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new
        {
            ok = true,
            message = "Status do projeto atualizado com sucesso.",
            project = MapProjectDetail(project)
        });
    }

    [HttpPost("{projectId:guid}/generate-gcode")]
    public IActionResult GenerateGCode(Guid projectId, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessTools)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui permissao para acessar Ferramentas e gerar G-Code."
            });
        }

        try
        {
            var result = _projectCatalogService.GenerateGCode(projectId, user);
            return Ok(new GenerateGCodeResponse
            {
                Ok = result.Ok,
                Message = result.Message,
                ProjectId = result.Project.ProjectId,
                ProjectName = result.Project.Name,
                Status = result.Project.Status,
                CanGenerateGCode = result.Project.CanGenerateGCode,
                FileName = result.FileName,
                FilePath = result.FilePath,
                ProjectFolderPath = result.ProjectFolderPath,
                GeneratedAtUtc = result.GeneratedAtUtc,
                ToolChangeCount = result.ToolChangeCount,
                CutOperationCount = result.CutOperationCount,
                DrillOperationCount = result.DrillOperationCount,
                ToolSequence = result.ToolSequence
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }
        catch (InvalidOperationException exception)
        {
            return Conflict(new { ok = false, message = exception.Message });
        }
    }

    private AuthenticatedUser? GetCurrentUser(string? authorization)
    {
        return _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
    }

    private static ProjectListItemDto MapProject(StoredProject project)
    {
        return new ProjectListItemDto
        {
            ProjectId = project.ProjectId,
            Slug = project.Slug,
            Route = project.Route,
            Name = project.Name,
            CustomerName = project.CustomerName,
            Status = project.Status,
            CanGenerateGCode = project.CanGenerateGCode,
            Source = project.Source,
            SyncedBy = project.SyncedBy,
            LocalProductionFolder = project.LocalProductionFolder,
            LastGeneratedGCodeFileName = project.LastGeneratedGCodeFileName,
            LastGeneratedGCodePath = project.LastGeneratedGCodePath,
            LastGeneratedAtUtc = project.LastGeneratedAtUtc,
            CreatedAtUtc = project.CreatedAtUtc,
            UpdatedAtUtc = project.UpdatedAtUtc,
            Summary = new ProjectSummaryDto
            {
                PartCount = project.Summary.PartCount,
                MaterialCount = project.Summary.MaterialCount,
                MachiningOperationCount = project.Summary.MachiningOperationCount,
                BoardCount = project.Summary.BoardCount,
                UtilizationPct = project.Summary.UtilizationPct,
                UnplacedParts = project.Summary.UnplacedParts
            }
        };
    }

    private static ProjectDetailDto MapProjectDetail(StoredProject project)
    {
        var baseDto = MapProject(project);
        var materialLookup = project.Materials.ToDictionary(material => material.Code, material => material.Name, StringComparer.OrdinalIgnoreCase);

        return new ProjectDetailDto
        {
            ProjectId = baseDto.ProjectId,
            Slug = baseDto.Slug,
            Route = baseDto.Route,
            Name = baseDto.Name,
            CustomerName = baseDto.CustomerName,
            Status = baseDto.Status,
            CanGenerateGCode = baseDto.CanGenerateGCode,
            Source = baseDto.Source,
            SyncedBy = baseDto.SyncedBy,
            LocalProductionFolder = baseDto.LocalProductionFolder,
            LastGeneratedGCodeFileName = baseDto.LastGeneratedGCodeFileName,
            LastGeneratedGCodePath = baseDto.LastGeneratedGCodePath,
            LastGeneratedAtUtc = baseDto.LastGeneratedAtUtc,
            CreatedAtUtc = baseDto.CreatedAtUtc,
            UpdatedAtUtc = baseDto.UpdatedAtUtc,
            Summary = baseDto.Summary,
            ExternalProjectId = project.ExternalProjectId,
            DesignerName = project.DesignerName,
            Unit = project.Unit,
            Notes = project.Notes,
            MachinePostProcessor = project.MachinePostProcessor,
            ImportHash = project.ImportHash,
            ImportedAtUtc = project.ImportedAtUtc,
            Materials = project.Materials.Select(material => new MaterialDto
            {
                Code = material.Code,
                Name = material.Name,
                Category = material.Category,
                ThicknessMm = material.ThicknessMm,
                DefaultBoardLengthMm = material.DefaultBoardLengthMm,
                DefaultBoardWidthMm = material.DefaultBoardWidthMm,
                GrainDirectionRequired = material.GrainDirectionRequired,
                Color = material.Color,
                Supplier = material.Supplier
            }).ToArray(),
            Parts = project.Parts.Select((part, index) => MapPart(part, index + 1, materialLookup)).ToArray(),
            Nesting = MapNesting(project.Nesting),
            ProductionOrder = new ProjectProductionOrderDto
            {
                ProjectFolderPath = project.ProductionOrder.ProjectFolderPath,
                ToolSequence = project.ProductionOrder.ToolSequence,
                LabelCount = project.ProductionOrder.LabelCount,
                EstimatedMinutes = project.ProductionOrder.EstimatedMinutes,
                CutOperationCount = project.ProductionOrder.CutOperationCount,
                DrillOperationCount = project.ProductionOrder.DrillOperationCount,
                CuttingMapLabel = project.ProductionOrder.CuttingMapLabel,
                LabelExportLabel = project.ProductionOrder.LabelExportLabel
            }
        };
    }

    private static ProjectPartDto MapPart(PartDto part, int item, IReadOnlyDictionary<string, string> materialLookup)
    {
        var quantity = Math.Max(1, part.Quantity);
        var drillCount = part.Machining.Count(operation => IsDrillOperation(operation));
        var externalCutCount = part.Machining.Count(operation => IsExternalCut(operation));
        var internalCutCount = Math.Max(0, part.Machining.Count - drillCount - externalCutCount);
        var tools = part.Machining
            .Select(operation => NormalizeToolCode(operation.ToolCode, operation.Type))
            .Where(code => !string.IsNullOrWhiteSpace(code))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        return new ProjectPartDto
        {
            Item = item,
            PartId = part.PartId,
            Name = part.Name,
            Reference = string.IsNullOrWhiteSpace(part.Sku) ? part.PartId : part.Sku!,
            Sku = part.Sku,
            ParentAssembly = part.ParentAssembly,
            MaterialCode = part.MaterialCode,
            MaterialName = materialLookup.TryGetValue(part.MaterialCode, out var materialName) ? materialName : part.MaterialCode,
            LengthMm = part.LengthMm,
            WidthMm = part.WidthMm,
            ThicknessMm = part.ThicknessMm,
            Quantity = quantity,
            CanRotateInNesting = part.CanRotateInNesting,
            GrainDirectionRequired = part.GrainDirectionRequired,
            GrainDirection = part.GrainDirection,
            FrontFace = part.FrontFace,
            PartType = part.PartType,
            Label = part.Label,
            Barcode = part.Barcode,
            Position = new ProjectPartPositionDto
            {
                X = part.Position.X,
                Y = part.Position.Y,
                Z = part.Position.Z,
                RotationX = part.Position.RotationX,
                RotationY = part.Position.RotationY,
                RotationZ = part.Position.RotationZ
            },
            EdgeBanding = new ProjectEdgeBandingSummaryDto
            {
                Top = part.EdgeBanding.Top.Enabled,
                Bottom = part.EdgeBanding.Bottom.Enabled,
                Left = part.EdgeBanding.Left.Enabled,
                Right = part.EdgeBanding.Right.Enabled,
                VisualCode = BuildEdgeVisualCode(part.EdgeBanding)
            },
            Machining = new ProjectMachiningSummaryDto
            {
                HasCnc = part.Machining.Count > 0,
                TotalOperations = part.Machining.Count,
                DrillOperationCount = drillCount,
                InternalCutCount = internalCutCount,
                ExternalCutCount = externalCutCount,
                ToolCodes = tools
            },
            Attributes = new Dictionary<string, string>(part.Attributes, StringComparer.OrdinalIgnoreCase)
        };
    }

    private static ProjectNestingDto MapNesting(ProjectNestingDto nesting)
    {
        return new ProjectNestingDto
        {
            BoardWidthMm = nesting.BoardWidthMm,
            BoardHeightMm = nesting.BoardHeightMm,
            BoardCount = nesting.BoardCount,
            UtilizationPct = nesting.UtilizationPct,
            EstimatedMinutes = nesting.EstimatedMinutes,
            TravelMeters = nesting.TravelMeters,
            PassCount = nesting.PassCount,
            AverageSpeedMetersPerMinute = nesting.AverageSpeedMetersPerMinute,
            Sheets = nesting.Sheets.Select(sheet => new ProjectNestingSheetDto
            {
                SheetNumber = sheet.SheetNumber,
                WidthMm = sheet.WidthMm,
                HeightMm = sheet.HeightMm,
                UsedAreaPct = sheet.UsedAreaPct,
                Items = sheet.Items.Select(item => new ProjectNestingItemDto
                {
                    PartId = item.PartId,
                    Reference = item.Reference,
                    MaterialCode = item.MaterialCode,
                    Xmm = item.Xmm,
                    Ymm = item.Ymm,
                    WidthMm = item.WidthMm,
                    HeightMm = item.HeightMm,
                    Rotated = item.Rotated
                }).ToArray()
            }).ToArray()
        };
    }

    private static string BuildEdgeVisualCode(EdgeBandingDto edgeBanding)
    {
        return string.Concat(
            edgeBanding.Top.Enabled ? 'T' : '-',
            edgeBanding.Right.Enabled ? 'R' : '-',
            edgeBanding.Bottom.Enabled ? 'B' : '-',
            edgeBanding.Left.Enabled ? 'L' : '-');
    }

    private static bool IsDrillOperation(MachiningOperationDto operation)
    {
        var type = (operation.Type ?? string.Empty).Trim().ToLowerInvariant();
        var toolCode = (operation.ToolCode ?? string.Empty).Trim().ToUpperInvariant();
        return toolCode == "T2"
            || type.Contains("drill", StringComparison.Ordinal)
            || type.Contains("furo", StringComparison.Ordinal)
            || type.Contains("hole", StringComparison.Ordinal)
            || type.Contains("broca", StringComparison.Ordinal);
    }

    private static bool IsExternalCut(MachiningOperationDto operation)
    {
        var type = (operation.Type ?? string.Empty).Trim().ToLowerInvariant();
        return type.Contains("external", StringComparison.Ordinal)
            || type.Contains("outer", StringComparison.Ordinal)
            || type.Contains("extern", StringComparison.Ordinal);
    }

    private static string NormalizeToolCode(string? toolCode, string? type)
    {
        var normalized = (toolCode ?? string.Empty).Trim().ToUpperInvariant();
        if (!string.IsNullOrWhiteSpace(normalized))
        {
            return normalized;
        }

        var typeValue = (type ?? string.Empty).Trim().ToLowerInvariant();
        return typeValue.Contains("drill", StringComparison.Ordinal)
            || typeValue.Contains("furo", StringComparison.Ordinal)
            || typeValue.Contains("hole", StringComparison.Ordinal)
            ? "T2"
            : "T1";
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
