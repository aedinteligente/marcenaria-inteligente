﻿using System.Collections.Concurrent;
using Microsoft.Extensions.Options;

namespace MarcenariaInteligente.CloudApi.Services;

public sealed class DashboardOptions
{
    public const string SectionName = "Dashboard";

    public string AppName { get; set; } = "Marcenaria Inteligente";

    public string DefaultAdminEmail { get; set; } = "admin@marcenaria.local";

    public string DefaultAdminPassword { get; set; } = "Admin@123";

    public string DefaultBaseUrl { get; set; } = "http://localhost:5056";
}

public sealed record AuthenticatedUser(
    string UserId,
    string Name,
    string Email,
    string Role,
    bool CanAccessMachineSettings,
    bool CanAccessTools,
    string DashboardToken,
    DateTimeOffset DashboardTokenExpiresAtUtc,
    string PluginToken,
    DateTimeOffset PluginTokenExpiresAtUtc);

public sealed record UserAccountSnapshot(
    string UserId,
    string Name,
    string Email,
    string Role,
    bool CanAccessMachineSettings,
    bool CanAccessTools,
    bool IsActive);

internal sealed class UserDirectoryEntry
{
    public string UserId { get; set; } = Guid.NewGuid().ToString("N");

    public string Name { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;

    public string Role { get; set; } = "employee";

    public bool CanAccessMachineSettings { get; set; }

    public bool CanAccessTools { get; set; }

    public bool IsActive { get; set; } = true;
}

public interface IAuthSessionService
{
    AuthenticatedUser SignIn(string email, string password);
    AuthenticatedUser? GetDashboardUser(string dashboardToken);
    AuthenticatedUser? GetPluginUser(string pluginToken);
    IReadOnlyCollection<UserAccountSnapshot> GetUserDirectory();
    UserAccountSnapshot? UpdatePermissions(string userId, bool canAccessMachineSettings, bool canAccessTools);
}

public sealed class InMemoryAuthSessionService : IAuthSessionService
{
    private readonly DashboardOptions _options;
    private readonly ConcurrentDictionary<string, UserDirectoryEntry> _usersById = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, string> _userIdsByEmail = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, AuthenticatedUser> _dashboardSessions = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, AuthenticatedUser> _pluginSessions = new(StringComparer.Ordinal);

    public InMemoryAuthSessionService(IOptions<DashboardOptions> options)
    {
        _options = options.Value;
        SeedDefaultUsers();
    }

    public AuthenticatedUser SignIn(string email, string password)
    {
        var normalizedEmail = email.Trim().ToLowerInvariant();

        if (!_userIdsByEmail.TryGetValue(normalizedEmail, out var userId) ||
            !_usersById.TryGetValue(userId, out var user) ||
            !user.IsActive ||
            password != user.Password)
        {
            throw new UnauthorizedAccessException("E-mail ou senha invalidos.");
        }

        var now = DateTimeOffset.UtcNow;
        var dashboardToken = $"dash_{Guid.NewGuid():N}";
        var pluginToken = $"plug_{Guid.NewGuid():N}";
        var authenticatedUser = CreateAuthenticatedUser(
            user,
            dashboardToken,
            now.AddHours(8),
            pluginToken,
            now.AddDays(7));

        _dashboardSessions[dashboardToken] = authenticatedUser;
        _pluginSessions[pluginToken] = authenticatedUser;

        return authenticatedUser;
    }

    public AuthenticatedUser? GetDashboardUser(string dashboardToken)
    {
        if (string.IsNullOrWhiteSpace(dashboardToken))
        {
            return null;
        }

        if (!_dashboardSessions.TryGetValue(dashboardToken, out var user))
        {
            return null;
        }

        return user.DashboardTokenExpiresAtUtc >= DateTimeOffset.UtcNow ? user : null;
    }

    public AuthenticatedUser? GetPluginUser(string pluginToken)
    {
        if (string.IsNullOrWhiteSpace(pluginToken))
        {
            return null;
        }

        if (!_pluginSessions.TryGetValue(pluginToken, out var user))
        {
            return null;
        }

        return user.PluginTokenExpiresAtUtc >= DateTimeOffset.UtcNow ? user : null;
    }

    public IReadOnlyCollection<UserAccountSnapshot> GetUserDirectory()
    {
        return _usersById.Values
            .OrderBy(entry => entry.Role, StringComparer.OrdinalIgnoreCase)
            .ThenBy(entry => entry.Name, StringComparer.OrdinalIgnoreCase)
            .Select(ToSnapshot)
            .ToArray();
    }

    public UserAccountSnapshot? UpdatePermissions(string userId, bool canAccessMachineSettings, bool canAccessTools)
    {
        if (!_usersById.TryGetValue(userId, out var user))
        {
            return null;
        }

        if (string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase))
        {
            user.CanAccessMachineSettings = true;
            user.CanAccessTools = true;
        }
        else
        {
            user.CanAccessMachineSettings = canAccessMachineSettings;
            user.CanAccessTools = canAccessTools;
        }

        RefreshSessions(user);
        return ToSnapshot(user);
    }

    private void SeedDefaultUsers()
    {
        AddOrUpdateUser(new UserDirectoryEntry
        {
            Name = "Administrador",
            Email = _options.DefaultAdminEmail.Trim().ToLowerInvariant(),
            Password = _options.DefaultAdminPassword,
            Role = "admin",
            CanAccessMachineSettings = true,
            CanAccessTools = true,
            IsActive = true
        });

        AddOrUpdateUser(new UserDirectoryEntry
        {
            Name = "Operador CNC",
            Email = "operador@marcenaria.local",
            Password = "Operador@123",
            Role = "employee",
            CanAccessMachineSettings = false,
            CanAccessTools = false,
            IsActive = true
        });

        AddOrUpdateUser(new UserDirectoryEntry
        {
            Name = "Programador CNC",
            Email = "programador@marcenaria.local",
            Password = "Programador@123",
            Role = "employee",
            CanAccessMachineSettings = false,
            CanAccessTools = true,
            IsActive = true
        });
    }

    private void AddOrUpdateUser(UserDirectoryEntry entry)
    {
        entry.Email = entry.Email.Trim().ToLowerInvariant();
        _usersById[entry.UserId] = entry;
        _userIdsByEmail[entry.Email] = entry.UserId;
    }

    private void RefreshSessions(UserDirectoryEntry user)
    {
        foreach (var pair in _dashboardSessions.ToArray())
        {
            if (!string.Equals(pair.Value.UserId, user.UserId, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            _dashboardSessions[pair.Key] = CreateAuthenticatedUser(
                user,
                pair.Value.DashboardToken,
                pair.Value.DashboardTokenExpiresAtUtc,
                pair.Value.PluginToken,
                pair.Value.PluginTokenExpiresAtUtc);
        }

        foreach (var pair in _pluginSessions.ToArray())
        {
            if (!string.Equals(pair.Value.UserId, user.UserId, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            _pluginSessions[pair.Key] = CreateAuthenticatedUser(
                user,
                pair.Value.DashboardToken,
                pair.Value.DashboardTokenExpiresAtUtc,
                pair.Value.PluginToken,
                pair.Value.PluginTokenExpiresAtUtc);
        }
    }

    private static AuthenticatedUser CreateAuthenticatedUser(
        UserDirectoryEntry user,
        string dashboardToken,
        DateTimeOffset dashboardTokenExpiresAtUtc,
        string pluginToken,
        DateTimeOffset pluginTokenExpiresAtUtc)
    {
        return new AuthenticatedUser(
            UserId: user.UserId,
            Name: user.Name,
            Email: user.Email,
            Role: user.Role,
            CanAccessMachineSettings: user.CanAccessMachineSettings,
            CanAccessTools: user.CanAccessTools,
            DashboardToken: dashboardToken,
            DashboardTokenExpiresAtUtc: dashboardTokenExpiresAtUtc,
            PluginToken: pluginToken,
            PluginTokenExpiresAtUtc: pluginTokenExpiresAtUtc);
    }

    private static UserAccountSnapshot ToSnapshot(UserDirectoryEntry user)
    {
        return new UserAccountSnapshot(
            UserId: user.UserId,
            Name: user.Name,
            Email: user.Email,
            Role: user.Role,
            CanAccessMachineSettings: user.CanAccessMachineSettings,
            CanAccessTools: user.CanAccessTools,
            IsActive: user.IsActive);
    }
}
