﻿using System.Collections.Concurrent;
using System.Globalization;
using System.Text;
using MarcenariaInteligente.CloudApi.Contracts;

namespace MarcenariaInteligente.CloudApi.Services;

public sealed class StoredProject
{
    public Guid ProjectId { get; set; }
    public string Slug { get; set; } = string.Empty;
    public string Route { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Status { get; set; } = ProjectStatusValues.Draft;
    public string Source { get; set; } = "sketchup";
    public string SyncedBy { get; set; } = string.Empty;
    public string LocalProductionFolder { get; set; } = string.Empty;
    public string ExternalProjectId { get; set; } = string.Empty;
    public string? DesignerName { get; set; }
    public string? Unit { get; set; } = "mm";
    public string? Notes { get; set; }
    public string? MachinePostProcessor { get; set; }
    public string? ImportHash { get; set; }
    public DateTimeOffset? ImportedAtUtc { get; set; }
    public List<PartDto> Parts { get; set; } = new();
    public List<MaterialDto> Materials { get; set; } = new();
    public ImportMetadataDto Metadata { get; set; } = new();
    public ProjectNestingDto Nesting { get; set; } = new();
    public ProjectProductionOrderDto ProductionOrder { get; set; } = new();
    public string? LastGeneratedGCodeFileName { get; set; }
    public string? LastGeneratedGCodePath { get; set; }
    public DateTimeOffset? LastGeneratedAtUtc { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset UpdatedAtUtc { get; set; }
    public ProjectSummaryDto Summary { get; set; } = new();
    public bool CanGenerateGCode => string.Equals(Status, ProjectStatusValues.InProduction, StringComparison.OrdinalIgnoreCase);
}

public sealed class GCodeGenerationResult
{
    public bool Ok { get; set; }
    public string Message { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public string ProjectFolderPath { get; set; } = string.Empty;
    public DateTimeOffset GeneratedAtUtc { get; set; }
    public int ToolChangeCount { get; set; }
    public int CutOperationCount { get; set; }
    public int DrillOperationCount { get; set; }
    public string ToolSequence { get; set; } = string.Empty;
    public StoredProject Project { get; set; } = new();
}

public interface IProjectCatalogService
{
    StoredProject UpsertFromImport(SketchUpProjectImportRequest request, AuthenticatedUser user);
    IReadOnlyCollection<StoredProject> List();
    StoredProject? Get(Guid projectId);
    StoredProject? GetBySlug(string slug);
    StoredProject? UpdateStatus(Guid projectId, string status, AuthenticatedUser user);
    GCodeGenerationResult GenerateGCode(Guid projectId, AuthenticatedUser user);
}

public sealed class InMemoryProjectCatalogService : IProjectCatalogService
{
    private const string DefaultMachineRoot = @"C:\CNC";
    private const decimal DefaultBoardWidthMm = 2750m;
    private const decimal DefaultBoardHeightMm = 1830m;
    private const decimal NestingOuterMarginMm = 12m;
    private const decimal NestingGapMm = 8m;

    private readonly ConcurrentDictionary<Guid, StoredProject> _projects = new();
    private readonly object _gate = new();

    public StoredProject UpsertFromImport(SketchUpProjectImportRequest request, AuthenticatedUser user)
    {
        var slug = Slugify(request.Project.CustomerName, request.Project.Name);
        var now = DateTimeOffset.UtcNow;
        var productionFolder = BuildProjectFolderPath(request.Project.CustomerName, request.Project.Name, slug);
        EnsureProductionSubfolders(productionFolder);

        var importedParts = request.Parts.Select(ClonePart).ToList();
        var importedMaterials = request.Materials.Select(CloneMaterial).ToList();
        var metadata = CloneMetadata(request.Metadata);
        var nesting = BuildNesting(importedParts, importedMaterials);
        var summary = BuildSummary(importedParts, importedMaterials, nesting);
        var productionOrder = BuildProductionOrder(productionFolder, importedParts, nesting);

        lock (_gate)
        {
            var existing = _projects.Values.FirstOrDefault(project => string.Equals(project.Slug, slug, StringComparison.OrdinalIgnoreCase));

            if (existing is null)
            {
                existing = new StoredProject
                {
                    ProjectId = Guid.NewGuid(),
                    Slug = slug,
                    Route = $"/projetos/{slug}",
                    Name = request.Project.Name,
                    CustomerName = request.Project.CustomerName ?? string.Empty,
                    Status = ProjectStatusValues.Draft,
                    Source = "sketchup",
                    SyncedBy = user.Email,
                    LocalProductionFolder = productionFolder,
                    ExternalProjectId = request.Project.ExternalProjectId,
                    DesignerName = request.Project.DesignerName,
                    Unit = request.Project.Unit,
                    Notes = request.Project.Notes,
                    MachinePostProcessor = request.Metadata.MachinePostProcessor,
                    ImportHash = request.Metadata.Hash,
                    ImportedAtUtc = request.Metadata.ExportedAt,
                    Parts = importedParts,
                    Materials = importedMaterials,
                    Metadata = metadata,
                    Nesting = nesting,
                    ProductionOrder = productionOrder,
                    CreatedAtUtc = now,
                    UpdatedAtUtc = now,
                    Summary = summary
                };

                _projects[existing.ProjectId] = existing;
                return Clone(existing);
            }

            existing.Name = request.Project.Name;
            existing.CustomerName = request.Project.CustomerName ?? string.Empty;
            existing.Source = "sketchup";
            existing.SyncedBy = user.Email;
            existing.LocalProductionFolder = productionFolder;
            existing.ExternalProjectId = request.Project.ExternalProjectId;
            existing.DesignerName = request.Project.DesignerName;
            existing.Unit = request.Project.Unit;
            existing.Notes = request.Project.Notes;
            existing.MachinePostProcessor = request.Metadata.MachinePostProcessor;
            existing.ImportHash = request.Metadata.Hash;
            existing.ImportedAtUtc = request.Metadata.ExportedAt;
            existing.Route = $"/projetos/{slug}";
            existing.Slug = slug;
            existing.Parts = importedParts;
            existing.Materials = importedMaterials;
            existing.Metadata = metadata;
            existing.Nesting = nesting;
            existing.ProductionOrder = productionOrder;
            existing.Summary = summary;
            existing.UpdatedAtUtc = now;

            return Clone(existing);
        }
    }

    public IReadOnlyCollection<StoredProject> List()
    {
        return _projects.Values.OrderByDescending(project => project.UpdatedAtUtc).Select(Clone).ToArray();
    }

    public StoredProject? Get(Guid projectId)
    {
        return _projects.TryGetValue(projectId, out var project) ? Clone(project) : null;
    }

    public StoredProject? GetBySlug(string slug)
    {
        var project = _projects.Values.FirstOrDefault(item => string.Equals(item.Slug, slug, StringComparison.OrdinalIgnoreCase));
        return project is null ? null : Clone(project);
    }

    public StoredProject? UpdateStatus(Guid projectId, string status, AuthenticatedUser user)
    {
        if (!_projects.TryGetValue(projectId, out var project))
        {
            return null;
        }

        var normalizedStatus = ProjectStatusValues.Normalize(status);
        if (!ProjectStatusValues.IsValid(normalizedStatus))
        {
            throw new ArgumentException("Status de projeto invalido.", nameof(status));
        }

        project.Status = normalizedStatus;
        project.UpdatedAtUtc = DateTimeOffset.UtcNow;
        project.SyncedBy = user.Email;
        project.Nesting = BuildNesting(project.Parts, project.Materials);
        project.Summary = BuildSummary(project.Parts, project.Materials, project.Nesting);
        project.ProductionOrder = BuildProductionOrder(project.LocalProductionFolder, project.Parts, project.Nesting);
        return Clone(project);
    }

    public GCodeGenerationResult GenerateGCode(Guid projectId, AuthenticatedUser user)
    {
        if (!_projects.TryGetValue(projectId, out var project))
        {
            throw new KeyNotFoundException("Projeto nao encontrado.");
        }

        if (!string.Equals(project.Status, ProjectStatusValues.InProduction, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("O G-Code so pode ser gerado quando o projeto estiver Em Producao.");
        }

        var generatedAt = DateTimeOffset.UtcNow;
        var folderPath = string.IsNullOrWhiteSpace(project.LocalProductionFolder)
            ? BuildProjectFolderPath(project.CustomerName, project.Name, project.Slug)
            : project.LocalProductionFolder;

        EnsureProductionSubfolders(folderPath);
        var gcodeFolder = Path.Combine(folderPath, "GCode");
        Directory.CreateDirectory(gcodeFolder);

        project.Nesting = BuildNesting(project.Parts, project.Materials);
        project.Summary = BuildSummary(project.Parts, project.Materials, project.Nesting);

        var analysis = AnalyzeMachining(project.Parts);
        var fileName = $"{SafeFileName(project.Name)}-{generatedAt:yyyyMMddHHmmss}.nc";
        var filePath = Path.Combine(gcodeFolder, fileName);

        File.WriteAllText(filePath, BuildGCodeContent(project, user, generatedAt, analysis), new UTF8Encoding(false));

        project.LocalProductionFolder = folderPath;
        project.LastGeneratedGCodeFileName = fileName;
        project.LastGeneratedGCodePath = filePath;
        project.LastGeneratedAtUtc = generatedAt;
        project.UpdatedAtUtc = generatedAt;
        project.SyncedBy = user.Email;
        project.ProductionOrder = BuildProductionOrder(folderPath, project.Parts, project.Nesting, analysis);

        return new GCodeGenerationResult
        {
            Ok = true,
            Message = $"G-Code gerado com sucesso em {Path.Combine(folderPath, "GCode")}, com separacao de T1 para cortes e T2 para furacoes.",
            FileName = fileName,
            FilePath = filePath,
            ProjectFolderPath = folderPath,
            GeneratedAtUtc = generatedAt,
            ToolChangeCount = analysis.ToolChangeCount,
            CutOperationCount = analysis.CutOperationCount,
            DrillOperationCount = analysis.DrillOperationCount,
            ToolSequence = analysis.ToolSequenceLabel,
            Project = Clone(project)
        };
    }

    private static ProjectSummaryDto BuildSummary(IReadOnlyList<PartDto> parts, IReadOnlyList<MaterialDto> materials, ProjectNestingDto nesting)
    {
        var partCount = parts.Sum(part => Math.Max(1, part.Quantity));
        var materialCount = materials.Count;
        var machiningOperationCount = parts.Sum(part => Math.Max(1, part.Quantity) * part.Machining.Count);

        return new ProjectSummaryDto
        {
            PartCount = partCount,
            MaterialCount = materialCount,
            MachiningOperationCount = machiningOperationCount,
            BoardCount = nesting.BoardCount,
            UtilizationPct = nesting.UtilizationPct,
            UnplacedParts = 0
        };
    }

    private static ProjectNestingDto BuildNesting(IReadOnlyList<PartDto> parts, IReadOnlyList<MaterialDto> materials)
    {
        var expandedParts = ExpandParts(parts);
        if (expandedParts.Count == 0)
        {
            return new ProjectNestingDto
            {
                BoardWidthMm = DefaultBoardWidthMm,
                BoardHeightMm = DefaultBoardHeightMm,
                BoardCount = 1,
                UtilizationPct = 0,
                EstimatedMinutes = 0,
                TravelMeters = 0,
                PassCount = 0,
                AverageSpeedMetersPerMinute = 0,
                Sheets = new[]
                {
                    new ProjectNestingSheetDto
                    {
                        SheetNumber = 1,
                        WidthMm = DefaultBoardWidthMm,
                        HeightMm = DefaultBoardHeightMm,
                        UsedAreaPct = 0,
                        Items = Array.Empty<ProjectNestingItemDto>()
                    }
                }
            };
        }

        var materialLookup = materials
            .GroupBy(material => material.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

        var sheetBuilders = new List<NestingSheetBuilder>();
        var sheetNumber = 1;

        foreach (var group in expandedParts.GroupBy(part => part.MaterialCode ?? string.Empty, StringComparer.OrdinalIgnoreCase))
        {
            var material = materialLookup.TryGetValue(group.Key, out var foundMaterial) ? foundMaterial : null;
            var boardWidth = material?.DefaultBoardLengthMm > 0 ? material.DefaultBoardLengthMm : DefaultBoardWidthMm;
            var boardHeight = material?.DefaultBoardWidthMm > 0 ? material.DefaultBoardWidthMm : DefaultBoardHeightMm;

            foreach (var part in group.OrderByDescending(item => Math.Max(item.HeightMm, item.WidthMm)).ThenBy(item => item.Name))
            {
                var placed = false;

                foreach (var sheet in sheetBuilders.Where(builder => string.Equals(builder.MaterialCode, group.Key, StringComparison.OrdinalIgnoreCase)
                    && builder.WidthMm == boardWidth
                    && builder.HeightMm == boardHeight))
                {
                    if (sheet.TryPlace(part, out _))
                    {
                        placed = true;
                        break;
                    }
                }

                if (placed)
                {
                    continue;
                }

                var newSheet = new NestingSheetBuilder(sheetNumber++, group.Key, boardWidth, boardHeight);
                if (!newSheet.TryPlace(part, out _))
                {
                    newSheet.ForcePlace(part);
                }

                sheetBuilders.Add(newSheet);
            }
        }

        var sheets = sheetBuilders.Select(builder => builder.ToDto()).ToArray();
        var totalArea = sheets.Sum(sheet => sheet.WidthMm * sheet.HeightMm);
        var usedArea = sheets.Sum(sheet => sheet.Items.Sum(item => item.WidthMm * item.HeightMm));
        var utilization = totalArea <= 0 ? 0 : Math.Round((usedArea / totalArea) * 100m, 2);
        var machiningCount = parts.Sum(part => Math.Max(1, part.Quantity) * part.Machining.Count);
        var passCount = Math.Max(expandedParts.Count, machiningCount + expandedParts.Count);
        var estimatedMinutes = Math.Max(8, (int)Math.Ceiling(expandedParts.Count * 1.8m + machiningCount * 0.7m));
        var travelMeters = Math.Round((expandedParts.Count * 1.25m) + (machiningCount * 0.18m), 1);

        return new ProjectNestingDto
        {
            BoardWidthMm = sheets.FirstOrDefault()?.WidthMm ?? DefaultBoardWidthMm,
            BoardHeightMm = sheets.FirstOrDefault()?.HeightMm ?? DefaultBoardHeightMm,
            BoardCount = Math.Max(1, sheets.Length),
            UtilizationPct = utilization,
            EstimatedMinutes = estimatedMinutes,
            TravelMeters = travelMeters,
            PassCount = passCount,
            AverageSpeedMetersPerMinute = 16.8m,
            Sheets = sheets
        };
    }

    private static ProjectProductionOrderDto BuildProductionOrder(string? folderPath, IReadOnlyList<PartDto> parts, ProjectNestingDto nesting, MachiningAnalysis? analysis = null)
    {
        var machining = analysis ?? AnalyzeMachining(parts);

        return new ProjectProductionOrderDto
        {
            ProjectFolderPath = folderPath ?? string.Empty,
            ToolSequence = machining.ToolSequenceLabel,
            LabelCount = parts.Sum(part => Math.Max(1, part.Quantity)),
            EstimatedMinutes = nesting.EstimatedMinutes,
            CutOperationCount = machining.CutOperationCount,
            DrillOperationCount = machining.DrillOperationCount,
            CuttingMapLabel = "PDF do mapa de corte pronto para impressao de producao",
            LabelExportLabel = "PDF de etiquetas A4/termica com QR Code pronto para exportacao"
        };
    }

    private static MachiningAnalysis AnalyzeMachining(IReadOnlyList<PartDto> parts)
    {
        var operations = new List<GCodeOperation>();

        foreach (var part in parts)
        {
            var quantity = Math.Max(1, part.Quantity);
            for (var instance = 0; instance < quantity; instance++)
            {
                if (part.Machining.Count == 0)
                {
                    operations.Add(CreateFallbackCut(part, instance));
                    continue;
                }

                foreach (var operation in part.Machining)
                {
                    var toolCode = NormalizeToolCode(operation.ToolCode, operation.Type);
                    var isDrill = IsDrillOperation(operation);
                    var isExternalCut = IsExternalCut(operation);

                    operations.Add(new GCodeOperation
                    {
                        PartId = part.PartId,
                        PartName = part.Name,
                        Reference = BuildPartReference(part, instance),
                        ToolCode = toolCode,
                        Type = operation.Type,
                        IsDrill = isDrill,
                        IsExternalCut = isExternalCut,
                        StartXmm = operation.StartXmm,
                        StartYmm = operation.StartYmm,
                        EndXmm = operation.EndXmm,
                        EndYmm = operation.EndYmm,
                        CenterXmm = operation.CenterXmm,
                        CenterYmm = operation.CenterYmm,
                        DiameterMm = operation.DiameterMm,
                        WidthMm = operation.WidthMm,
                        LengthMm = operation.LengthMm,
                        DepthMm = operation.DepthMm > 0 ? operation.DepthMm : part.ThicknessMm,
                        Notes = operation.Notes
                    });
                }
            }
        }

        var ordered = operations
            .OrderBy(operation => ToolOrder(operation.ToolCode))
            .ThenBy(operation => operation.IsDrill ? 1 : 0)
            .ThenBy(operation => operation.PartName)
            .ThenBy(operation => operation.Reference)
            .ToList();

        var toolSequence = ordered
            .Select(operation => operation.ToolCode)
            .Where(code => !string.IsNullOrWhiteSpace(code))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        return new MachiningAnalysis
        {
            Operations = ordered,
            CutOperationCount = ordered.Count(operation => !operation.IsDrill),
            DrillOperationCount = ordered.Count(operation => operation.IsDrill),
            ToolChangeCount = toolSequence.Length,
            ToolSequence = toolSequence,
            ToolSequenceLabel = toolSequence.Length == 0 ? "Sem ferramentas" : string.Join(" → ", toolSequence)
        };
    }

    private static string BuildGCodeContent(StoredProject project, AuthenticatedUser user, DateTimeOffset generatedAt, MachiningAnalysis analysis)
    {
        var lines = new List<string>
        {
            "%",
            $"; Projeto: {project.Name}",
            $"; Cliente: {project.CustomerName}",
            $"; Gerado por: {user.Email}",
            $"; Gerado em: {generatedAt:O}",
            $"; Pasta local: {project.LocalProductionFolder}",
            $"; Sequencia de ferramentas: {analysis.ToolSequenceLabel}",
            "; Fluxo profissional com trava por status e separacao T1/T2 para ATC",
            "G21",
            "G90",
            "G17",
            "G40",
            "G49",
            "G54",
            "G80",
            "G94"
        };

        string? currentTool = null;
        foreach (var operation in analysis.Operations)
        {
            if (!string.Equals(currentTool, operation.ToolCode, StringComparison.OrdinalIgnoreCase))
            {
                currentTool = operation.ToolCode;
                lines.Add($"; --- Ferramenta {currentTool} ---");
                lines.Add($"M6 {currentTool}");
                lines.Add(operation.IsDrill ? "S12000 M3" : "S18000 M3");
                lines.Add("G0 Z12.000");
            }

            lines.Add($"; {operation.Reference} | {operation.PartName} | {operation.Type}");
            if (operation.IsDrill)
            {
                lines.Add($"G0 X{FormatGCodeDecimal(operation.CenterXmm)} Y{FormatGCodeDecimal(operation.CenterYmm)}");
                lines.Add($"G81 X{FormatGCodeDecimal(operation.CenterXmm)} Y{FormatGCodeDecimal(operation.CenterYmm)} Z-{FormatGCodeDecimal(Math.Max(1m, operation.DepthMm))} R2.000 F1200");
                lines.Add("G80");
            }
            else
            {
                var startX = operation.StartXmm;
                var startY = operation.StartYmm;
                var endX = operation.EndXmm == 0 && operation.EndYmm == 0 ? operation.LengthMm : operation.EndXmm;
                var endY = operation.EndYmm;
                if (endX == 0 && endY == 0)
                {
                    endX = operation.WidthMm > 0 ? operation.WidthMm : 100m;
                    endY = 0;
                }

                lines.Add($"G0 X{FormatGCodeDecimal(startX)} Y{FormatGCodeDecimal(startY)}");
                lines.Add($"G1 Z-{FormatGCodeDecimal(Math.Max(1m, operation.DepthMm))} F1800");
                lines.Add($"G1 X{FormatGCodeDecimal(endX)} Y{FormatGCodeDecimal(endY)} F4200");
                lines.Add("G0 Z12.000");
            }
        }

        lines.Add("M5");
        lines.Add("M30");
        lines.Add("%");
        return string.Join(Environment.NewLine, lines);
    }

    private static GCodeOperation CreateFallbackCut(PartDto part, int instance)
    {
        return new GCodeOperation
        {
            PartId = part.PartId,
            PartName = part.Name,
            Reference = BuildPartReference(part, instance),
            ToolCode = "T1",
            Type = "external_cut",
            IsDrill = false,
            IsExternalCut = true,
            StartXmm = 0,
            StartYmm = 0,
            EndXmm = part.LengthMm,
            EndYmm = 0,
            CenterXmm = part.LengthMm / 2m,
            CenterYmm = part.WidthMm / 2m,
            DiameterMm = 6,
            WidthMm = part.WidthMm,
            LengthMm = part.LengthMm,
            DepthMm = part.ThicknessMm,
            Notes = "Corte externo automatico criado como fallback"
        };
    }

    private static List<ExpandedPart> ExpandParts(IReadOnlyList<PartDto> parts)
    {
        var expanded = new List<ExpandedPart>();
        foreach (var part in parts)
        {
            var quantity = Math.Max(1, part.Quantity);
            for (var index = 0; index < quantity; index++)
            {
                expanded.Add(new ExpandedPart
                {
                    PartId = part.PartId,
                    Name = part.Name,
                    Reference = BuildPartReference(part, index),
                    MaterialCode = part.MaterialCode,
                    WidthMm = part.WidthMm,
                    HeightMm = part.LengthMm,
                    CanRotate = part.CanRotateInNesting
                });
            }
        }

        return expanded;
    }

    private static string BuildPartReference(PartDto part, int instance)
    {
        var baseCode = SafeFileName(part.Sku ?? part.Label ?? part.Name);
        return $"{baseCode}-{instance + 1:00}";
    }

    private static bool IsDrillOperation(MachiningOperationDto operation)
    {
        var type = (operation.Type ?? string.Empty).Trim().ToLowerInvariant();
        var toolCode = (operation.ToolCode ?? string.Empty).Trim().ToUpperInvariant();
        return toolCode == "T2"
            || type.Contains("drill", StringComparison.Ordinal)
            || type.Contains("furo", StringComparison.Ordinal)
            || type.Contains("hole", StringComparison.Ordinal)
            || type.Contains("broca", StringComparison.Ordinal);
    }

    private static bool IsExternalCut(MachiningOperationDto operation)
    {
        var type = (operation.Type ?? string.Empty).Trim().ToLowerInvariant();
        return type.Contains("external", StringComparison.Ordinal)
            || type.Contains("outer", StringComparison.Ordinal)
            || type.Contains("extern", StringComparison.Ordinal);
    }

    private static string NormalizeToolCode(string? toolCode, string? type)
    {
        var normalized = (toolCode ?? string.Empty).Trim().ToUpperInvariant();
        if (!string.IsNullOrWhiteSpace(normalized))
        {
            return normalized;
        }

        var typeValue = (type ?? string.Empty).Trim().ToLowerInvariant();
        return typeValue.Contains("drill", StringComparison.Ordinal)
            || typeValue.Contains("furo", StringComparison.Ordinal)
            || typeValue.Contains("hole", StringComparison.Ordinal)
            ? "T2"
            : "T1";
    }

    private static int ToolOrder(string? toolCode)
    {
        var code = (toolCode ?? string.Empty).Trim().ToUpperInvariant();
        return code switch
        {
            "T1" => 1,
            "T2" => 2,
            "T3" => 3,
            _ => 99
        };
    }

    private static string FormatGCodeDecimal(decimal value)
    {
        return value.ToString("0.###", CultureInfo.InvariantCulture);
    }

    private static void EnsureProductionSubfolders(string projectFolder)
    {
        Directory.CreateDirectory(projectFolder);
        Directory.CreateDirectory(Path.Combine(projectFolder, "GCode"));
        Directory.CreateDirectory(Path.Combine(projectFolder, "Mapas de Corte"));
        Directory.CreateDirectory(Path.Combine(projectFolder, "Etiquetas"));
    }

    private static StoredProject Clone(StoredProject project)
    {
        return new StoredProject
        {
            ProjectId = project.ProjectId,
            Slug = project.Slug,
            Route = project.Route,
            Name = project.Name,
            CustomerName = project.CustomerName,
            Status = project.Status,
            Source = project.Source,
            SyncedBy = project.SyncedBy,
            LocalProductionFolder = project.LocalProductionFolder,
            ExternalProjectId = project.ExternalProjectId,
            DesignerName = project.DesignerName,
            Unit = project.Unit,
            Notes = project.Notes,
            MachinePostProcessor = project.MachinePostProcessor,
            ImportHash = project.ImportHash,
            ImportedAtUtc = project.ImportedAtUtc,
            Parts = project.Parts.Select(ClonePart).ToList(),
            Materials = project.Materials.Select(CloneMaterial).ToList(),
            Metadata = CloneMetadata(project.Metadata),
            Nesting = CloneNesting(project.Nesting),
            ProductionOrder = CloneProductionOrder(project.ProductionOrder),
            LastGeneratedGCodeFileName = project.LastGeneratedGCodeFileName,
            LastGeneratedGCodePath = project.LastGeneratedGCodePath,
            LastGeneratedAtUtc = project.LastGeneratedAtUtc,
            CreatedAtUtc = project.CreatedAtUtc,
            UpdatedAtUtc = project.UpdatedAtUtc,
            Summary = new ProjectSummaryDto
            {
                PartCount = project.Summary.PartCount,
                MaterialCount = project.Summary.MaterialCount,
                MachiningOperationCount = project.Summary.MachiningOperationCount,
                BoardCount = project.Summary.BoardCount,
                UtilizationPct = project.Summary.UtilizationPct,
                UnplacedParts = project.Summary.UnplacedParts
            }
        };
    }

    private static ProjectProductionOrderDto CloneProductionOrder(ProjectProductionOrderDto order)
    {
        return new ProjectProductionOrderDto
        {
            ProjectFolderPath = order.ProjectFolderPath,
            ToolSequence = order.ToolSequence,
            LabelCount = order.LabelCount,
            EstimatedMinutes = order.EstimatedMinutes,
            CutOperationCount = order.CutOperationCount,
            DrillOperationCount = order.DrillOperationCount,
            CuttingMapLabel = order.CuttingMapLabel,
            LabelExportLabel = order.LabelExportLabel
        };
    }

    private static ProjectNestingDto CloneNesting(ProjectNestingDto nesting)
    {
        return new ProjectNestingDto
        {
            BoardWidthMm = nesting.BoardWidthMm,
            BoardHeightMm = nesting.BoardHeightMm,
            BoardCount = nesting.BoardCount,
            UtilizationPct = nesting.UtilizationPct,
            EstimatedMinutes = nesting.EstimatedMinutes,
            TravelMeters = nesting.TravelMeters,
            PassCount = nesting.PassCount,
            AverageSpeedMetersPerMinute = nesting.AverageSpeedMetersPerMinute,
            Sheets = nesting.Sheets.Select(sheet => new ProjectNestingSheetDto
            {
                SheetNumber = sheet.SheetNumber,
                WidthMm = sheet.WidthMm,
                HeightMm = sheet.HeightMm,
                UsedAreaPct = sheet.UsedAreaPct,
                Items = sheet.Items.Select(item => new ProjectNestingItemDto
                {
                    PartId = item.PartId,
                    Reference = item.Reference,
                    MaterialCode = item.MaterialCode,
                    Xmm = item.Xmm,
                    Ymm = item.Ymm,
                    WidthMm = item.WidthMm,
                    HeightMm = item.HeightMm,
                    Rotated = item.Rotated
                }).ToArray()
            }).ToArray()
        };
    }

    private static PartDto ClonePart(PartDto part)
    {
        return new PartDto
        {
            PartId = part.PartId,
            Name = part.Name,
            Sku = part.Sku,
            ParentAssembly = part.ParentAssembly,
            MaterialCode = part.MaterialCode,
            LengthMm = part.LengthMm,
            WidthMm = part.WidthMm,
            ThicknessMm = part.ThicknessMm,
            Quantity = part.Quantity,
            CanRotateInNesting = part.CanRotateInNesting,
            GrainDirectionRequired = part.GrainDirectionRequired,
            GrainDirection = part.GrainDirection,
            FrontFace = part.FrontFace,
            PartType = part.PartType,
            Label = part.Label,
            Barcode = part.Barcode,
            Position = new PartPositionDto
            {
                X = part.Position.X,
                Y = part.Position.Y,
                Z = part.Position.Z,
                RotationX = part.Position.RotationX,
                RotationY = part.Position.RotationY,
                RotationZ = part.Position.RotationZ
            },
            EdgeBanding = new EdgeBandingDto
            {
                Top = CloneEdgeBandSide(part.EdgeBanding.Top),
                Bottom = CloneEdgeBandSide(part.EdgeBanding.Bottom),
                Left = CloneEdgeBandSide(part.EdgeBanding.Left),
                Right = CloneEdgeBandSide(part.EdgeBanding.Right)
            },
            Machining = part.Machining.Select(operation => new MachiningOperationDto
            {
                OperationId = operation.OperationId,
                Type = operation.Type,
                Face = operation.Face,
                StartXmm = operation.StartXmm,
                StartYmm = operation.StartYmm,
                EndXmm = operation.EndXmm,
                EndYmm = operation.EndYmm,
                CenterXmm = operation.CenterXmm,
                CenterYmm = operation.CenterYmm,
                DiameterMm = operation.DiameterMm,
                WidthMm = operation.WidthMm,
                LengthMm = operation.LengthMm,
                DepthMm = operation.DepthMm,
                ToolCode = operation.ToolCode,
                Notes = operation.Notes
            }).ToList(),
            Attributes = part.Attributes.ToDictionary(entry => entry.Key, entry => entry.Value, StringComparer.OrdinalIgnoreCase)
        };
    }

    private static EdgeBandSideDto CloneEdgeBandSide(EdgeBandSideDto side)
    {
        return new EdgeBandSideDto
        {
            Enabled = side.Enabled,
            MaterialCode = side.MaterialCode,
            ThicknessMm = side.ThicknessMm,
            WidthMm = side.WidthMm,
            Color = side.Color
        };
    }

    private static MaterialDto CloneMaterial(MaterialDto material)
    {
        return new MaterialDto
        {
            Code = material.Code,
            Name = material.Name,
            Category = material.Category,
            ThicknessMm = material.ThicknessMm,
            DefaultBoardLengthMm = material.DefaultBoardLengthMm,
            DefaultBoardWidthMm = material.DefaultBoardWidthMm,
            GrainDirectionRequired = material.GrainDirectionRequired,
            Color = material.Color,
            Supplier = material.Supplier
        };
    }

    private static ImportMetadataDto CloneMetadata(ImportMetadataDto metadata)
    {
        return new ImportMetadataDto
        {
            ExportedAt = metadata.ExportedAt,
            MachinePostProcessor = metadata.MachinePostProcessor,
            Hash = metadata.Hash,
            Extra = metadata.Extra.ToDictionary(entry => entry.Key, entry => entry.Value, StringComparer.OrdinalIgnoreCase)
        };
    }

    private static string BuildProjectFolderPath(string? customerName, string? projectName, string? fallbackSlug = null)
    {
        var customerFolder = SafeFolderName(customerName);
        if (string.IsNullOrWhiteSpace(customerFolder))
        {
            customerFolder = "Sem Cliente";
        }

        var projectFolder = SafeFolderName(projectName);
        if (string.IsNullOrWhiteSpace(projectFolder) && !string.IsNullOrWhiteSpace(fallbackSlug))
        {
            projectFolder = SafeFolderName(fallbackSlug);
        }

        if (string.IsNullOrWhiteSpace(projectFolder))
        {
            projectFolder = "Projeto";
        }

        return Path.Combine(DefaultMachineRoot, customerFolder, projectFolder);
    }

    private static string SafeFolderName(string? value)
    {
        var raw = (value ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(raw))
        {
            return string.Empty;
        }

        var invalidChars = Path.GetInvalidFileNameChars();
        var sanitized = new string(raw.Select(ch => invalidChars.Contains(ch) ? '-' : ch).ToArray());
        sanitized = sanitized.Replace('.', '-');

        while (sanitized.Contains("  ", StringComparison.Ordinal))
        {
            sanitized = sanitized.Replace("  ", " ", StringComparison.Ordinal);
        }

        return sanitized.Trim();
    }

    private static string SafeFileName(string? value)
    {
        var folderSafe = SafeFolderName(value);
        if (string.IsNullOrWhiteSpace(folderSafe))
        {
            return "projeto";
        }

        var compact = folderSafe.Replace(' ', '_');
        return compact.Length > 80 ? compact[..80] : compact;
    }

    private static string Slugify(params string?[] values)
    {
        var raw = string.Join('-', values.Where(value => !string.IsNullOrWhiteSpace(value)).Select(value => value!.Trim().ToLowerInvariant()));
        var chars = raw.Select(ch => char.IsLetterOrDigit(ch) ? ch : '-').ToArray();
        var slug = new string(chars);

        while (slug.Contains("--", StringComparison.Ordinal))
        {
            slug = slug.Replace("--", "-", StringComparison.Ordinal);
        }

        return string.IsNullOrWhiteSpace(slug) ? $"projeto-{Guid.NewGuid():N}" : slug.Trim('-');
    }

    private sealed class ExpandedPart
    {
        public string PartId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Reference { get; set; } = string.Empty;
        public string MaterialCode { get; set; } = string.Empty;
        public decimal WidthMm { get; set; }
        public decimal HeightMm { get; set; }
        public bool CanRotate { get; set; }
    }

    private sealed class GCodeOperation
    {
        public string PartId { get; set; } = string.Empty;
        public string PartName { get; set; } = string.Empty;
        public string Reference { get; set; } = string.Empty;
        public string ToolCode { get; set; } = "T1";
        public string Type { get; set; } = string.Empty;
        public bool IsDrill { get; set; }
        public bool IsExternalCut { get; set; }
        public decimal StartXmm { get; set; }
        public decimal StartYmm { get; set; }
        public decimal EndXmm { get; set; }
        public decimal EndYmm { get; set; }
        public decimal CenterXmm { get; set; }
        public decimal CenterYmm { get; set; }
        public decimal DiameterMm { get; set; }
        public decimal WidthMm { get; set; }
        public decimal LengthMm { get; set; }
        public decimal DepthMm { get; set; }
        public string? Notes { get; set; }
    }

    private sealed class MachiningAnalysis
    {
        public IReadOnlyList<GCodeOperation> Operations { get; set; } = Array.Empty<GCodeOperation>();
        public int ToolChangeCount { get; set; }
        public int CutOperationCount { get; set; }
        public int DrillOperationCount { get; set; }
        public IReadOnlyList<string> ToolSequence { get; set; } = Array.Empty<string>();
        public string ToolSequenceLabel { get; set; } = string.Empty;
    }

    private sealed class NestingSheetBuilder
    {
        private decimal _cursorX = NestingOuterMarginMm;
        private decimal _cursorY = NestingOuterMarginMm;
        private decimal _rowHeight;
        private decimal _usedArea;
        private readonly List<ProjectNestingItemDto> _items = new();

        public NestingSheetBuilder(int sheetNumber, string materialCode, decimal widthMm, decimal heightMm)
        {
            SheetNumber = sheetNumber;
            MaterialCode = materialCode;
            WidthMm = widthMm;
            HeightMm = heightMm;
        }

        public int SheetNumber { get; }
        public string MaterialCode { get; }
        public decimal WidthMm { get; }
        public decimal HeightMm { get; }

        public bool TryPlace(ExpandedPart part, out ProjectNestingItemDto placedItem)
        {
            var orientations = BuildOrientations(part);

            foreach (var orientation in orientations)
            {
                if (CanPlaceAt(_cursorX, _cursorY, orientation.width, orientation.height))
                {
                    placedItem = Place(part, orientation.width, orientation.height, orientation.rotated, _cursorX, _cursorY);
                    return true;
                }

                var nextRowY = _cursorY + _rowHeight + NestingGapMm;
                if (CanPlaceAt(NestingOuterMarginMm, nextRowY, orientation.width, orientation.height))
                {
                    _cursorX = NestingOuterMarginMm;
                    _cursorY = nextRowY;
                    _rowHeight = 0;
                    placedItem = Place(part, orientation.width, orientation.height, orientation.rotated, _cursorX, _cursorY);
                    return true;
                }
            }

            placedItem = new ProjectNestingItemDto();
            return false;
        }

        public void ForcePlace(ExpandedPart part)
        {
            var orientation = BuildOrientations(part).First();
            var x = NestingOuterMarginMm;
            var y = NestingOuterMarginMm;
            Place(part, Math.Min(orientation.width, WidthMm - (NestingOuterMarginMm * 2)), Math.Min(orientation.height, HeightMm - (NestingOuterMarginMm * 2)), orientation.rotated, x, y);
        }

        public ProjectNestingSheetDto ToDto()
        {
            var totalArea = WidthMm * HeightMm;
            var usedPct = totalArea <= 0 ? 0 : Math.Round((_usedArea / totalArea) * 100m, 2);
            return new ProjectNestingSheetDto
            {
                SheetNumber = SheetNumber,
                WidthMm = WidthMm,
                HeightMm = HeightMm,
                UsedAreaPct = usedPct,
                Items = _items.ToArray()
            };
        }

        private IEnumerable<(decimal width, decimal height, bool rotated)> BuildOrientations(ExpandedPart part)
        {
            yield return (part.WidthMm, part.HeightMm, false);
            if (part.CanRotate && part.WidthMm != part.HeightMm)
            {
                yield return (part.HeightMm, part.WidthMm, true);
            }
        }

        private bool CanPlaceAt(decimal x, decimal y, decimal width, decimal height)
        {
            var maxWidth = WidthMm - NestingOuterMarginMm;
            var maxHeight = HeightMm - NestingOuterMarginMm;
            return x + width <= maxWidth && y + height <= maxHeight;
        }

        private ProjectNestingItemDto Place(ExpandedPart part, decimal width, decimal height, bool rotated, decimal x, decimal y)
        {
            var item = new ProjectNestingItemDto
            {
                PartId = part.PartId,
                Reference = part.Reference,
                MaterialCode = part.MaterialCode,
                Xmm = x,
                Ymm = y,
                WidthMm = width,
                HeightMm = height,
                Rotated = rotated
            };

            _items.Add(item);
            _usedArea += width * height;
            _rowHeight = Math.Max(_rowHeight, height);
            _cursorX = x + width + NestingGapMm;
            return item;
        }
    }
}
