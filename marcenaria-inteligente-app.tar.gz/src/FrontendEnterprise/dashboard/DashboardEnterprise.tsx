import React, { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import { MoreHorizontal, FolderKanban, Users, BadgeCheck, Factory, Search, Filter, Drill, ScissorsLineDashed, FileBarChart2 } from 'lucide-react';

export type ProjectStatus = 'rascunho' | 'producao';

export interface MetricCardItem {
  label: string;
  value: string;
  trend: string;
  icon: React.ReactNode;
}

export interface ClientVolumeItem {
  client: string;
  projetos: number;
  cor: string;
}

export interface ProjectRow {
  id: string;
  code: string;
  name: string;
  client: string;
  status: ProjectStatus;
  author: string;
  updatedAt: string;
}

export interface BomRow {
  item: number;
  referencia: string;
  codigo: string;
  quantidade: number;
  descricao: string;
  material: string;
  comprimento: number;
  largura: number;
  bordas: {
    top: boolean;
    right: boolean;
    bottom: boolean;
    left: boolean;
  };
  cnc: boolean;
}

const metricCards: MetricCardItem[] = [
  {
    label: 'Total de Projetos',
    value: '248',
    trend: '+12% no mês',
    icon: <FolderKanban className="h-5 w-5" />
  },
  {
    label: 'Licenças Ativas',
    value: '37',
    trend: '+4 esta semana',
    icon: <BadgeCheck className="h-5 w-5" />
  },
  {
    label: 'Total de Clientes',
    value: '91',
    trend: '18 estratégicos',
    icon: <Users className="h-5 w-5" />
  },
  {
    label: 'Máquinas Integradas',
    value: '12',
    trend: '9 online agora',
    icon: <Factory className="h-5 w-5" />
  }
];

const projectVolumeByClient: ClientVolumeItem[] = [
  { client: 'Além do Aroma', projetos: 18, cor: '#0f766e' },
  { client: 'Mercadão dos Óculos', projetos: 12, cor: '#2563eb' },
  { client: 'Viva Ambientes', projetos: 9, cor: '#7c3aed' },
  { client: 'Estúdio Atlas', projetos: 7, cor: '#ea580c' },
  { client: 'Casa Fina Planejados', projetos: 6, cor: '#0891b2' }
];

const projectsSeed: ProjectRow[] = [
  {
    id: 'pjt-001',
    code: 'PRJ-2026-001',
    name: 'Além do Aroma',
    client: 'Além do Aroma',
    status: 'producao',
    author: 'Ana Ribeiro',
    updatedAt: '07/04/2026 16:30'
  },
  {
    id: 'pjt-002',
    code: 'PRJ-2026-002',
    name: 'Clínica Horizonte',
    client: 'Clínica Horizonte',
    status: 'rascunho',
    author: 'Carlos Prado',
    updatedAt: '07/04/2026 11:10'
  },
  {
    id: 'pjt-003',
    code: 'PRJ-2026-003',
    name: 'Mercadão dos Óculos',
    client: 'Mercadão dos Óculos',
    status: 'producao',
    author: 'Ana Ribeiro',
    updatedAt: '06/04/2026 18:45'
  },
  {
    id: 'pjt-004',
    code: 'PRJ-2026-004',
    name: 'Residencial Aurora',
    client: 'Residencial Aurora',
    status: 'rascunho',
    author: 'Marcos Lima',
    updatedAt: '06/04/2026 15:20'
  }
];

const bomSeed: BomRow[] = [
  {
    item: 1,
    referencia: 'LATERAL-EXT-01',
    codigo: 'PEC-0001',
    quantidade: 2,
    descricao: 'Lateral externa armário superior',
    material: 'Branco TX 15',
    comprimento: 720,
    largura: 350,
    bordas: { top: true, right: true, bottom: false, left: false },
    cnc: true
  },
  {
    item: 2,
    referencia: 'PRAT-INT-03',
    codigo: 'PEC-0002',
    quantidade: 3,
    descricao: 'Prateleira interna móvel',
    material: 'Branco TX 15',
    comprimento: 868,
    largura: 320,
    bordas: { top: true, right: false, bottom: true, left: false },
    cnc: false
  },
  {
    item: 3,
    referencia: 'FUNDO-CAIXA-01',
    codigo: 'PEC-0003',
    quantidade: 1,
    descricao: 'Fundo encaixado módulo inferior',
    material: 'Cru 6',
    comprimento: 900,
    largura: 680,
    bordas: { top: false, right: false, bottom: false, left: false },
    cnc: false
  },
  {
    item: 4,
    referencia: 'FRENTE-GAV-01',
    codigo: 'PEC-0004',
    quantidade: 4,
    descricao: 'Frente de gaveta usinada',
    material: 'Madeirado Nogueira 18',
    comprimento: 600,
    largura: 180,
    bordas: { top: true, right: true, bottom: true, left: true },
    cnc: true
  }
];

function clsx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(' ');
}

function SectionCard({
  title,
  subtitle,
  actions,
  children,
  className
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={clsx('rounded-3xl border border-slate-200 bg-white p-6 shadow-[0_24px_80px_-48px_rgba(15,23,42,0.45)]', className)}>
      <div className="mb-5 flex flex-col gap-4 border-b border-slate-100 pb-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
          {subtitle ? <p className="mt-1 text-sm text-slate-500">{subtitle}</p> : null}
        </div>
        {actions ? <div className="flex items-center gap-3">{actions}</div> : null}
      </div>
      {children}
    </section>
  );
}

function MetricCard({ item }: { item: MetricCardItem }) {
  return (
    <article className="rounded-3xl border border-slate-200 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-5 text-white shadow-[0_32px_80px_-56px_rgba(15,23,42,0.75)]">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.24em] text-slate-400">{item.label}</p>
          <strong className="mt-3 block text-4xl font-semibold tracking-tight">{item.value}</strong>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-emerald-300">{item.icon}</div>
      </div>
      <p className="text-sm text-slate-300">{item.trend}</p>
    </article>
  );
}

function StatusPill({ status }: { status: ProjectStatus }) {
  const label = status === 'producao' ? 'Em Produção' : 'Rascunho';
  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold',
        status === 'producao' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
      )}
    >
      {label}
    </span>
  );
}

function ProjectRowActions() {
  const items = ['Orçamentos', 'Custos', 'Lista de Cortes', 'Plano de Corte'];
  return (
    <div className="relative inline-flex">
      <button
        type="button"
        className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 text-slate-500 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
      >
        <MoreHorizontal className="h-4 w-4" />
      </button>
      <div className="absolute right-0 top-12 z-10 hidden min-w-[180px] rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl group-hover:block">
        {items.map(item => (
          <button
            key={item}
            type="button"
            className="block w-full rounded-xl px-3 py-2 text-left text-sm text-slate-600 transition hover:bg-slate-50 hover:text-slate-900"
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}

function EdgeBandingIcon({ edges }: { edges: BomRow['bordas'] }) {
  const active = 'stroke-sky-500 stroke-[4]';
  const inactive = 'stroke-slate-300 stroke-[2] stroke-dasharray-[6_4]';

  return (
    <svg viewBox="0 0 100 70" className="h-12 w-16 overflow-visible">
      <line x1="12" y1="10" x2="88" y2="10" className={edges.top ? active : inactive} />
      <line x1="88" y1="10" x2="88" y2="60" className={edges.right ? active : inactive} />
      <line x1="12" y1="60" x2="88" y2="60" className={edges.bottom ? active : inactive} />
      <line x1="12" y1="10" x2="12" y2="60" className={edges.left ? active : inactive} />
      <rect x="12" y="10" width="76" height="50" rx="8" className="fill-slate-100/70 stroke-slate-200" />
    </svg>
  );
}

export function DashboardHomePage() {
  return (
    <div className="min-h-screen bg-slate-100 p-6 text-slate-900 lg:p-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-8">
        <header className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.32em] text-slate-400">Marcenaria SaaS Enterprise</p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">Visão executiva do dono</h1>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-500">
              Painel inspirado em soluções enterprise para operação integrada entre SketchUp, engenharia, produção e gestão comercial.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-400 hover:bg-slate-50">
              Exportar visão
            </button>
            <button className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800">
              Novo projeto
            </button>
          </div>
        </header>

        <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {metricCards.map(item => (
            <MetricCard key={item.label} item={item} />
          ))}
        </section>

        <section className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
          <SectionCard
            title="Volume de projetos por cliente"
            subtitle="Monitoramento executivo da carteira e priorização da produção"
          >
            <div className="h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={projectVolumeByClient} barCategoryGap={18}>
                  <CartesianGrid stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="client" tickLine={false} axisLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <Tooltip cursor={{ fill: 'rgba(15, 23, 42, 0.04)' }} />
                  <Bar dataKey="projetos" radius={[10, 10, 0, 0]}>
                    {projectVolumeByClient.map(item => (
                      <Cell key={item.client} fill={item.cor} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </SectionCard>

          <SectionCard title="Mix do portfólio" subtitle="Distribuição entre produção e preparação">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-center">
              <div className="h-[240px] w-full lg:max-w-[240px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Produção', value: 62, fill: '#10b981' },
                        { name: 'Rascunho', value: 38, fill: '#f59e0b' }
                      ]}
                      dataKey="value"
                      innerRadius={56}
                      outerRadius={86}
                      paddingAngle={3}
                    />
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-4">
                <div className="rounded-2xl bg-emerald-50 p-4">
                  <p className="text-xs uppercase tracking-[0.24em] text-emerald-700">Produção</p>
                  <strong className="mt-2 block text-3xl font-semibold text-emerald-900">62%</strong>
                  <p className="mt-2 text-sm text-emerald-800">Projetos já liberados para G-Code e chão de fábrica.</p>
                </div>
                <div className="rounded-2xl bg-amber-50 p-4">
                  <p className="text-xs uppercase tracking-[0.24em] text-amber-700">Rascunho</p>
                  <strong className="mt-2 block text-3xl font-semibold text-amber-900">38%</strong>
                  <p className="mt-2 text-sm text-amber-800">Projetos ainda em engenharia, orçamento ou revisão técnica.</p>
                </div>
              </div>
            </div>
          </SectionCard>
        </section>

        <ProjectsTableSection rows={projectsSeed} />
      </div>
    </div>
  );
}

export function ProjectsTableSection({ rows }: { rows: ProjectRow[] }) {
  const [search, setSearch] = useState('');
  const filteredRows = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return rows;
    return rows.filter(row => [row.code, row.name, row.client, row.author].some(value => value.toLowerCase().includes(term)));
  }, [rows, search]);

  return (
    <SectionCard
      title="Lista de Projetos"
      subtitle="Tabela operacional completa com ações rápidas e contexto comercial-técnico"
      actions={
        <>
          <label className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={event => setSearch(event.target.value)}
              placeholder="Buscar por código, nome, cliente ou autor"
              className="h-11 w-[320px] rounded-2xl border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm text-slate-900 outline-none ring-0 transition placeholder:text-slate-400 focus:border-slate-400 focus:bg-white"
            />
          </label>
          <button className="inline-flex h-11 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50">
            <Filter className="h-4 w-4" />
            Filtros
          </button>
        </>
      }
    >
      <div className="overflow-hidden rounded-3xl border border-slate-200">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr className="text-left text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                <th className="px-5 py-4">Código</th>
                <th className="px-5 py-4">Nome</th>
                <th className="px-5 py-4">Cliente</th>
                <th className="px-5 py-4">Status</th>
                <th className="px-5 py-4">Autor</th>
                <th className="px-5 py-4">Atualizado</th>
                <th className="px-5 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {filteredRows.map(row => (
                <tr key={row.id} className="transition hover:bg-slate-50/80">
                  <td className="px-5 py-4 text-sm font-semibold text-slate-900">{row.code}</td>
                  <td className="px-5 py-4 text-sm text-slate-700">{row.name}</td>
                  <td className="px-5 py-4 text-sm text-slate-600">{row.client}</td>
                  <td className="px-5 py-4"><StatusPill status={row.status} /></td>
                  <td className="px-5 py-4 text-sm text-slate-600">{row.author}</td>
                  <td className="px-5 py-4 text-sm text-slate-500">{row.updatedAt}</td>
                  <td className="px-5 py-4 text-right">
                    <ProjectRowActions />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </SectionCard>
  );
}

export function CuttingListPage({ rows = bomSeed }: { rows?: BomRow[] }) {
  return (
    <div className="min-h-screen bg-slate-100 p-6 text-slate-900 lg:p-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-8">
        <header className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.32em] text-slate-400">Engenharia do Projeto</p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">Lista de Cortes · BOM detalhada</h1>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-500">
              Estrutura visual para engenharia, PCP e chão de fábrica, com leitura rápida de material, bordas, dimensões e indicação de usinagem CNC.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-400 hover:bg-slate-50">
              Exportar BOM
            </button>
            <button className="rounded-2xl bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800">
              Abrir Plano de Corte
            </button>
          </div>
        </header>

        <section className="grid gap-5 lg:grid-cols-4">
          <article className="rounded-3xl border border-slate-200 bg-white p-5">
            <div className="mb-4 inline-flex rounded-2xl bg-slate-100 p-3 text-slate-700"><FileBarChart2 className="h-5 w-5" /></div>
            <p className="text-sm text-slate-500">Total de peças</p>
            <strong className="mt-2 block text-3xl font-semibold text-slate-950">{rows.reduce((total, row) => total + row.quantidade, 0)}</strong>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-5">
            <div className="mb-4 inline-flex rounded-2xl bg-sky-50 p-3 text-sky-700"><ScissorsLineDashed className="h-5 w-5" /></div>
            <p className="text-sm text-slate-500">Peças com fita</p>
            <strong className="mt-2 block text-3xl font-semibold text-slate-950">{rows.filter(row => Object.values(row.bordas).some(Boolean)).length}</strong>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-5">
            <div className="mb-4 inline-flex rounded-2xl bg-violet-50 p-3 text-violet-700"><Drill className="h-5 w-5" /></div>
            <p className="text-sm text-slate-500">Com indicação CNC</p>
            <strong className="mt-2 block text-3xl font-semibold text-slate-950">{rows.filter(row => row.cnc).length}</strong>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-5">
            <div className="mb-4 inline-flex rounded-2xl bg-emerald-50 p-3 text-emerald-700"><FolderKanban className="h-5 w-5" /></div>
            <p className="text-sm text-slate-500">Materiais únicos</p>
            <strong className="mt-2 block text-3xl font-semibold text-slate-950">{new Set(rows.map(row => row.material)).size}</strong>
          </article>
        </section>

        <SectionCard title="Bill of Materials" subtitle="Tabela detalhada com representação visual das bordas e indicador de operações CNC">
          <div className="overflow-hidden rounded-3xl border border-slate-200">
            <div className="overflow-x-auto">
              <table className="min-w-[1280px] divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr className="text-left text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                    <th className="px-4 py-4">Item</th>
                    <th className="px-4 py-4">Referência</th>
                    <th className="px-4 py-4">Código</th>
                    <th className="px-4 py-4">Qtde</th>
                    <th className="px-4 py-4">Descrição da Peça</th>
                    <th className="px-4 py-4">Material</th>
                    <th className="px-4 py-4">Dimensões (C × L)</th>
                    <th className="px-4 py-4">Fita de Borda</th>
                    <th className="px-4 py-4">Indicação CNC</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {rows.map(row => (
                    <tr key={row.codigo} className="align-middle transition hover:bg-slate-50/70">
                      <td className="px-4 py-4 text-sm font-semibold text-slate-900">{row.item}</td>
                      <td className="px-4 py-4 text-sm text-slate-600">{row.referencia}</td>
                      <td className="px-4 py-4 text-sm text-slate-600">{row.codigo}</td>
                      <td className="px-4 py-4 text-sm text-slate-600">{row.quantidade}</td>
                      <td className="px-4 py-4 text-sm text-slate-900">{row.descricao}</td>
                      <td className="px-4 py-4 text-sm text-slate-600">{row.material}</td>
                      <td className="px-4 py-4 text-sm text-slate-600">{row.comprimento} × {row.largura} mm</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <EdgeBandingIcon edges={row.bordas} />
                          <div className="text-xs text-slate-500">
                            <p>Azul: borda com fita</p>
                            <p>Tracejada: sem fita</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className={clsx(
                          'inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold',
                          row.cnc ? 'bg-violet-100 text-violet-700' : 'bg-slate-100 text-slate-600'
                        )}>
                          {row.cnc ? 'Furação / Usinagem' : 'Sem usinagem'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

export default function DashboardEnterpriseShowcase() {
  return (
    <div className="space-y-10">
      <DashboardHomePage />
      <CuttingListPage />
    </div>
  );
}
