$base = 'C:\Users\aed marcenaria\Documents\exaustor\marcenaria-inteligente\src\MarcenariaInteligente.CloudApi'

$program = @'
using System.Text.Json.Serialization;
using MarcenariaInteligente.CloudApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        options.JsonSerializerOptions.WriteIndented = true;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHealthChecks();
builder.Services.AddCors(options =>
{
    options.AddPolicy("SpaAndPlugin", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.Configure<DashboardOptions>(builder.Configuration.GetSection(DashboardOptions.SectionName));
builder.Services.AddSingleton<IAuthSessionService, InMemoryAuthSessionService>();
builder.Services.AddSingleton<IProjectCatalogService, InMemoryProjectCatalogService>();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRouting();
app.UseCors("SpaAndPlugin");

app.MapHealthChecks("/health");
app.MapControllers();

app.MapFallback(async context =>
{
    if (context.Request.Path.StartsWithSegments("/api") ||
        context.Request.Path.StartsWithSegments("/health"))
    {
        context.Response.StatusCode = StatusCodes.Status404NotFound;
        await context.Response.WriteAsJsonAsync(new
        {
            ok = false,
            message = "Endpoint nao encontrado."
        });
        return;
    }

    var indexFile = Path.Combine(app.Environment.WebRootPath, "index.html");
    if (!File.Exists(indexFile))
    {
        context.Response.StatusCode = StatusCodes.Status404NotFound;
        await context.Response.WriteAsync("Arquivo index.html nao encontrado.");
        return;
    }

    context.Response.ContentType = "text/html; charset=utf-8";
    await context.Response.SendFileAsync(indexFile);
});

app.Run();
'@

$projectsController = @'
using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/projects")]
public sealed class ProjectsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly IProjectCatalogService _projectCatalogService;

    public ProjectsController(IAuthSessionService authSessionService, IProjectCatalogService projectCatalogService)
    {
        _authSessionService = authSessionService;
        _projectCatalogService = projectCatalogService;
    }

    [HttpGet]
    public IActionResult List([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var projects = _projectCatalogService.List().Select(MapProject);
        return Ok(new { ok = true, projects });
    }

    [HttpGet("{projectId:guid}")]
    public IActionResult GetById(Guid projectId, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var project = _projectCatalogService.Get(projectId);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new { ok = true, project = MapProject(project) });
    }

    [HttpGet("by-slug/{slug}")]
    public IActionResult GetBySlug(string slug, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        var project = _projectCatalogService.GetBySlug(slug);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new { ok = true, project = MapProject(project) });
    }

    [HttpPatch("{projectId:guid}/status")]
    public IActionResult UpdateStatus(
        Guid projectId,
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] ProjectStatusUpdateRequest request)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!ProjectStatusValues.IsValid(request.Status))
        {
            return BadRequest(new { ok = false, message = "Status de projeto invalido." });
        }

        var project = _projectCatalogService.UpdateStatus(projectId, request.Status, user);
        if (project is null)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }

        return Ok(new
        {
            ok = true,
            message = "Status do projeto atualizado com sucesso.",
            project = MapProject(project)
        });
    }

    [HttpPost("{projectId:guid}/generate-gcode")]
    public IActionResult GenerateGCode(Guid projectId, [FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetCurrentUser(authorization);
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessTools)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui permissao para acessar Ferramentas e gerar G-Code."
            });
        }

        try
        {
            var result = _projectCatalogService.GenerateGCode(projectId, user);
            return Ok(new GenerateGCodeResponse
            {
                Ok = result.Ok,
                Message = result.Message,
                ProjectId = result.Project.ProjectId,
                Status = result.Project.Status,
                FileName = result.FileName,
                GeneratedAtUtc = result.GeneratedAtUtc
            });
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { ok = false, message = "Projeto nao encontrado." });
        }
        catch (InvalidOperationException exception)
        {
            return Conflict(new { ok = false, message = exception.Message });
        }
    }

    private AuthenticatedUser? GetCurrentUser(string? authorization)
    {
        return _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
    }

    private static ProjectListItemDto MapProject(StoredProject project)
    {
        return new ProjectListItemDto
        {
            ProjectId = project.ProjectId,
            Slug = project.Slug,
            Route = project.Route,
            Name = project.Name,
            CustomerName = project.CustomerName,
            Status = project.Status,
            CanGenerateGCode = project.CanGenerateGCode,
            Source = project.Source,
            SyncedBy = project.SyncedBy,
            CreatedAtUtc = project.CreatedAtUtc,
            UpdatedAtUtc = project.UpdatedAtUtc,
            Summary = new ProjectSummaryDto
            {
                PartCount = project.Summary.PartCount,
                MaterialCount = project.Summary.MaterialCount,
                MachiningOperationCount = project.Summary.MachiningOperationCount,
                BoardCount = project.Summary.BoardCount,
                UtilizationPct = project.Summary.UtilizationPct,
                UnplacedParts = project.Summary.UnplacedParts
            }
        };
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

$adminController = @'
using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/admin")]
public sealed class AdminController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public AdminController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet("users")]
    public IActionResult ListUsers([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = GetAdminUser(authorization, out var errorResult);
        if (user is null)
        {
            return errorResult!;
        }

        var users = _authSessionService.GetUserDirectory().Select(MapUser);
        return Ok(new { ok = true, users });
    }

    [HttpPut("users/{userId}/permissions")]
    public IActionResult UpdatePermissions(
        string userId,
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] UpdateUserPermissionsRequest request)
    {
        var user = GetAdminUser(authorization, out var errorResult);
        if (user is null)
        {
            return errorResult!;
        }

        var updated = _authSessionService.UpdatePermissions(
            userId,
            request.CanAccessMachineSettings,
            request.CanAccessTools);

        if (updated is null)
        {
            return NotFound(new { ok = false, message = "Usuario nao encontrado." });
        }

        return Ok(new
        {
            ok = true,
            message = "Permissoes atualizadas com sucesso.",
            user = MapUser(updated)
        });
    }

    private AuthenticatedUser? GetAdminUser(string? authorization, out IActionResult? errorResult)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            errorResult = Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
            return null;
        }

        if (!string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase))
        {
            errorResult = StatusCode(StatusCodes.Status403Forbidden, new { ok = false, message = "Acesso restrito ao painel de administracao." });
            return null;
        }

        errorResult = null;
        return user;
    }

    private static AdminUserDto MapUser(UserAccountSnapshot user)
    {
        return new AdminUserDto
        {
            UserId = user.UserId,
            Name = user.Name,
            Email = user.Email,
            Role = user.Role,
            IsAdmin = string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase),
            IsActive = user.IsActive,
            Permissions = new UserPermissionsDto
            {
                CanAccessMachineSettings = user.CanAccessMachineSettings,
                CanAccessTools = user.CanAccessTools
            }
        };
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

Set-Content -Path (Join-Path $base 'Program.cs') -Value $program -Encoding UTF8
Set-Content -Path (Join-Path $base 'Controllers\ProjectsController.cs') -Value $projectsController -Encoding UTF8
Set-Content -Path (Join-Path $base 'Controllers\AdminController.cs') -Value $adminController -Encoding UTF8
Write-Output 'STEP1_DONE'
