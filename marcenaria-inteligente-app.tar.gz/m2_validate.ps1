﻿$ErrorActionPreference = 'Stop'

$project = 'C:\Users\aed marcenaria\Documents\exaustor\marcenaria-inteligente\src\MarcenariaInteligente.CloudApi'
$dotnet = 'C:\Program Files\dotnet\dotnet.exe'
$base = 'http://localhost:5056'
$outLog = Join-Path $project 'run-module2.out.log'
$errLog = Join-Path $project 'run-module2.err.log'

function Invoke-JsonRequest {
    param(
        [string]$Method,
        [string]$Url,
        [hashtable]$Headers = @{},
        [object]$Body = $null
    )

    $params = @{
        Uri = $Url
        Method = $Method
        Headers = $Headers
    }

    if ($null -ne $Body) {
        $params.ContentType = 'application/json'
        if ($Body -is [string]) {
            $params.Body = $Body
        }
        else {
            $params.Body = ($Body | ConvertTo-Json -Depth 20)
        }
    }

    try {
        $response = Invoke-WebRequest @params -UseBasicParsing
        $content = $response.Content
        $json = $null
        if ($content -and ($content.Trim().StartsWith('{') -or $content.Trim().StartsWith('['))) {
            try { $json = $content | ConvertFrom-Json } catch { }
        }

        return [pscustomobject]@{
            StatusCode = [int]$response.StatusCode
            Ok = $true
            Content = $content
            Json = $json
        }
    }
    catch {
        $resp = $_.Exception.Response
        $statusCode = 0
        $content = $_.Exception.Message

        if ($resp) {
            try { $statusCode = [int]$resp.StatusCode.value__ } catch { try { $statusCode = [int]$resp.StatusCode } catch { } }
            try {
                $stream = $resp.GetResponseStream()
                if ($stream) {
                    $reader = New-Object System.IO.StreamReader($stream)
                    $content = $reader.ReadToEnd()
                    $reader.Dispose()
                }
            }
            catch { }
        }

        $json = $null
        if ($content -and ($content.Trim().StartsWith('{') -or $content.Trim().StartsWith('['))) {
            try { $json = $content | ConvertFrom-Json } catch { }
        }

        return [pscustomobject]@{
            StatusCode = $statusCode
            Ok = $false
            Content = $content
            Json = $json
        }
    }
}

Get-CimInstance Win32_Process |
    Where-Object { $_.Name -eq 'dotnet.exe' -and $_.CommandLine -like '*MarcenariaInteligente.CloudApi*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

Remove-Item $outLog, $errLog -Force -ErrorAction SilentlyContinue
$proc = Start-Process -FilePath $dotnet -ArgumentList 'run --urls http://localhost:5056' -WorkingDirectory $project -PassThru -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog

$health = $null
for ($i = 0; $i -lt 45; $i++) {
    Start-Sleep -Seconds 1
    $health = Invoke-JsonRequest -Method 'GET' -Url "$base/health"
    if ($health.Ok) { break }
}

$adminLogin = Invoke-JsonRequest -Method 'POST' -Url "$base/api/auth/login" -Body @{ email = 'admin@marcenaria.local'; password = 'Admin@123' }
$adminToken = $adminLogin.Json.dashboardToken
$pluginSession = Invoke-JsonRequest -Method 'POST' -Url "$base/api/auth/plugin-session" -Body @{ dashboardToken = $adminToken }
$pluginToken = $pluginSession.Json.token

$projectPayload = @{
    tenantId = 'tenant-validacao'
    source = 'sketchup'
    pluginVersion = '0.3.0'
    sketchUpVersion = 'validacao-local'
    project = @{
        externalProjectId = [guid]::NewGuid().ToString()
        name = 'Projeto Validacao Modulo 2'
        customerName = 'Cliente Validacao'
        unit = 'mm'
    }
    parts = @(
        @{
            partId = [guid]::NewGuid().ToString()
            name = 'Lateral'
            materialCode = 'MDF-18-BRANCO'
            lengthMm = 800
            widthMm = 450
            thicknessMm = 18
            quantity = 1
            canRotateInNesting = $true
            grainDirectionRequired = $false
            position = @{ x = 0; y = 0; z = 0; rotationX = 0; rotationY = 0; rotationZ = 0 }
            edgeBanding = @{
                top = @{ enabled = $true; materialCode = 'PVC-1MM'; thicknessMm = 1; widthMm = 22 }
                bottom = @{ enabled = $false; materialCode = $null; thicknessMm = 0; widthMm = 0 }
                left = @{ enabled = $false; materialCode = $null; thicknessMm = 0; widthMm = 0 }
                right = @{ enabled = $true; materialCode = 'PVC-1MM'; thicknessMm = 1; widthMm = 22 }
            }
            machining = @(
                @{
                    operationId = [guid]::NewGuid().ToString()
                    type = 'drilling'
                    face = 'top'
                    centerXmm = 50
                    centerYmm = 50
                    diameterMm = 5
                    depthMm = 18
                    toolCode = 'T2'
                }
            )
            attributes = @{ material_exato = 'MDF Branco 18mm'; fita_topo = 'true'; fita_direita = 'true' }
        }
    )
    materials = @(
        @{ code = 'MDF-18-BRANCO'; name = 'MDF Branco 18mm'; thicknessMm = 18; defaultBoardLengthMm = 2750; defaultBoardWidthMm = 1830 }
    )
    metadata = @{ exportedAt = [DateTimeOffset]::UtcNow.ToString('o') }
}

$sync = Invoke-JsonRequest -Method 'POST' -Url "$base/api/plugin/cloud-sync" -Headers @{ Authorization = "Bearer $pluginToken" } -Body $projectPayload
$projects = Invoke-JsonRequest -Method 'GET' -Url "$base/api/projects" -Headers @{ Authorization = "Bearer $adminToken" }
$projectItem = $projects.Json.projects | Where-Object { $_.name -eq 'Projeto Validacao Modulo 2' } | Select-Object -First 1
if (-not $projectItem) {
    $projectItem = $projects.Json.projects | Select-Object -First 1
}

$projectId = $projectItem.projectId
$projectRoute = $projectItem.route
$catchAllProjectRoute = Invoke-JsonRequest -Method 'GET' -Url ($base + $projectRoute)
$catchAllAdminRoute = Invoke-JsonRequest -Method 'GET' -Url ($base + '/admin')

$gcodeBefore = Invoke-JsonRequest -Method 'POST' -Url "$base/api/projects/$projectId/generate-gcode" -Headers @{ Authorization = "Bearer $adminToken" }
$statusUpdate = Invoke-JsonRequest -Method 'PATCH' -Url "$base/api/projects/$projectId/status" -Headers @{ Authorization = "Bearer $adminToken" } -Body @{ status = 'em_producao' }
$gcodeAfter = Invoke-JsonRequest -Method 'POST' -Url "$base/api/projects/$projectId/generate-gcode" -Headers @{ Authorization = "Bearer $adminToken" }

$adminUsers = Invoke-JsonRequest -Method 'GET' -Url "$base/api/admin/users" -Headers @{ Authorization = "Bearer $adminToken" }
$passwordMap = @{
    'operador@marcenaria.local' = 'Operador@123'
    'programador@marcenaria.local' = 'Programador@123'
}
$targetUser = $adminUsers.Json.users | Where-Object { (-not $_.isAdmin) -and $passwordMap.ContainsKey($_.email) } | Select-Object -First 1
$rbac = $null

if ($targetUser) {
    $originalMachine = [bool]$targetUser.permissions.canAccessMachineSettings
    $originalTools = [bool]$targetUser.permissions.canAccessTools

    $toggleOff = Invoke-JsonRequest -Method 'PUT' -Url "$base/api/admin/users/$($targetUser.userId)/permissions" -Headers @{ Authorization = "Bearer $adminToken" } -Body @{ canAccessMachineSettings = $false; canAccessTools = $false }
    $userLogin = Invoke-JsonRequest -Method 'POST' -Url "$base/api/auth/login" -Body @{ email = $targetUser.email; password = $passwordMap[$targetUser.email] }
    $userToken = $userLogin.Json.dashboardToken
    $machineForbidden = Invoke-JsonRequest -Method 'GET' -Url "$base/api/machine-settings" -Headers @{ Authorization = "Bearer $userToken" }
    $toolsForbidden = Invoke-JsonRequest -Method 'GET' -Url "$base/api/tools" -Headers @{ Authorization = "Bearer $userToken" }
    $adminForbidden = Invoke-JsonRequest -Method 'GET' -Url "$base/api/admin/users" -Headers @{ Authorization = "Bearer $userToken" }
    $restore = Invoke-JsonRequest -Method 'PUT' -Url "$base/api/admin/users/$($targetUser.userId)/permissions" -Headers @{ Authorization = "Bearer $adminToken" } -Body @{ canAccessMachineSettings = $originalMachine; canAccessTools = $originalTools }

    $rbac = [pscustomobject]@{
        TestedUser = $targetUser.email
        ToggleOffStatus = $toggleOff.StatusCode
        MachineSettingsAfterBlock = $machineForbidden.StatusCode
        ToolsAfterBlock = $toolsForbidden.StatusCode
        AdminPanelAsEmployee = $adminForbidden.StatusCode
        RestoreStatus = $restore.StatusCode
    }
}

$appJsPath = Join-Path $project 'wwwroot\assets\app.js'
$appJs = Get-Content $appJsPath -Raw
$frontendChecks = [pscustomobject]@{
    GCodeDisabledRulePresent = ($appJs -match '!project\.canGenerateGCode' -and $appJs -match '!state\.user\?\.permissions\?\.canAccessTools')
    AdminViewPresent = ($appJs -match 'renderAdminView' -and $appJs -match '/api/admin/users')
    MachineGuardPresent = ($appJs -match 'renderMachineSettingsView' -and $appJs -match '/api/machine-settings')
    ToolsGuardPresent = ($appJs -match 'renderToolsView' -and $appJs -match '/api/tools')
}

$result = [pscustomobject]@{
    Backend = [pscustomobject]@{
        ProcessId = $proc.Id
        HealthStatus = $health.StatusCode
        HealthOk = $health.Ok
    }
    Auth = [pscustomobject]@{
        AdminLogin = $adminLogin.StatusCode
        PluginSession = $pluginSession.StatusCode
    }
    CatchAllSpa = [pscustomobject]@{
        ProjectRoute = $projectRoute
        ProjectRouteStatus = $catchAllProjectRoute.StatusCode
        ProjectRouteServesIndex = ($catchAllProjectRoute.Content -like '*Dashboard Web*' -or $catchAllProjectRoute.Content -like '*app-shell*')
        AdminRouteStatus = $catchAllAdminRoute.StatusCode
        AdminRouteServesIndex = ($catchAllAdminRoute.Content -like '*Dashboard Web*' -or $catchAllAdminRoute.Content -like '*app-shell*')
    }
    ProjectFlow = [pscustomobject]@{
        SyncStatus = $sync.StatusCode
        SyncedProjectId = $projectId
        InitialStatus = $projectItem.status
        GCodeBeforeProduction = $gcodeBefore.StatusCode
        StatusUpdate = $statusUpdate.StatusCode
        UpdatedStatus = $statusUpdate.Json.project.status
        GCodeAfterProduction = $gcodeAfter.StatusCode
        GCodeFileName = $gcodeAfter.Json.fileName
    }
    Rbac = $rbac
    FrontendChecks = $frontendChecks
}

$result | ConvertTo-Json -Depth 10

