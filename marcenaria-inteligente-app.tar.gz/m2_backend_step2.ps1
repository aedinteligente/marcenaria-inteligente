$base = 'C:\Users\aed marcenaria\Documents\exaustor\marcenaria-inteligente\src\MarcenariaInteligente.CloudApi'

$authController = @'
using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly DashboardOptions _options;

    public AuthController(IAuthSessionService authSessionService, IOptions<DashboardOptions> options)
    {
        _authSessionService = authSessionService;
        _options = options.Value;
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public ActionResult<LoginResponse> Login([FromBody] LoginRequest request)
    {
        try
        {
            var user = _authSessionService.SignIn(request.Email, request.Password);
            return Ok(new LoginResponse
            {
                Ok = true,
                Message = "Autenticacao concluida com sucesso.",
                DashboardToken = user.DashboardToken,
                DashboardTokenExpiresAtUtc = user.DashboardTokenExpiresAtUtc,
                User = ToUserDto(user)
            });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "E-mail ou senha invalidos."
            });
        }
    }

    [HttpPost("plugin-session")]
    [ProducesResponseType(typeof(PluginSessionResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public ActionResult<PluginSessionResponse> CreatePluginSession([FromBody] PluginSessionRequest request)
    {
        var user = _authSessionService.GetDashboardUser(request.DashboardToken);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Sessao do dashboard invalida ou expirada."
            });
        }

        var baseUrl = ResolvePublicBaseUrl();
        return Ok(new PluginSessionResponse
        {
            Ok = true,
            Token = user.PluginToken,
            ExpiresInMs = Math.Max(0, (long)(user.PluginTokenExpiresAtUtc - DateTimeOffset.UtcNow).TotalMilliseconds),
            SyncUrl = $"{baseUrl}/api/plugin/cloud-sync",
            DashboardUrl = $"{baseUrl}/projetos",
            Endpoints = new PluginEndpointsDto
            {
                Sync = $"{baseUrl}/api/plugin/cloud-sync",
                Version = $"{baseUrl}/api/plugin/version",
                Download = $"{baseUrl}/api/plugin/download"
            },
            Plugin = new PluginVersionDto
            {
                Version = "0.3.0",
                VersionUrl = $"{baseUrl}/api/plugin/version",
                DownloadUrl = $"{baseUrl}/api/plugin/download"
            },
            User = ToUserDto(user)
        });
    }

    [HttpGet("me")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult Me([FromHeader(Name = "Authorization")] string? authorization)
    {
        var token = ExtractBearerToken(authorization);
        var user = _authSessionService.GetDashboardUser(token);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Sessao invalida ou expirada."
            });
        }

        return Ok(new
        {
            ok = true,
            user = ToUserDto(user)
        });
    }

    private string ResolvePublicBaseUrl()
    {
        var forwardedProto = Request.Headers["X-Forwarded-Proto"].FirstOrDefault();
        var forwardedHost = Request.Headers["X-Forwarded-Host"].FirstOrDefault();

        if (!string.IsNullOrWhiteSpace(forwardedHost))
        {
            var scheme = string.IsNullOrWhiteSpace(forwardedProto) ? Request.Scheme : forwardedProto;
            return $"{scheme}://{forwardedHost}".TrimEnd('/');
        }

        if (Request.Host.HasValue)
        {
            var host = Request.Host.Value.Trim();
            var isLocalHost = host.StartsWith("localhost", StringComparison.OrdinalIgnoreCase)
                || host.StartsWith("127.0.0.1", StringComparison.OrdinalIgnoreCase)
                || host.StartsWith("[::1]", StringComparison.OrdinalIgnoreCase);

            if (!isLocalHost)
            {
                var scheme = host.Contains("trycloudflare.com", StringComparison.OrdinalIgnoreCase)
                    ? "https"
                    : Request.Scheme;
                return $"{scheme}://{host}".TrimEnd('/');
            }
        }

        return _options.DefaultBaseUrl.TrimEnd('/');
    }

    private static AuthUserDto ToUserDto(AuthenticatedUser user)
    {
        return new AuthUserDto
        {
            UserId = user.UserId,
            Name = user.Name,
            Email = user.Email,
            Role = user.Role,
            Permissions = new UserPermissionsDto
            {
                CanAccessMachineSettings = user.CanAccessMachineSettings,
                CanAccessTools = user.CanAccessTools
            }
        };
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

$pluginController = @'
using MarcenariaInteligente.CloudApi.Contracts;
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/plugin")]
public sealed class PluginController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;
    private readonly IProjectCatalogService _projectCatalogService;

    public PluginController(IAuthSessionService authSessionService, IProjectCatalogService projectCatalogService)
    {
        _authSessionService = authSessionService;
        _projectCatalogService = projectCatalogService;
    }

    [HttpPost("cloud-sync")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult CloudSync(
        [FromHeader(Name = "Authorization")] string? authorization,
        [FromBody] SketchUpProjectImportRequest request)
    {
        var token = ExtractBearerToken(authorization);
        var user = _authSessionService.GetPluginUser(token);
        if (user is null)
        {
            return Unauthorized(new
            {
                ok = false,
                message = "Token do plugin invalido ou expirado."
            });
        }

        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var project = _projectCatalogService.UpsertFromImport(request, user);
        return Ok(new
        {
            ok = true,
            message = "Projeto sincronizado com sucesso.",
            projectId = project.ProjectId,
            projectUrl = project.Route,
            status = project.Status,
            canGenerateGCode = project.CanGenerateGCode,
            syncedBy = user.Email,
            receivedAt = DateTimeOffset.UtcNow,
            summary = project.Summary
        });
    }

    [HttpGet("version")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Version()
    {
        return Ok(new
        {
            version = "0.3.0",
            minimumDashboardVersion = "0.3.0",
            releasedAt = DateTimeOffset.UtcNow,
            notes = "Plugin com HtmlDialog, callback de sincronizacao, projetos salvos e RBAC no dashboard."
        });
    }

    [HttpGet("download")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Download()
    {
        return Ok(new
        {
            ok = true,
            message = "Endpoint reservado para distribuicao futura do pacote RBZ do plugin."
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

$machineSettingsController = @'
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/machine-settings")]
public sealed class MachineSettingsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public MachineSettingsController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet]
    public IActionResult Get([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessMachineSettings)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui acesso a Configuracao de Maquina."
            });
        }

        return Ok(new
        {
            ok = true,
            machine = new
            {
                code = "router-cnc-01",
                spindleRpm = 18000,
                feedRateMmMin = 4200,
                plungeRateMmMin = 1800,
                safeZMm = 12
            }
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

$toolsController = @'
using MarcenariaInteligente.CloudApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace MarcenariaInteligente.CloudApi.Controllers;

[ApiController]
[Route("api/tools")]
public sealed class ToolsController : ControllerBase
{
    private readonly IAuthSessionService _authSessionService;

    public ToolsController(IAuthSessionService authSessionService)
    {
        _authSessionService = authSessionService;
    }

    [HttpGet]
    public IActionResult Get([FromHeader(Name = "Authorization")] string? authorization)
    {
        var user = _authSessionService.GetDashboardUser(ExtractBearerToken(authorization));
        if (user is null)
        {
            return Unauthorized(new { ok = false, message = "Sessao invalida ou expirada." });
        }

        if (!user.CanAccessTools)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new
            {
                ok = false,
                message = "Seu usuario nao possui acesso a Ferramentas."
            });
        }

        return Ok(new
        {
            ok = true,
            tools = new[]
            {
                new { code = "T1", name = "Fresa de topo 6mm", diameterMm = 6 },
                new { code = "T2", name = "Broca 5mm", diameterMm = 5 },
                new { code = "T3", name = "Fresa de acabamento 3mm", diameterMm = 3 }
            }
        });
    }

    private static string ExtractBearerToken(string? authorization)
    {
        if (string.IsNullOrWhiteSpace(authorization))
        {
            return string.Empty;
        }

        const string prefix = "Bearer ";
        return authorization.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? authorization[prefix.Length..].Trim()
            : authorization.Trim();
    }
}
'@

Set-Content -Path (Join-Path $base 'Controllers\AuthController.cs') -Value $authController -Encoding UTF8
Set-Content -Path (Join-Path $base 'Controllers\PluginController.cs') -Value $pluginController -Encoding UTF8
Set-Content -Path (Join-Path $base 'Controllers\MachineSettingsController.cs') -Value $machineSettingsController -Encoding UTF8
Set-Content -Path (Join-Path $base 'Controllers\ToolsController.cs') -Value $toolsController -Encoding UTF8
Write-Output 'STEP2_DONE'
