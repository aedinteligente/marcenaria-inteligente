# Validação pública do dashboard

- URL pública funcional validada: `https://5056-imssac1zfnp41d83kizwo-b27513b5.us2.manus.computer/`
- Título carregado no navegador: `Marcenaria Inteligente | Enterprise`
- Tela inicial validada com identidade visual branco e vermelho.
- Login público validado com credenciais locais padrão.
- Após autenticação, a rota `/home` abriu corretamente.
- Itens visíveis no dashboard: Home, Projetos, Equipe, Máquina CNC, Ferramentas, Conectar SketchUp, ENVIAR PROJETO.
- O painel inicial exibe a mensagem sobre a ponte SketchUp ↔ Dashboard com `window.sketchup.sincronizar()`.
- O plugin Ruby no computador conectado foi atualizado para usar a URL pública `https://5056-imssac1zfnp41d83kizwo-b27513b5.us2.manus.computer` como `DEFAULT_BASE_URL`.
