# Como testar o plugin SketchUp do Passo 2

**Autor:** Manus AI  
**Data:** 2026-04-06

## O que este plugin faz

Este primeiro plugin de teste adiciona ao SketchUp um menu chamado **Exportar Plano de Corte**. Quando o comando é executado, o script lê os **componentes e grupos selecionados** no modelo 3D, extrai **nome**, **comprimento (X)**, **largura (Y)** e **espessura (Z)** e monta um payload JSON no mesmo contrato definido no Passo 1. Em seguida, o plugin permite **salvar o arquivo `.json`** no computador do usuário ou, se o salvamento for cancelado, tenta exibir o JSON em uma janela de alerta usando `UI.messagebox` [1] [2].

## Arquivo do plugin

O arquivo Ruby criado para este passo é o seguinte:

| Item | Caminho |
|---|---|
| Código-fonte principal | `C:\Users\aed marcenaria\Documents\exaustor\marcenaria-inteligente\sketchup_exportar_plano_de_corte.rb` |
| Cópia já instalada para teste | `C:\Users\aed marcenaria\AppData\Roaming\SketchUp\SketchUp 2025\SketchUp\Plugins\sketchup_exportar_plano_de_corte.rb` |

Isso significa que, no computador conectado, o script **já foi copiado** para a pasta de plugins do **SketchUp 2025**.

## Passo a passo exato para rodar o script no SketchUp

### Cenário recomendado: teste pelo menu do SketchUp

Se você estiver usando o **SketchUp 2025** neste computador, siga exatamente esta sequência.

| Passo | Ação |
|---|---|
| 1 | Feche o SketchUp, caso ele já esteja aberto. |
| 2 | Abra novamente o **SketchUp 2025**. |
| 3 | Abra qualquer arquivo `.skp` de teste, ou crie um modelo simples com alguns componentes. |
| 4 | Selecione no modelo os componentes ou grupos que representam as peças. |
| 5 | No menu superior do SketchUp, abra **Extensions**. |
| 6 | Clique em **Exportar Plano de Corte**. |
| 7 | Escolha onde salvar o arquivo `.json`. |
| 8 | Confirme o salvamento. |
| 9 | Abra o arquivo `.json` salvo no Bloco de Notas, VS Code ou qualquer editor de texto. |
| 10 | Verifique se as peças selecionadas aparecem dentro do array `parts`. |

## O que você deve esperar ao testar

Se a seleção estiver correta, o plugin deve gerar um JSON com esta estrutura lógica.

| Bloco do JSON | Conteúdo esperado |
|---|---|
| `tenantId` | Valor fixo de teste nesta fase |
| `source` | `sketchup` |
| `pluginVersion` | Versão inicial do plugin |
| `sketchUpVersion` | Versão do SketchUp em execução |
| `project` | Informações básicas do arquivo/modelo |
| `parts` | Lista das peças selecionadas |
| `materials` | Materiais deduzidos a partir da seleção |
| `metadata` | Data de exportação e nome do arquivo de origem |

Cada item em `parts` deve conter, no mínimo, os seguintes campos preenchidos pelo teste atual.

| Campo | Origem no SketchUp |
|---|---|
| `name` | Nome da instância ou nome da definição |
| `lengthMm` | Dimensão local no eixo X |
| `widthMm` | Dimensão local no eixo Y |
| `thicknessMm` | Dimensão local no eixo Z |
| `position.x`, `position.y`, `position.z` | Origem da transformação da instância |
| `attributes.sketchupEntityType` | Tipo da entidade (`ComponentInstance` ou `Group`) |
| `attributes.sketchupEntityId` | Identificador interno da entidade |

## Como criar um teste simples dentro do SketchUp

Se você quiser validar rapidamente a extração das medidas, faça um teste controlado com uma peça conhecida. Crie um retângulo com dimensões conhecidas, por exemplo **600 x 400 mm**, empurre com **18 mm** de espessura, transforme esse sólido em componente e dê a ele o nome **Lateral Teste**. Depois selecione apenas essa peça e execute o comando **Exportar Plano de Corte**.

O esperado é que o JSON contenha algo conceitualmente equivalente a isto.

```json
{
  "partId": "P-001",
  "name": "Lateral Teste",
  "materialCode": "SEM_MATERIAL",
  "lengthMm": 600.0,
  "widthMm": 400.0,
  "thicknessMm": 18.0
}
```

Os números podem variar caso a peça tenha sido escalada ou criada em orientação diferente, mas para um teste simples sem rotação e sem escala o resultado deve acompanhar as dimensões originais.

## Como rodar manualmente pelo Console Ruby, se necessário

Se você quiser forçar o carregamento manual do arquivo sem reiniciar o SketchUp, também pode testar pelo **Ruby Console**. Nesse caso, abra o SketchUp, vá em **Window > Ruby Console** e execute a linha abaixo.

```ruby
load 'C:/Users/aed marcenaria/AppData/Roaming/SketchUp/SketchUp 2025/SketchUp/Plugins/sketchup_exportar_plano_de_corte.rb'
```

Depois disso, volte ao menu **Extensions** e procure pela opção **Exportar Plano de Corte**.

## Como interpretar problemas comuns

| Situação | Causa provável | Ação recomendada |
|---|---|---|
| O menu não aparece | O SketchUp estava aberto antes da cópia do arquivo | Feche e abra o SketchUp novamente |
| Surge aviso para selecionar entidades | Nenhum componente ou grupo foi selecionado | Selecione as peças antes de executar o comando |
| O JSON salva, mas medidas parecem erradas | A peça pode ter escala, rotação ou modelagem fora do padrão esperado | Teste primeiro com um componente simples e sem escala |
| O JSON não exibe no alerta | O conteúdo ficou grande demais para a caixa de mensagem | Salve o arquivo em disco em vez de cancelar o diálogo |

## Observação importante sobre esta versão

Esta é uma **versão inicial de validação técnica**. Ela ainda não extrai automaticamente bordas, usinagens, material detalhado, cliente ou metadados produtivos completos. O foco desta etapa é comprovar que o plugin consegue:

1. aparecer no menu do SketchUp;
2. ler a seleção atual;
3. extrair dimensões básicas;
4. montar o JSON no contrato acordado; e
5. salvar esse JSON para conferência.

## Referências

[1]: https://ruby.sketchup.com/UI.html "Module: UI — SketchUp Ruby API Documentation"
[2]: https://ruby.sketchup.com/Sketchup/ComponentInstance.html "Class: Sketchup::ComponentInstance — SketchUp Ruby API Documentation"
