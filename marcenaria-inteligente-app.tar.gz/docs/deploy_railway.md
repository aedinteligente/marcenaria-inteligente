# Publicação permanente no Railway — Marcenaria Inteligente

Este projeto foi preparado para publicação estável no **Railway** com **Docker**, **.NET 8** e frontend estático embarcado na própria aplicação ASP.NET Core.

## O que já foi preparado

| Item | Status | Observação |
|---|---:|---|
| `Dockerfile` | pronto | build multi-stage para .NET 8 |
| `railway.json` | pronto | política de reinício configurada |
| `.dockerignore` | pronto | contexto de build reduzido |
| `Program.cs` | pronto | binding dinâmico em `0.0.0.0:$PORT` |
| fallback SPA | pronto | links diretos da SPA continuam funcionando |

## Estrutura de publicação

O serviço web publica uma aplicação única com:

| Camada | Implementação |
|---|---|
| Backend | ASP.NET Core 8 |
| Frontend | arquivos estáticos em `wwwroot` |
| Deploy | Docker no Railway |
| Porta | variável `PORT` fornecida pelo Railway |

## Variáveis de ambiente recomendadas no Railway

Configure estas variáveis no serviço:

| Variável | Valor sugerido | Finalidade |
|---|---|---|
| `ASPNETCORE_ENVIRONMENT` | `Production` | modo de execução |
| `ASPNETCORE_URLS` | `http://0.0.0.0:${PORT}` | binding de rede |
| `Dashboard__DefaultBaseUrl` | `https://SEU-DOMINIO-OU-URL-RAILWAY` | URL pública usada pela sessão do plugin |
| `Dashboard__DefaultAdminEmail` | `admin@aedinteligente.com` | login inicial do painel |
| `Dashboard__DefaultAdminPassword` | `troque-esta-senha-imediatamente` | senha inicial do painel |

## Passos de publicação no Railway

### 1. Subir o projeto para um repositório Git

Publique a pasta do projeto em um repositório GitHub.

### 2. Criar o projeto no Railway

No Railway:

1. Crie um novo projeto.
2. Escolha **Deploy from GitHub Repo**.
3. Selecione o repositório deste projeto.
4. Aguarde o build com base no `Dockerfile`.

### 3. Habilitar acesso público

Depois do deploy:

1. Abra o serviço.
2. Vá em **Settings → Networking**.
3. Gere um domínio Railway.
4. Depois, se desejar, conecte seu domínio próprio.

### 4. Configurar domínio final

Quando o domínio definitivo estiver disponível, copie-o para a variável:

`Dashboard__DefaultBaseUrl`

Exemplo:

```text
Dashboard__DefaultBaseUrl=https://app.aedinteligente.com.br
```

## Plugin SketchUp em produção

O plugin Ruby precisa apontar para a URL pública final do sistema. No arquivo `sketchup_exportar_plano_de_corte.rb`, substitua a constante `DEFAULT_BASE_URL` pelo domínio final.

Exemplo:

```ruby
DEFAULT_BASE_URL = 'https://app.aedinteligente.com.br'.freeze
```

A ponte já está preparada para:

| Recurso | Status |
|---|---:|
| `UI::HtmlDialog` | pronto |
| `add_action_callback('sendCurrentProject')` | pronto |
| `add_action_callback('synchronizeCurrentProject')` | pronto |
| `add_action_callback('sincronizar')` | pronto |
| `window.sketchup.sincronizar()` | compatível |

## Validação após publicar

Depois do primeiro deploy, valide estes pontos:

| Verificação | Resultado esperado |
|---|---|
| abrir `/` | dashboard carrega sem erro 404/500 |
| abrir `/projetos` | SPA responde por fallback corretamente |
| login admin | autenticação concluída |
| gerar sessão do plugin | endpoints retornam URL pública correta |
| sincronizar projeto | POST em `/api/plugin/cloud-sync` funcionando |

## Observação importante

Sem o **login da sua conta Railway**, eu consigo preparar integralmente o pacote de implantação, mas **não consigo concluir a publicação real no seu workspace**. Assim que você conectar o repositório no Railway, este pacote já estará pronto para subir.
