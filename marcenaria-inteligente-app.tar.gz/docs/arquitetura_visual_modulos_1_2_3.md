# Arquitetura Visual Base — Marcenaria SaaS Enterprise

Nesta etapa, a stack visual adotada para o novo código base será **React + TypeScript + Tailwind CSS + Recharts**, mantendo o backend atual em **ASP.NET Core** e o plugin SketchUp em **Ruby + UI::HtmlDialog**.

| Camada | Stack escolhida | Motivo |
|---|---|---|
| **Dashboard Web** | **React + TypeScript** | Permite componentização clara para Home, Projetos, Lista de Cortes e expansão futura para Plano de Corte |
| **Design System** | **Tailwind CSS** | Acelera construção de UI limpa, responsiva e consistente, com estética enterprise |
| **Gráficos** | **Recharts** | Adequado para cards executivos e gráficos de volume por cliente |
| **Plugin SketchUp** | **Ruby + UI::HtmlDialog** | Mantém integração nativa com SketchUp e permite painel lateral ancorado |
| **Comunicação Plugin ↔ Web** | **Callbacks do HtmlDialog + POST HTTP** | Compatível com o fluxo já consolidado do projeto |

A organização dos arquivos desta base visual seguirá dois blocos. O primeiro será um conjunto de **componentes React reutilizáveis** para o dashboard, cobrindo os Módulos 2 e 3. O segundo será a **interface lateral do plugin** para o Módulo 1, composta por HTML/CSS/JS integráveis ao `UI::HtmlDialog` e preparadas para callbacks Ruby.

| Entrega desta etapa | Conteúdo |
|---|---|
| **Módulo 2** | Home com métricas, gráfico por cliente e tabela de projetos com menu contextual |
| **Módulo 3** | Tela de Lista de Cortes com tabela BOM detalhada, indicador visual de borda e coluna CNC |
| **Módulo 1** | Painel lateral do SketchUp com abas **Galeria** e **Acabamentos** |

Os arquivos serão gerados como **código base visual profissional**, prontos para evolução incremental. O foco desta entrega será a experiência de interface, a organização dos componentes e a compatibilidade com a arquitetura existente.
