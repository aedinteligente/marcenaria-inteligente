# Mapa do projeto e contrato inicial de integração SketchUp

**Autor:** Manus AI  
**Data:** 2026-04-06

## Mapa do projeto em 5 etapas

O desenvolvimento desta plataforma deve ser conduzido em **cinco etapas modulares**, com separação clara entre ingestão de dados, processamento fabril e experiência do usuário. Essa divisão reduz risco técnico, permite entregas incrementais e evita acoplamento prematuro entre CAD, SaaS e CAM.

| Etapa | Nome | Objetivo principal | Entregáveis |
|---|---|---|---|
| 1 | Fundação de integração | Receber e validar na nuvem os dados exportados do SketchUp | Plugin inicial, contrato JSON, API de importação, versionamento de payload |
| 2 | Núcleo SaaS | Estruturar autenticação, empresas, clientes, projetos e materiais | Login, multiempresa, cadastro de materiais, dashboard inicial |
| 3 | Engenharia de corte | Implementar otimização de chapas com restrições de produção | Serviço de nesting, cálculo de sobras, aproveitamento e múltiplas chapas |
| 4 | Produção e rastreabilidade | Gerar etiquetas, relatórios e lotes de fabricação | PDFs, QR Codes, listas de peças, ordens de produção |
| 5 | CNC e industrialização | Exportar dados de usinagem para máquinas e fluxos CAM | Pós-processadores, exportações CNC, validações fabris e auditoria |

## Detalhamento das cinco etapas

A **Etapa 1** deve concentrar a captura do modelo e a ingestão confiável dos dados. Nessa etapa, o plugin do SketchUp precisa selecionar componentes, ler dimensões, espessura, material, bordas, posição e usinagens e enviar tudo para a API por HTTPS em JSON. A API, por sua vez, deve validar o contrato, registrar a importação e devolver um identificador de processamento.

A **Etapa 2** transforma a solução em produto SaaS. O foco passa a ser autenticação, usuários, clientes, materiais, projetos, permissões e histórico de importações. Nessa fase o dashboard web ganha relevância, porque será o ponto central de operação da marcenaria.

A **Etapa 3** introduz o motor de otimização. O objetivo não é apenas encaixar peças em chapas, mas respeitar sentido do veio, rotação permitida, perdas de serra, sobras úteis, agrupamento por material e espessura e priorização de reaproveitamento.

A **Etapa 4** converte dados em produção operacional. Aqui entram etiquetas com QR Code ou código de barras, relatórios de corte, separação por lote, identificação de bordas e rastreabilidade da peça desde a importação até a montagem.

A **Etapa 5** fecha o ciclo industrial. As operações de furação, rasgo, fresagem e contorno passam a ser exportadas conforme o software ou máquina CNC de destino, com pós-processadores por fabricante e validações específicas de bancada ou centro de usinagem.

## Contrato inicial do JSON vindo do SketchUp

O contrato desenhado para a Fase 1 foi pensado para atender três necessidades simultâneas: **produção**, **otimização** e **rastreabilidade**. Em vez de enviar apenas largura e altura, o payload já traz contexto suficiente para suportar corte, borda, etiquetagem e futura exportação CNC.

### Estrutura de alto nível

| Campo | Tipo | Obrigatório | Finalidade |
|---|---|---|---|
| `tenantId` | string | Sim | Identifica a empresa da marcenaria no SaaS |
| `source` | string | Sim | Origem da importação; nesta fase, `sketchup` |
| `pluginVersion` | string | Sim | Versão do plugin responsável pela exportação |
| `sketchUpVersion` | string | Sim | Versão do SketchUp usada na origem |
| `project` | object | Sim | Dados globais do projeto importado |
| `parts` | array | Sim | Lista de peças fabricáveis |
| `materials` | array | Não | Catálogo resumido de materiais encontrados na exportação |
| `metadata` | object | Não | Informações complementares de rastreio e integração |

### Dados mínimos de cada peça

Cada peça precisa carregar os campos que realmente impactam fabricação. O conjunto mínimo recomendado é o seguinte.

| Campo | Tipo | Obrigatório | Observação |
|---|---|---|---|
| `partId` | string | Sim | Identificador único da peça no projeto |
| `name` | string | Sim | Nome legível da peça |
| `materialCode` | string | Sim | Código do material vinculado |
| `lengthMm` | number | Sim | Comprimento da peça em milímetros |
| `widthMm` | number | Sim | Largura da peça em milímetros |
| `thicknessMm` | number | Sim | Espessura da peça |
| `quantity` | integer | Não | Quantidade da peça; padrão 1 |
| `canRotateInNesting` | boolean | Não | Define se pode girar no plano de corte |
| `grainDirectionRequired` | boolean | Não | Indica se o veio precisa ser respeitado |
| `grainDirection` | string | Não | Direção do veio, como `length` ou `width` |
| `edgeBanding` | object | Não | Fitas de borda por lado |
| `machining` | array | Não | Operações de usinagem da peça |
| `attributes` | object | Não | Metadados livres do modelo |

## Estrutura das bordas

As fitas de borda foram modeladas por lado, porque isso é essencial para etiquetagem e produção.

| Lado | Campos principais |
|---|---|
| `top` | `enabled`, `materialCode`, `thicknessMm`, `widthMm`, `color` |
| `bottom` | `enabled`, `materialCode`, `thicknessMm`, `widthMm`, `color` |
| `left` | `enabled`, `materialCode`, `thicknessMm`, `widthMm`, `color` |
| `right` | `enabled`, `materialCode`, `thicknessMm`, `widthMm`, `color` |

## Estrutura das usinagens

As operações de usinagem foram modeladas para aceitar desde furos simples até rasgos e fresagens de contorno.

| Campo | Finalidade |
|---|---|
| `operationId` | Identifica a operação de forma única |
| `type` | Define o tipo: `drill`, `slot`, `groove`, `pocket`, `route`, `contour`, `countersink` ou `other` |
| `face` | Face da peça em que a operação acontece |
| `startXmm`, `startYmm` | Coordenadas iniciais |
| `endXmm`, `endYmm` | Coordenadas finais |
| `centerXmm`, `centerYmm` | Centro útil para furações e pockets |
| `diameterMm` | Diâmetro do furo ou ferramenta associada |
| `widthMm`, `lengthMm`, `depthMm` | Medidas de usinagem |
| `toolCode` | Código da ferramenta ou broca |
| `notes` | Observações técnicas |

## Exemplo resumido do fluxo de Fase 1

```text
1. Usuário seleciona componentes no SketchUp
2. Plugin Ruby lê geometria, material, bordas e usinagens
3. Plugin monta JSON padronizado
4. Plugin envia POST para /api/imports/sketchup
5. API valida o payload
6. API gera um ImportId e marca o projeto como recebido
7. Projeto fica pronto para persistência e processamento futuro
```

## Estrutura criada no computador conectado

Os seguintes artefatos foram criados no diretório do computador conectado para viabilizar a Fase 1.

| Caminho | Conteúdo |
|---|---|
| `marcenaria-inteligente/docs/arquitetura-fase1.md` | Arquitetura ideal e justificativas técnicas |
| `marcenaria-inteligente/docs/mapa-do-projeto-e-contrato.md` | Mapa em 5 etapas e definição do JSON |
| `marcenaria-inteligente/src/MarcenariaInteligente.CloudApi/Program.cs` | Bootstrap da API ASP.NET Core |
| `marcenaria-inteligente/src/MarcenariaInteligente.CloudApi/Controllers/ImportsController.cs` | Endpoint de importação do SketchUp |
| `marcenaria-inteligente/src/MarcenariaInteligente.CloudApi/Contracts/SketchUpImportContracts.cs` | Contratos C# do payload e resposta |
| `marcenaria-inteligente/schemas/sketchup-project-import.schema.json` | JSON Schema formal |
| `marcenaria-inteligente/schemas/sketchup-project-import.sample.json` | Exemplo completo de payload |

## Próxima decisão técnica recomendada

A próxima ação com melhor relação entre esforço e valor é instalar o **.NET SDK 8 ou 9** no computador conectado e, em paralelo, iniciar o **plugin Ruby do SketchUp** com exportação de payload para o endpoint já modelado. Com isso, a Etapa 1 deixa de ser apenas estrutural e passa a ser testável ponta a ponta.

## Referências

[1]: https://ruby.sketchup.com/ "SketchUp Ruby API Documentation"
[2]: https://developers.google.com/optimization/pack/bin_packing "The Bin Packing Problem | OR-Tools"
[3]: https://learn.microsoft.com/en-us/aspnet/core/tutorials/web-api-help-pages-using-swagger?view=aspnetcore-8.0 "ASP.NET Core web API documentation with Swagger / OpenAPI | Microsoft Learn"
[4]: https://www.postgresql.org/docs/current/datatype-json.html "PostgreSQL Documentation: JSON Types"
