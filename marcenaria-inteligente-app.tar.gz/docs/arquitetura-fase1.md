# Arquitetura recomendada da plataforma de marcenaria inteligente

**Autor:** Manus AI  
**Data:** 2026-04-06

## Contexto arquitetural

A plataforma desejada combina três domínios técnicos distintos: **captura CAD**, **orquestração SaaS** e **engenharia de produção**. O fluxo principal começa no **SketchUp**, onde um plugin deve ler componentes, materiais, bordas e operações de usinagem; em seguida, esses dados precisam ser enviados para uma **API central em nuvem**; por fim, o sistema deve processar o projeto para gerar **plano de corte**, **etiquetas**, **relatórios** e **saídas para CNC**.

A documentação oficial do SketchUp confirma que a **Ruby API** é o mecanismo nativo para interagir com modelos e com a própria aplicação, e que essas interações ocorrem dentro do SketchUp [1]. A mesma documentação ressalta que as chamadas à API devem ocorrer na **thread principal**, o que favorece um plugin enxuto, responsável por extrair e serializar dados, deixando o processamento pesado para serviços em nuvem [1].

No motor de corte, o núcleo matemático se aproxima de problemas de **packing** e **bin packing**. A documentação do OR-Tools descreve formalmente o bin packing como a tarefa de encontrar o menor número de recipientes necessário para acomodar todos os itens [2]. Embora o seu caso real seja mais sofisticado, por envolver nesting 2D, orientação do veio, kerf, rotação permitida e restrições fabris, essa base confirma que o algoritmo deve ficar desacoplado do backend transacional, para evoluir de heurísticas rápidas para otimização híbrida.

A documentação da Microsoft também mostra que o **ASP.NET Core Web API** possui suporte maduro para APIs REST e documentação OpenAPI, o que o torna apropriado para receber o JSON vindo do plugin, validar contratos e expor endpoints internos e externos do SaaS [3].

## Arquitetura ideal por camada

| Camada | Tecnologia recomendada | Motivo principal |
|---|---|---|
| Plugin CAD | **Ruby** para extensão SketchUp | É a tecnologia nativa e oficialmente suportada pelo ecossistema SketchUp [1] |
| Dashboard Web | **React + TypeScript + Next.js** | Excelente experiência para SaaS, componentização, autenticação e painéis de dados |
| Backend transacional | **ASP.NET Core Web API (C#)** | Forte tipagem, ótima modelagem de contratos, boa integração com filas, autenticação e OpenAPI [3] |
| Banco principal | **PostgreSQL** | Robusto para multiempresa, histórico de importações, consultas relacionais e suporte a JSON/JSONB [4] |
| Cache e filas curtas | **Redis** | Útil para filas leves, cache de sessão e processamento assíncrono |
| Motor de otimização | **Python** como serviço isolado | Ecossistema forte para heurísticas, matemática, OR-Tools, geração geométrica e evolução rápida |
| Geração de PDFs/etiquetas | **Serviço backend em C#** ou serviço Python especializado | Permite gerar etiquetas, QR Codes, lotes de impressão e relatórios padronizados |
| CNC/CAM export | **Serviço especializado** com regras por máquina | Necessário para traduzir usinagem em formatos por fabricante ou pós-processadores |
| Armazenamento de arquivos | **S3 compatível** | Adequado para modelos importados, artefatos PDF, imagens e arquivos de produção |

## Recomendação objetiva da pilha

A **arquitetura ideal de produção** para o produto SaaS é a seguinte.

| Domínio | Pilha recomendada |
|---|---|
| Frontend web | **Next.js + React + TypeScript + Tailwind CSS** |
| Backend principal | **ASP.NET Core 8/9 + Entity Framework Core + PostgreSQL** |
| Serviço de otimização | **Python 3.11+ + FastAPI + OR-Tools + Shapely/NumPy** |
| Plugin SketchUp | **Ruby + UI::HtmlDialog + HTTPS/JSON** |
| Auth | **JWT + refresh token + SSO opcional** |
| Assíncrono | **Redis + fila de jobs** |
| Observabilidade | **OpenTelemetry + logs estruturados + Sentry/Grafana** |

## Adaptação ao ambiente local detectado

No computador conectado, foi detectado **Windows 11** com executável `dotnet`, porém **sem SDK instalado**, e sem Node.js, Java, Rust ou Python funcional de desenvolvimento. Isso significa que, **neste momento**, o ambiente local não é adequado para compilar todo o stack ideal, mas é suficiente para **modelar a solução**, criar a **estrutura de código-fonte inicial** e preparar um backend base em **C# / ASP.NET Core** de forma manual, pronto para compilar assim que o SDK for instalado.

Por isso, a estratégia mais prudente para a Fase 1 é separar dois níveis de decisão:

| Nível | Decisão |
|---|---|
| Arquitetura de produto | Manter **Frontend React**, **Backend ASP.NET Core**, **Otimizador Python** e **Plugin Ruby** |
| Implementação local imediata | Criar no computador conectado a **estrutura inicial da API em C#**, com contratos JSON, modelos e endpoints de importação |

## Desenho lógico do sistema

```text
SketchUp Plugin (Ruby)
   -> extrai peças, materiais, bordas e usinagens
   -> envia JSON autenticado via HTTPS

Cloud API (ASP.NET Core)
   -> valida payload
   -> persiste projeto, peças e operações
   -> agenda processamento assíncrono

Optimization Service (Python)
   -> calcula plano de corte / nesting
   -> respeita chapa, rotação, veio, folga e sobras
   -> devolve layouts e métricas de aproveitamento

Production Service
   -> gera etiquetas PDF
   -> gera relatórios de produção
   -> exporta dados CNC/CAM

Web Dashboard (Next.js)
   -> projetos
   -> clientes
   -> materiais
   -> produção
   -> relatórios
```

## Modelagem funcional mínima do domínio

| Entidade | Finalidade |
|---|---|
| Tenant | Representa a marcenaria/empresa cliente |
| User | Usuário autenticado do SaaS |
| Customer | Cliente final da marcenaria |
| Project | Projeto importado do SketchUp |
| Material | Catálogo de chapas, espessuras, cores e padrões |
| BoardSheet | Definição da chapa padrão usada no corte |
| Part | Peça fabricável extraída do modelo |
| EdgeBanding | Informação de fita de borda por lado |
| MachiningOperation | Furo, rasgo, canal, pocket, fresagem ou contorno |
| NestJob | Solicitação de otimização de corte |
| LabelBatch | Lote de etiquetas e relatórios |

## Padrão recomendado para integração do plugin

O plugin do SketchUp não deve tentar resolver toda a inteligência de fabricação localmente. A responsabilidade dele deve ser restrita à **extração, normalização inicial e envio**. O payload ideal deve conter contexto do projeto, identificação de peças, orientação, material, bordas, transformações e usinagens. A API recebe esse contrato, registra uma **importação versionada** e responde com um identificador de processamento.

Esse desenho permite três vantagens decisivas. Primeiro, reduz a complexidade dentro do SketchUp, respeitando as limitações do runtime Ruby [1]. Segundo, centraliza regras de produção na nuvem, onde elas podem ser versionadas. Terceiro, permite recalcular cortes e relatórios sem depender de o modelo original estar aberto naquele momento.

## Conclusão arquitetural

A melhor combinação para o produto é: **plugin SketchUp em Ruby**, **dashboard em React/Next.js**, **backend principal em ASP.NET Core**, **PostgreSQL como banco transacional** e **serviço de otimização em Python**. Para a Fase 1 no computador conectado, a escolha prática é iniciar pela **API em C#**, porque o ambiente local está mais próximo do ecossistema .NET do que de qualquer outro, ainda que o SDK precise ser instalado antes da compilação.

## Referências

[1]: https://ruby.sketchup.com/ "SketchUp Ruby API Documentation"
[2]: https://developers.google.com/optimization/pack/bin_packing "The Bin Packing Problem | OR-Tools"
[3]: https://learn.microsoft.com/en-us/aspnet/core/tutorials/web-api-help-pages-using-swagger?view=aspnetcore-8.0 "ASP.NET Core web API documentation with Swagger / OpenAPI | Microsoft Learn"
[4]: https://www.postgresql.org/docs/current/datatype-json.html "PostgreSQL Documentation: JSON Types"
